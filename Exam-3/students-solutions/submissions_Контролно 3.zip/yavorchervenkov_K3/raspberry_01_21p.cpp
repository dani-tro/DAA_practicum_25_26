#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

const int MAX = 512, MOD = 1e9 + 7;
int a[MAX][MAX], dp[MAX][MAX], maxDP[MAX][MAX];
vector<pair<int, int>> sums;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    cin >> n >> m;

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= m; j++)
        {
            cin >> a[i][j];
        }
    }

    dp[n][m] = maxDP[n][m] = a[n][m];
    int ans = dp[n][m];
    for(int j = m - 1; j >= 1; j--)
    {
        dp[1][j] = max(a[1][j], a[1][j] + maxDP[1][j + 1]);
        maxDP[1][j] = max(maxDP[1][j + 1], dp[1][j]);
        ans += dp[1][j];
    }

    cout << ans;
}