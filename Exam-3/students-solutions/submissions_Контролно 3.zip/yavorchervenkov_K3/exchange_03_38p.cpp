#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

const int MAXS = 5e4 + 10, MAXN = 256, MOD = 1e9 + 7;
int a[MAXS], b[MAXS], dp[MAXS][MAXN];
vector<pair<int, int>> sums;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int s, n;
    cin >> s;
    cin >> n;

    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }

    for(int i = 1; i <= n; i++)
    {
        cin >> b[i];
    }

    dp[0][0] = 1;
    sums.push_back({ 0, 0 });
    for(int i = 1; i <= n; i++)
    {
        vector<pair<int, int>> temp;
        for(int j = 1; j <= b[i]; j++)
        {
            for(auto sum : sums)
            {
                if(sum.first + a[i] * j <= s)
                {
                    if(dp[sum.first + a[i] * j][i] == 0)
                    {
                        temp.push_back({ sum.first + a[i] * j, i });
                    }
                    dp[sum.first + a[i] * j][i] += dp[sum.first][sum.second];
                }
            }
        }

        for(auto sum : temp)
        {
            sums.push_back(sum);
        }
    }

    int ans = 0;
    for(int i = 1; i <= n; i++)
    {
        ans += dp[s][i];
        ans %= MOD;
    }

    cout << ans % MOD;
}