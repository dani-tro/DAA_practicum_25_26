#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

#define int long long

const int MAX = 128, MOD = 1e9 + 7;
int a[MAX], dp[MAX][MAX];
pair<int, int> sizes[MAX][MAX];
vector<pair<int, int>> sums;

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n;
    cin >> n;

    cin >> a[0];
    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
        sizes[i][i] = {a[i - 1], a[i]};
    }

    for(int t = 1; t <= n - 1; t++)
    {
        for(int i = 1; i + t <= n; i++)
        {
            int j = i + t;

            sizes[i][j] = { sizes[i][i].first, sizes[i + 1][j].second };
            dp[i][j] = 1e18;
            for(int s = 1; s <= j - i; s++)
            {
                int cand = min(sizes[i][i + s - 1].first * sizes[i + s][j].first * sizes[i + s][j].second + dp[i][i + s - 1] + dp[i + s][j],
                    sizes[i][j - s].first * sizes[i][j - s].second * sizes[j - s + 1][j].second + dp[i][j - s] + dp[j - s + 1][j]);
                dp[i][j] = min(dp[i][j], cand);
            }
        }
    }

    cout << dp[1][n];
}