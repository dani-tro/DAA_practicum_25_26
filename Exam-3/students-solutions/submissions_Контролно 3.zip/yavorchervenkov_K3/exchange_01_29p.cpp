#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

const int MAX = 1e5 + 10, MOD = 1e9 + 7;
int a[MAX], b[MAX];
vector<pair<int, int>> sums;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int s, n;
    cin >> s;
    cin >> n;

    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }

    for(int i = 1; i <= n; i++)
    {
        cin >> b[i];
    }

    int ans = 0;
    sums.push_back({ 0, 0 });
    for(int i = 1; i <= n; i++)
    {
        vector<pair<int, int>> temp;
        for(int j = 1; j <= b[i]; j++)
        {
            for(auto sum : sums) temp.push_back({ sum.first + a[i] * j, sum.second + 1});
        }

        for(auto sum : temp)
        {
            sums.push_back(sum);
            if(sum.first == s) ans++;
            ans %= MOD;
        }
    }

    cout << ans % MOD;
}