#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

const int MAX = 512, MOD = 1e9 + 7;
int a[MAX][MAX], dp[MAX][MAX], maxDP[MAX][MAX];
vector<pair<int, int>> sums;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    cin >> n >> m;

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= m; j++)
        {
            cin >> a[i][j];
        }
    }

    dp[n][m] = maxDP[n][m] = a[n][m];
    int ans = dp[n][m];
    for(int i = n; i >= 1; i--)
    {
        for(int j = m; j >= 1; j--)
        {
            if(i == n && j == m) continue;

            dp[i][j] = max(a[i][j], a[i][j] + max((i == n ? 0 : maxDP[i + 1][j]), (j == m ? 0 : maxDP[i][j + 1])));
            maxDP[i][j] = max(max((i == n ? 0 : maxDP[i + 1][j]), (j == m ? 0 : maxDP[i][j + 1])), dp[i][j]);
            ans += dp[i][j];
        }
    }

    cout << ans;
}