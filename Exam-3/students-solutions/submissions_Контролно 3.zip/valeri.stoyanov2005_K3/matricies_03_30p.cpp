#include <bits/stdc++.h>

using namespace std;
#define MAX 110

long long dp[MAX][MAX], r[MAX];

int main()
{
    int n;
    cin >> n;

    for (int i = 0; i <= n; i++)
        cin >> r[i];

    for (int i = 1; i < n; i++)
        dp[i][i + 1] = r[i - 1] * r[i] * r[i + 1];

    // int i = 1, j = 3;

    // while()

    for (int len = 3; len <= n; len++)
    {
        for (int i = 1; i <= n; i++)
        {
            int j = i + len - 1;

            // dp[i][j] = LLONG_MAX;

            // for (int k = i + 1; k < j; k++)
            // {
            // dp[i][j] = min({dp[i][j], dp[i][k], dp[k][j]});
            // dp[i][j] += r[i - 1] * r[j - 1] * r[j];

            // dp[i][j] = min(dp[i][k], dp[k][j]) + r[i - 1] * r[k] * r[j];

            dp[i][j] = min(dp[i][j - 1] + r[i - 1] * r[j - 1] * r[j], dp[i + 1][j] + r[i - 1] * r[i] * r[j]);
            // }
        }
    }

    cout << dp[1][n] << '\n';

    return 0;
}