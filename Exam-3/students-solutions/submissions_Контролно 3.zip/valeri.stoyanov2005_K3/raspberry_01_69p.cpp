// zad1
#include <bits/stdc++.h>

using namespace std;
#define MAX 550

int n, m;
int dp[MAX][MAX], table[MAX][MAX], dptemp[MAX][MAX];

void findMax(int x, int y)
{
    dp[x][y] = 0;

    int optimalValue = INT_MIN;
    for (int i = x; i <= n; i++)
    {
        for (int j = y; j <= m; j++)
        {
            optimalValue = max(optimalValue, dp[i][j]);
        }
    }

    dp[x][y] = optimalValue + table[x][y];
}

int main()
{
    cin >> n >> m;

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> table[i][j];

    dp[n][m] = table[n][m];

    for (int i = m - 1; i >= 1; i--)
    {
        dp[n][i] = 0;
        for (int j = i + 1; j <= m; j++)
            dp[n][i] = max(dp[n][i], dp[n][j]);
        dp[n][i] += table[n][i];
    }

    for (int i = n - 1; i >= 1; i--)
    {
        dp[i][m] = 0;
        for (int j = i + 1; j <= n; j++)
            dp[i][m] = max(dp[i][m], dp[j][m]);
        dp[i][m] += table[i][m];
    }

    for (int i = n - 1; i >= 1; i--)
    {
        for (int j = m - 1; j >= 1; j--)
        {
            findMax(i, j);
        }
    }

    long long finalSum = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            finalSum += dp[i][j];

    cout << finalSum << '\n';

    return 0;
}