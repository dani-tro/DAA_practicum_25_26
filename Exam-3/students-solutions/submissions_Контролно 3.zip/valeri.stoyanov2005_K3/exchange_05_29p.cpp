#include <bits/stdc++.h>

using namespace std;
#define MAXN 220
#define MAX 55000
#define MOD 1000000007

long long dp[MAX], a[MAXN], b[MAXN];

int main()
{
    int s, n;
    cin >> s >> n;

    for (int i = 1; i <= n; i++)
        cin >> a[i];

    for (int i = 1; i <= n; i++)
        cin >> b[i];

    dp[0] = 1;

    for (int i = 1; i <= n; i++)
    {
        int tempdp[MAX];
        for (int j = 0; j <= s; j++)
        {
            if (dp[j] != 0)
            {
                tempdp[j] = dp[j];
            }
        }

        for (int j = 0; j <= s; j++)
        {
            if (tempdp[j] != 0)
                for (int k = 1; k <= b[i]; k++)
                {
                    dp[j + k * a[i]] = (dp[j + k * a[i]] + 1) % MOD;
                }
        }
    }

    cout << dp[s] << '\n';

    return 0;
}