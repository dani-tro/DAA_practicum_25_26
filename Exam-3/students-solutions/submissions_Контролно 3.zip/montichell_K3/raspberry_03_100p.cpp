#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 505;
int a[MAXN][MAXN];
int dp[MAXN][MAXN];

signed main()
{
    int n, m;
    cin >> n >> m;

    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=m;j++)
        {
            cin >> a[i][j];
        }
    }

    int res = 0;

    for(int sum = n+m; sum >= 2; sum--)
    {
        for(int i=1; i<=min(n, sum-1); i++)
        {
            int j = sum - i;
            if(j>m)
                continue;
            dp[i][j] = max(dp[i+1][j], dp[i][j+1]);
            dp[i][j] = max(dp[i][j], dp[i+1][j] - a[i+1][j]);
            dp[i][j] = max(dp[i][j], dp[i][j+1] - a[i][j+1]);
            dp[i][j] = max(dp[i][j], 0ll);
            dp[i][j] += a[i][j];
            res += dp[i][j];
        }
    }

    // for(int i = 1; i<=n; i++)
    // {
    //     for(int j=1; j<=m; j++)
    //     {
    //         cout << dp[i][j] << " ";
    //     }
    //     cout << endl;
    // }

    cout << res << endl;    

    return 0;
}