#include <bits/stdc++.h>
using namespace std;

const int MAXN = 105;
int r[MAXN];
int dp[MAXN][MAXN];

int main()
{
    int n;
    cin >> n;

    for(int i=0; i<=n;i++)
    {
        cin >> r[i];
    }

    for(int diag=2; diag<=n; diag++)
    {
        for(int i=1; i<=n - diag + 1; i++)
        {
            int j = diag + i - 1;
            dp[i][j] = 1e9 + 5;
            for(int k=i; k<=j-1; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + r[i-1]*r[k]*r[j]);
            }
        }
    }

    cout << dp[1][n] << endl;


    return 0;
}