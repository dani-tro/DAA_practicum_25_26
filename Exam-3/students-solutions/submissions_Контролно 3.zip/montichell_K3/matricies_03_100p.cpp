#include <bits/stdc++.h>
using namespace std;

#define int long long

const int MAXN = 105;
int r[MAXN];
int dp[MAXN][MAXN];

signed main()
{
    int n;
    cin >> n;

    for(int i=0; i<=n;i++)
    {
        cin >> r[i];
    }

    for(int diag=2; diag<=n; diag++)
    {
        for(int j=diag; j<=n; j++)
        {
            int i = j - diag + 1;

            dp[i][j] = 1e15 + 5;
            for(int k=i; k<=j-1; k++)
            {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j] + r[i-1]*r[k]*r[j]);
            }
        }
    }

    cout << dp[1][n] << endl;


    return 0;
}