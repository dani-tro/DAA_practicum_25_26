#include <bits/stdc++.h>
using namespace std;

const int MAXN = 205;
const int MAXS = 50005;
const int mod = 1e9 + 7;
int val[MAXN];
int cnt[MAXN];

int dp[MAXN][MAXS];

int main()
{
    int s, n;
    cin >> s >> n;

    for(int i=1; i<=n; i++)
    {
        cin >> val[i];
    }

    for(int i=1; i<=n; i++)
    {
        cin >> cnt[i];
    }

    for(int j=0; j<=cnt[1] && j*val[1] <=s;j++)
    {
        dp[1][j * val[1]] = 1;
    }


    for(int i=2; i<=n; i++)
    {
        for(int v=0; v<=s; v++)
        {
            for(int j=0; j<=cnt[i]; j++)
            {
                if(v - j*val[i] >= 0)
                {
                    dp[i][v] = (dp[i][v] + dp[i-1][v - j*val[i]]) % mod;
                }
            }
        }
    }

    // for(int i=1; i<=n; i++)
    // {
    //     for(int v=1; v<=s; v++)
    //     {
    //         cout << dp[i][v] << " ";
    //     }
    //     cout << endl;
    // }

    cout << dp[n][s] << endl;

    return 0;
}