#include <bits/stdc++.h>
using namespace std;

#define MAX 510
int a[MAX][MAX];
int dp[MAX][MAX];

int main()
{
    int n, m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= m; j++)
        {
            cin >> a[i][j];
        }
    }

    int total = 0;
    dp[n][m] = a[n][m];
    total += dp[n][m];
    //cout << "i = " << n << " j = " << m << "dp = " << dp[n][m] << endl;
    int curr_max = dp[n][m];
    for(int i = m-1; i > 0; i--)
    {
        dp[n][i] = a[n][i];
        if(curr_max > 0)
        {
            dp[n][i] += curr_max;
        }
        curr_max = max(curr_max, dp[n][i]);
        total += dp[n][i];
        //cout << "i = " << n << " j = " << i << "dp = " << dp[n][i] << endl;
    }

    curr_max = dp[n][m];
    for(int i = n-1; i > 0; i--)
    {
        dp[i][m] = a[i][m];
        if(curr_max > 0)
        {
            dp[i][m] += curr_max;
        }
        curr_max = max(curr_max, dp[n][i]);
        total += dp[i][m];
        //cout << "i = " << i << " j = " << m << "dp = " << dp[i][m] << endl;
    }

    for(int i = n-1; i > 0; i--)
    {
        for(int j = m - 1; j > 0; j--)
        {
            dp[i][j] += a[i][j];
            int curr_max = a[n][m];
            for(int k = n; k >= i; k--)
            {
                for(int l = m; l >=j; l--)
                {
                    if(k == i && l == j)
                        break;
                    if(dp[k][l] > curr_max)
                        curr_max = dp[k][l];
                }
            }

            if(curr_max > 0)
                dp[i][j] += curr_max;
            
            total += dp[i][j];
            //cout << "i = " << i << " j = " << j << "dp = " << dp[i][j] << endl;
        }
    }

    cout << total << endl;

    return 0;
}