#include <bits/stdc++.h>
using namespace std;

#define MAX 210

long long s, n;

int main()
{
    cin >> s >> n;
    vector<long long> a(n+1);
    vector<long long> b(n+1);
    for(int i = 0; i < n; i++)
        cin >> a[i];

    for(int i = 0; i < n; i++)
        cin >> b[i];

    vector<long long> dp(s+1, -1);
    vector<long long> dp2(s+1, -1);
    dp[0] = 1;
    dp2[0] = 1;
    
    for(int i = 0; i < n; i++)
    {
        int max_coins = min(b[i], s/a[i]);
        for(int j = 0; j <= s; j++)
        {
            if(dp[j] >= 0)
            {
                for(int k = 1; k <= max_coins; k++)
                {
                    if(j+k*a[i] > s)
                        break;
                    if(dp[j+k*a[i]] == -1)
                        dp2[j+k*a[i]] = 0;
                    
                    dp2[j+k*a[i]] += dp[j];
                }
            }
        }
        for(int i = 0; i <= s; i++)
        {
            dp[i] = dp2[i];
        }
    }

        

    cout << dp[s] << endl;
    


    return 0;
}