#include<iostream>
#define MAXN 105
#define INF 1000000000000
using namespace std;
int input[MAXN];
int matrices[MAXN][2];
long long dp[MAXN][MAXN];
int main(){
    int n;
    cin>>n;
    for(int i=1; i<=n+1; i++){
        cin>>input[i];
        dp[i][i]=0;
    }
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            if(i!=j) dp[i][j] = INF;
        }
    }
    matrices[1][0] = input[1];
    for(int i=2; i<=n; i++){
        matrices[i][0] = matrices[i-1][1] = input[i];
    }
    matrices[n][1] = input[n+1];
    for(int i=1; i<n; i++){
        dp[i][i+1] = matrices[i][0]*matrices[i][1]*matrices[i+1][1]; 
    }
    for(int diff=2; diff<=n-1; diff++){
        for(int i=1; i+diff<=n; i++){
            for(int j=i; j<i+diff; j++){
                if(dp[i][i+diff]>dp[i][j]+dp[j+1][i+diff]+matrices[i][0]*matrices[j][1]*matrices[i+diff][1]){
                    dp[i][i+diff] = dp[i][j]+dp[j+1][i+diff]+matrices[i][0]*matrices[j][1]*matrices[i+diff][1];
                }
            }
        }
    }
    cout<<dp[1][n]<<endl;
    return 0;
}
