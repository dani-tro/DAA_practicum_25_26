#include<iostream>
#define MAXN 105
#define INF 100000000
using namespace std;
int input[MAXN];
int matrices[MAXN][2];
int dp[MAXN][MAXN];
int main(){
    int n;
    cin>>n;
    for(int i=1; i<=n+1; i++){
        cin>>input[i];
    }
    matrices[1][0] = input[1];
    for(int i=2; i<=n; i++){
        matrices[i][0] = matrices[i-1][1] = input[i];
    }
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
        dp[i][j] = INF;
        }
    }
    matrices[n][1] = input[n+1];
    for(int i=1; i<n; i++){
        dp[i][i+1] = matrices[i][0]*matrices[i][1]*matrices[i+1][1]; 
    }
    for(int diff=2; diff<=n-1; diff++){
        for(int i=1; i+diff<=n; i++){
            dp[i][i+diff] = min(dp[i][i+diff-1]+matrices[i][0]*matrices[i+diff][0]*matrices[i+diff][1],
                                dp[i+1][i+diff]+matrices[i][0]*matrices[i][1]*matrices[i+diff][1]);
        }
    }
    cout<<dp[1][n]<<endl;
    return 0;
}