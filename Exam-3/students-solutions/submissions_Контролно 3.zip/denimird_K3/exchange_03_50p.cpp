#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
#define MAXS 50005
#define MAXN 205
#define MOD 1000000007
int prev_dp[MAXS];
int curr_dp[MAXS];
int vals[MAXN];
int counts[MAXN];
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    int s, n;
    cin>>s;
    cin>>n;
    for(int i=1; i<=n; i++){
        cin>>vals[i];
    }
    for(int i=1; i<=n; i++){
        cin>>counts[i];
    }
    // vector<pair<int, int>> coins;
    // for(int i=0; i<=n; i++){
    //     coins.push_back({vals[i], counts[i]});
    // }
    // sort(coins.begin(), coins.end(), greater<int>());
    prev_dp[0] = 1;
    curr_dp[0] = 1;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=counts[i]; j++){
            for(int k=j*vals[i]; k<=s; k++){
                curr_dp[k] = (curr_dp[k]+prev_dp[k-j*vals[i]])%MOD;
            }
        }
        for(int l=0; l<=s; l++){
            prev_dp[l] = curr_dp[l];
        }
    }
    cout<<curr_dp[s]<<'\n';
}