#include<iostream>
using namespace std;
#define MAXS 50005
#define MAXN 205
#define MOD 1000000007
int prev_dp[MAXS];
int curr_dp[MAXS];
int vals[MAXN];
int counts[MAXN];
int main(){
    int s, n;
    cin>>s;
    cin>>n;
    for(int i=1; i<=n; i++){
        cin>>vals[i];
    }
    for(int i=1; i<=n; i++){
        cin>>counts[i];
    }
    prev_dp[0] = 1;
    curr_dp[0] = 1;
    for(int i=1; i<=n; i++){
        for(int l=0; l<=s; l++){
            curr_dp[l] = prev_dp[l];
        }
        for(int j=1; j<=counts[i]; j++){
            for(int k=1; k<=s; k++){
                if(k>=j*vals[i]) curr_dp[k] = (curr_dp[k]+prev_dp[k-j*vals[i]])%MOD;
            }
        }
        for(int l=0; l<=s; l++){
            prev_dp[l] = curr_dp[l];
        }
    }
    cout<<curr_dp[s]<<endl;
}