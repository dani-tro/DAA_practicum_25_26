#include<iostream>
#include<algorithm>
using namespace std;
#define MAXN 505
#define MININF -100000000000
long long ans[MAXN][MAXN];
int input[MAXN][MAXN];
long long max_pleasure[MAXN][MAXN];
int main(){
    int n, m;
    cin>>n>>m;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=m; j++){
            cin>>input[i][j];
            ans[i][j] = max_pleasure[i][j] = MININF;
        }
    }
    for(int i=1; i<=n; i++) max_pleasure[i][m+1] = MININF;
    for(int i=1; i<=m; i++) max_pleasure[n+1][i] = MININF;
    ans[n][m] = max_pleasure[n][m] = input[n][m];
    for(int j=m; j>=1; j--){
        for(int i=n; i>=1; i--){
            if(ans[i][j]!=MININF) continue;
            ans[i][j] = max(input[i][j]+max_pleasure[i+1][j], input[i][j]+max_pleasure[i][j+1]);
            if(input[i][j]>ans[i][j]) ans[i][j] = input[i][j];
            max_pleasure[i][j] = max(max_pleasure[i+1][j], max_pleasure[i][j+1]);
            if(ans[i][j]>max_pleasure[i][j]) max_pleasure[i][j] = ans[i][j];
        }
    }
    long long sum = 0;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=m; j++){
            sum+=ans[i][j];
        }
    }
    cout<<sum<<endl;
    return 0;
}