#include <iostream>
using namespace std;
#define int long long
#define endl "\n"

const int maxn = 500 + 4;
const int INF = 9999999999999;
int a[maxn][maxn];
int dp[maxn][maxn];
int otg[maxn][maxn];
int n, m;

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[i][j];
        }
    }

    for (int i = 0; i <= n+1; i++) {
        for (int j = 0; j <= m+1; j++) {
            dp[i][j] = 0;
        }
    }

    int otgg = 0;
    for (int i = n; i >= 1; i--) {
        for (int j = m; j >= 1; j--) {
            int md = max(0ll, max(dp[i + 1][j], dp[i][j + 1]));
            if (i == n && j == m) dp[i][j] = a[i][j];
            else dp[i][j] = max(md, md + a[i][j]);
            otgg += md + a[i][j];
            otg[i][j] = md + a[i][j];
        }
    }

    /*cout << endl;
    
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cout << otg[i][j] << " ";
        }
        cout << endl;
    }*/

    cout << otgg << endl;

    return 0;
}