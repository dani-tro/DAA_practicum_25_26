#include <iostream>
#include <vector>
using namespace std;
#define int long long
#define endl "\n"

const int maxn = 200 + 4;
const int maxs = 50000 + 4;
const int INF = 9999999999999;
const int MOD = 1000000000 + 7;
int a[maxn], b[maxn];
int dp[maxs];
int n, s;

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> s >> n;
    for (int i = 0; i < n; i++) cin >> a[i]; // value
    for (int i = 0; i < n; i++) cin >> b[i]; // broj


    for (int i = 0; i <= b[0]; i++) {
        dp[i * a[0]] = 1;
    }

    for (int i = 1; i < n; i++) {
        for (int su = s; su >= 0; su--) {
            //dp[su] = 0;
            for (int br = 1; br <= b[i]; br++) {
                if (su - br * a[i] < 0) break;
                dp[su] = (dp[su] + dp[su - br * a[i]]) % MOD;
            }
        }
    }

    cout << dp[s] << endl;

    return 0;
}