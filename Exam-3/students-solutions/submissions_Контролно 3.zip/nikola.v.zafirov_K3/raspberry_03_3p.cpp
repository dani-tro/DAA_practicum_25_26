#include <iostream>
using namespace std;
#define int long long
#define endl "\n"

const int maxn = 500 + 4;
int a[maxn][maxn];
int dp[maxn][maxn];
int n, m;

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[n - i + 1][j];
        }
    }

    for (int i = n; i >= 1; i--) {
        for (int j = m; j >= 1; j--) {
            dp[i][j] = max(dp[i + 1][j], dp[i][j + 1]) + a[i][j];
        }
    }

    int otg = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            otg += dp[n][m];
        }
    }

    cout << otg << endl;

    return 0;
}