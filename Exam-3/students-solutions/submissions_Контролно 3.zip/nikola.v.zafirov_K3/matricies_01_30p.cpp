#include <iostream>
#include <vector>
using namespace std;
#define int long long
#define endl "\n"

const int maxn = 200 + 4;

const int INF = 9999999999999;

int n;
int a[102];
int mem[102][102];

int shitrec(int s, int f) {
    if (f == s + 1) return 0;
    if (mem[s][f] != 0) return mem[s][f];

    int best = INF;
    for (int mid = s + 1; mid < f; mid++) {
        best = min(best, shitrec(s, mid) + shitrec(mid, f) + a[s] * a[mid] * a[f]);
    }
    return best;
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n;
    for (int i = 0; i < n+1; i++) cin >> a[i];

    cout << shitrec(0, n);

    return 0;
}