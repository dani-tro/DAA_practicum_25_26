#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

int maxSum(int n, int m, std::vector<std::vector<int>> &A){
    int input;
    std::vector<std::vector<int>> right, diag, bot;
    std::vector<int> result;

    for(int i = 0; i < n; i++)
        right.push_back({});

    for(int i = 1; i < m; i++){
        std::cin >> input;
        right[i].push_back(input);
    }

    for(int i = 1; i < n; i++)
        bot.push_back({});

    for(int i = 0; i < m; i++){
        std::cin >> input;
        bot[i].push_back(input);
    }

    for(int i = 1; i < n; i++)
        right.push_back({});

    for(int i = 1; i < m; i++){
        std::cin >> input;
        right[i].push_back(input);
    }

    int val;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; i++){
            val = A[n][m] + std::max(maxSum(n, m - 1, right),
                                     maxSum(n - 1, m, bot),
                                     maxSum(n - 1, m - 1, diag));
        result.push_back(val);
        }
    }

    int sum = 0;
    for(int i = 0; i < result.size(); i++)
        sum += result[i];
    return sum;
}

int main(){
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> A;
    for(int i = 0; i < n; i++)
        A.push_back({});

    int input;
    for(int i = 0; i < m; i++){
        std::cin >> input;
        A[i].push_back(input);
    }

    std::cout << maxSum(n, m, A) << std::endl;

    return 0;
}