#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

int exchange(int s, int n, std::vector<int> A, std::vector<int> B){
    return 0;
}

int main(){
    int s, n;
    std::cin >> s >> n;

    int input;
    std::vector<int> A, B;
    for(int i = 0; i < n; i++){
        std::cin >> input;
        A.push_back(input);
    }

    for(int i = 0; i < n; i++){
        std::cin >> input;
        B.push_back(input);
    }
    
    std::cout << exchange(s, n, A, B) << std::endl;

    return 0;
}