#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>


long long matrices2(int n, std::vector<int> &A){
    if(A.size() < 3)
        return -1;

    if(A.size() == 3)
        return A[0] * A[1] * A[2];

    int index = -1;
    int max = -1;
    long long minProd = 9223372036854775807;
    std::vector<int> result;
    
    for(int i = 1; i < A.size() - 1; i++){
        if((max == A[i] && minProd > A[i - 1] * A[i] * A[i + 1]) || max < A[i]){
            max = A[i];
            minProd = A[i - 1] * A[i] * A[i + 1];
            index = i;
        }
    }

    for(int i = 0; i < A.size(); i++){
        if(i == index){
            result.push_back(A[i + 1]);
            i++;
        }
        else
            result.push_back(A[i]);
    }

    return minProd + matrices2(n - 1, result);
}

int main(){
    int n;
    std::cin >> n;

    std::vector<int> A;
    int val;
    for(int i = 0; i < n + 1; i++){
        std::cin >> val;
        A.push_back(val);
    }
    std::cout << matrices2(n, A) << std::endl;
    return 0;
}