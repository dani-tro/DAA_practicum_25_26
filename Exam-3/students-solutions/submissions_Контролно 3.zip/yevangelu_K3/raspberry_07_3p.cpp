#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

int maxSum(int n, int m, std::vector<std::vector<int>> &A){
    std::vector<std::vector<int>> right, diag, bot;
    std::vector<int> result;

    if(n == 0 || m == 0)
        return 0;

    if(n == 1 && m == 1);
        return A[0][0];

    for(int i = 0; i < n; i++)
        right.push_back({});

    for(int i = 0; i < n; i++)
        for(int j = 1; j < m; j++)
            right[i].push_back(A[i][j]);

    for(int i = 1; i < n; i++)
        bot.push_back({});

    for(int i = 1; i < n; i++)
        for(int j = 0; j < m; j++)
            bot[i].push_back(A[i][j]);

    for(int i = 1; i < n; i++)
        diag.push_back({});

    for(int i = 1; i < n; i++)
        for(int j = 1; j < m; j++)
            diag[i].push_back(A[i][j]);

    int val;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; i++){
            val = A[n][m] + std::max(maxSum(n, m - 1, right), std::max(
                                     maxSum(n - 1, m, bot),
                                     maxSum(n - 1, m - 1, diag)));
            result.push_back(val);
        }
    }

    int sum = 0;
    for(int i = 0; i < result.size(); i++)
        sum += result[i];
    return sum;
}

int main(){
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> A;
    for(int i = 0; i < n; i++)
        A.push_back({});

    int input;
    for(int i = 0; i < m; i++){
        std::cin >> input;
        A[i].push_back(input);
    }

    std::cout << maxSum(n, m, A) << std::endl;

    return 0;
}