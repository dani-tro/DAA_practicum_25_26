#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

struct minMul{
    int min;
    int ind;
};

int matrices(int n, std::vector<int> &A){
    int start = 0;
    int end = n;

    std::vector<int> result;
    minMul element;
    element.min = 2147483647;
    element.ind = -1;

    if(A.size() < 3)
        return 0;

    if(A.size() == 3)
        return A[0] * A[1] * A[2];

    for(int i = 0; i < n - 2; i++){
        if(element.min > A[i] * A[i + 1] * A[i + 2]){
            element.min = A[i] * A[i + 1] * A[i + 2];
            element.ind = i;
        }
    }

    for(int i = 0; i < A.size(); i++){
        if(i == element.ind){
            result.push_back(A[i]);
            result.push_back(A[i + 2]);
            i += 2;
        }
        else
            result.push_back(A[i]);
    }
    return element.min + matrices(n - 1, result);
}

int main(){
    int n;
    std::cin >> n;

    std::vector<int> A;
    int val;
    for(int i = 0; i < n + 1; i++){
        std::cin >> val;
        A.push_back(val);
    }
    std::cout << matrices(n, A) << std::endl;
    return 0;
}