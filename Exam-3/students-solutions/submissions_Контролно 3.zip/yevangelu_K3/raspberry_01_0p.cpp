#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

int maxSum(int n, int m, std::vector<std::vector<int>> A){
    std::vector<int> curr;
    
    int curr_sum;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; i++){
            
        }
    }

    return 0;
}

int main(){
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> A;
    for(int i = 0; i < n; i++)
        A.push_back({});

    int input;
    for(int i = 0; i < m; i++){
        std::cin >> input;
        A[i].push_back(input);
    }

    std::cout << maxSum(n, m, A);

    return 0;
}