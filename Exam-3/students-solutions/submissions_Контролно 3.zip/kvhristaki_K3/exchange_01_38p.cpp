#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
// #include <priority_queue>
#include <stack>

using namespace std;
const int maxN = 205, MOD = 1e9 + 7, maxS = 50015;
int S, N, a[maxN], b[maxN];
int dp[maxN][maxS];
long long ans;

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> S >> N;

    for (int i = 1; i <= N; i++)
        cin >> a[i];
    for (int i = 1; i <= N; i++)
        cin >> b[i];

    for(int i = 1; i <= N; i++) dp[i][0] = 1;
    for(int k = 1; k <= b[1] && k * a[1] <= S; k++)
    {
        dp[1][k * a[1]] = 1;
    }

    for (int i = 2; i <= N; i++)
    {
        for (int j = 1; j <= S; j++)
        {
            dp[i][j] = dp[i - 1][j];

            for (int k = 1; k <= b[i] && k * a[i] <= j; k++)
            {
                if (j - k * a[i] >= 0)
                {
                    dp[i][j] += dp[i - 1][j - k * a[i]] % MOD;
                }
            }
        }
    }

    cout << dp[N][S] << "\n";

    // for(int i = 1; i <= N; i++)
    // {
    //     for(int j = 1; j <= S; j++)
    //     {
    //         cout << dp[i][j] << " ";
    //     }
    //     cout << "\n";
    // }

    return 0;
}