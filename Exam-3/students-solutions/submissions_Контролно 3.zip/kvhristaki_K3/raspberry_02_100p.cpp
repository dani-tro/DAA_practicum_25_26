#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
// #include <priority_queue>
#include <stack>

using namespace std;
const int maxN = 505;
int a[maxN][maxN], N, M;
long long ans;
pair<int, pair<int, int>> dp[maxN][maxN];

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> N >> M;

    for (int i = 1; i <= N; i++)
    {
        for (int j = 1; j <= M; j++)
            cin >> a[i][j];
    }

    dp[N][M] = {a[N][M], {0, 0}};

    for (int i = N - 1; i > 0; i--)
    {
        if (a[i + 1][M] > 0)
        {
            dp[i][M] = {dp[i + 1][M].first + a[i][M], {i + 1, M}};
        }
        else
        {
            auto c = dp[i + 1][M].second;
            dp[i][M] = {dp[c.first][c.second].first + a[i][M], c};
        }
    }
    for (int i = M - 1; i > 0; i--)
    {
        if (a[N][i + 1] > 0)
        {
            dp[N][i] = {dp[N][i + 1].first + a[N][i], {N, i + 1}};
        }
        else
        {
            auto c = dp[N][i + 1].second;
            dp[N][i] = {dp[c.first][c.second].first + a[N][i], c};
        }
    }

    pair<int, pair<int, int>> temp1, temp2;
    for (int i = N - 1; i > 0; i--)
    {
        for (int j = M - 1; j > 0; j--)
        {
            if (a[i + 1][j] > 0)
            {
                temp1 = {dp[i + 1][j].first + a[i][j], {i + 1, j}};
            }
            else
            {
                auto c = dp[i + 1][j].second;
                temp1 = {dp[c.first][c.second].first + a[i][j], c};
            }

            if (a[i][j + 1] > 0)
            {
                temp2 = {dp[i][j + 1].first + a[i][j], {i, j + 1}};
            }
            else
            {
                auto c = dp[i][j + 1].second;
                temp2 = {dp[c.first][c.second].first + a[i][j], c};
            }
            
            // if(i < 2 || j < 2)
            // {
            //     cout << i << " " << j << ":\n";
            //     cout << a[i][j] << "\n";
            //     cout << temp1.first << " {" << temp1.second.first << "," << temp1.second.second << "}\n";
            //     cout << temp2.first << " {" << temp2.second.first << "," << temp2.second.second << "}\n";
            
            // }

            if(temp1.first > temp2.first) dp[i][j] = temp1;
            else dp[i][j] = temp2;
        }
    }

    for (int i = 1; i <= N; i++)
    {
        for (int j = 1; j <= M; j++)
        {
            ans += dp[i][j].first;
        }
    }

    cout << ans << "\n";

    // for (int i = 1; i <= N; i++)
    // {
    //     for (int j = 1; j <= M; j++)
    //     {

    //         cout << dp[i][j].first << " {" << dp[i][j].second.first << "," << dp[i][j].second.second << "} ";
    //     }
    //     cout << "\n";
    // }

    return 0;
}