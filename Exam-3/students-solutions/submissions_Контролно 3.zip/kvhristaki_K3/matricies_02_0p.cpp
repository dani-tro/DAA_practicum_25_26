#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
//#include <priority_queue>
#include <stack>

#define int long long

using namespace std;
const int maxN = 105;
int N, r[maxN];
int dp[maxN][maxN];

signed main()
{
    // ios_base::sync_with_stdio(false);
	// cin.tie(nullptr);
	// cout.tie(nullptr);

    cin >> N;
    for(int i = 0; i <= N; i++) cin >> r[i];
    while(N > 10) r[N + 2] += 1;

    for(int k = 1; k < N; k++)
    {
        for(int i = 1; i + k <= N; i++)
        {
            int j = i + k;
            dp[i][j] = min(dp[i + 1][j] + r[i-1]*r[i]*r[j], dp[i][j - 1] + r[i - 1]*r[j - 1]*r[j]);
        }
    }

    cout << dp[1][N] << "\n";

    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= N; j++)
        {
            cout << dp[i][j] << " ";
        }
        cout << "\n";
    }
    
    return 0;
}