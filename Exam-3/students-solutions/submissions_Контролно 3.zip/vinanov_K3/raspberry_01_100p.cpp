#include <bits/stdc++.h>
using namespace std;
// const int maxn = 110;

// long long arr[maxn];
// long long dp[maxn][maxn];

// int main(){
//     ios_base::sync_with_stdio(false);
// 	cin.tie(nullptr);
// 	cout.tie(nullptr);

//     int n;
//     cin >> n;

//     for(int i = 1; i<= n + 1; ++i){
//         cin >> arr[i];
//     }

//     for(int i = 1; i<= n + 1; ++i){
//         for(int j = i; j<= n + 1; ++j){
//             for(int k = i; k<= j; ++k){
//                 dp[i][j] = min() + arr[];
//             }
//         }
//     }

//     for(int i = 1; i<= n + 1; ++i){
//         for(int j = 1; j<= n + 1; ++j){
//             cout << arr[i][j] << " ";
//         }
//         cout << endl;
//     }

    



// }

const int maxn = 550;

long long table[maxn][maxn];
long long dp[maxn][maxn];

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int n, m;
    cin >> n >> m;


    for(int i = 0; i<= n +1; ++i){
        for(int j = 0; j<= m + 1; ++j){
            dp[i][j] = -1e8;
        }
    }

    for(int i = 1; i<= n; ++i){
        for(int j = 1; j<= m; ++j){
            cin >> dp[i][j];
        }
    }

    long long sum = 0;

    for(int i = n; i > 0; --i){
        for(int j = m; j > 0; --j){
            //cout << dp[i][j] << " " << dp[i][j] + dp[i+1][j]<< " " <<  dp[i][j] +dp[i][j+1] << "\n";
            long long max_bottom = max(dp[i+1][j],dp[i][j+1]); 
            sum += max(dp[i][j],dp[i][j] + max_bottom);
            dp[i][j] = max({dp[i][j],dp[i][j] + max_bottom, max_bottom});
        }
    }

 
// cout << "---------------------"  << endl;

//     for(int i = 1; i<= n; ++i){
//         for(int j = 1; j<= m; ++j){
//             cout << dp[i][j] << " ";
//         }
//         cout << endl;
    
//     }

    cout << sum << "\n";


    //cout << dp[n][m] << " " << dp[n][m] + dp[n+1][m]<< " " <<  dp[n][m] +dp[n][m+1];

}