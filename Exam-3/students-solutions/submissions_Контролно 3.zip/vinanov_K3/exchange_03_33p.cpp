#include <bits/stdc++.h>
using namespace std;


const int maxS = 51000;
const int maxN = 210;
const int MOD = 1e9 + 7;

int dp[maxS];
int a[maxN];
int b[maxN];

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int s,n;
    cin >> s >> n;

    for(int i = 1; i<= n; ++i) cin >> a[i];
    for(int i = 1; i<= n; ++i) cin >> b[i];

    dp[0] = 1;

    for(int i = 1; i<= n; ++i){
        // for(int j = 1; j <= b[i]; ++j){
        //     for(int t = s; t >= 0; --t){
        //         if(dp[t] != 0 && t + a[i]*j <= s){
        //             ++dp[t + a[i]];
        //         }
        //     }
        // }

        for(int t = s; t >= 0; --t){
            if(dp[t] !=0){
                for(int j = 1; j <= b[i]; ++j){
                    if(t + a[i]*j <= s){
                        dp[t + a[i]*j] = (dp[t + a[i]*j] + 1) % MOD;
                    }
                }
            }
        }
    }

    //for(int i = 1; i<= s; ++i) cout << dp[i] << " ";

    cout << dp[s];
    
}
