#include <bits/stdc++.h>
using namespace std;
// const int maxn = 110;

// long long arr[maxn];
// long long dp[maxn][maxn];

// int main(){
//     ios_base::sync_with_stdio(false);
// 	cin.tie(nullptr);
// 	cout.tie(nullptr);

//     int n;
//     cin >> n;

//     for(int i = 1; i<= n + 1; ++i){
//         cin >> arr[i];
//     }

//     for(int i = 1; i<= n + 1; ++i){
//         for(int j = i; j<= n + 1; ++j){
//             for(int k = i; k<= j; ++k){
//                 dp[i][j] = min() + arr[];
//             }
//         }
//     }

//     for(int i = 1; i<= n + 1; ++i){
//         for(int j = 1; j<= n + 1; ++j){
//             cout << arr[i][j] << " ";
//         }
//         cout << endl;
//     }

    



// }

const int maxS = 51000;
const int maxN = 210;


int dp[maxS];
int a[maxN];
int b[maxN];

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int s,n;
    cin >> s >> n;

    for(int i = 1; i<= n; ++i) cin >> a[i];
    for(int i = 1; i<= n; ++i) cin >> b[i];

    for(int i = 1; i<= n; ++i){
        for(int j = 1; j <= b[i]; ++j){
            for(int t = s; t > 0; --t){
                if(t + a[i] <= s){
                    ++dp[t + a[i]];
                }
            }
        }
    }

    cout << dp[s];
    
}


