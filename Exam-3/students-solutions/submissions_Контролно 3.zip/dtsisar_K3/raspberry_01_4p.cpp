#include <iostream>
#include <algorithm>
#include <climits>

using namespace std;
#define int long long

const int MAX = 2005;

int dp[MAX][MAX];
int n, m;
int a[MAX][MAX];

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m;

	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j) {
			cin >> a[i][j];
		}
	}

	

	for (int i = n; i >= 1; i--) {
		for (int j = m; j >= 1; j--) {
			dp[i][j] = a[i][j];
			int sum = 0;
			for (int k = i; k <= n; ++k) {
				for (int p = j; p <= m; ++p) {
					int maxi = -1, maxj = -1, max = -INT_MAX;

					if (k + 1 <= n) {
						max = dp[k + 1][p];
						maxi = k + 1;
						maxj = p;
					}

					if (p + 1 <= m) {
						if (max < dp[k][p + 1]) {
							max = dp[k][p + 1];
							maxi = k;
							maxj = p + 1;
						}
					}

					if (k + 1 <= n && p + 1 <= m) {
						if (max < dp[k + 1][p + 1]) {
							max = dp[k + 1][p + 1];
							maxi = k + 1;
							maxj = p + 1;
						}
					}
					if (maxi >= 0 && maxj >= 0) {
						k = maxi;
						p = maxj;
						if (max > 0) {
							sum += max;
							dp[i][j] += max;

							max == -INT_MAX;
						}
					}
				}
			}

			
		}
	}
	int sum = 0;

	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j) {
			sum += dp[i][j];
		}
	}
	cout << sum << endl;

}
