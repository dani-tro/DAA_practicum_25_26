#include <bits/stdc++.h>

using namespace std;

const int maxn = 105;
long long dp[maxn][maxn];
long long a[maxn];

int main()
{
    int n;
    cin >> n;
    for (int i = 0; i <= n; ++i)
    {
        cin >> a[i];
    }

    for (int i = 0, j = 1; j <= n; ++i, ++j)
    {
        dp[i][j] = LLONG_MAX;
        dp[i][i] = LLONG_MAX;
    }

    for (int i = 0, j = 2; j <= n; ++i, ++j)
        dp[i][j] = a[i] * a[i + 1] * a[i + 2];

    for (int dist = 3; dist <= n; ++dist)
    {
        for (int i = 0, j = i + dist; j <= n; ++i, ++j)
        {
            dp[i][j] = min(dp[i + 1][j] + a[i] * a[i + 1] * a[j], dp[i][j - 1] + a[i] * a[j - 1] * a[j]);
        }
    }
    cout << dp[0][n];



    return 0;
}
