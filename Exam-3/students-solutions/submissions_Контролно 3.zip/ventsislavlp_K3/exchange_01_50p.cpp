#include <bits/stdc++.h>

using namespace std;

const int maxs = 5e4 + 3;
const int maxn = 202;

long long dp[maxn][maxs];
long long prefix[maxn][maxs];
const long long mod = 1e9 + 7;

int main()
{
    int s;
    cin >> s;
    int n;
    cin >> n;
    int a[n + 1], b[n + 1];
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
    }
    for (int i = 1; i <= n; ++i)
    {
        cin >> b[i];
    }

    for (int i = 0; i <= n; ++i) dp[i][0] = 1;


    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= s; ++j)
        {
            for (int k = 0; k <= b[i]; ++k)
            {
                if (j - k * a[i] < 0) continue;
                dp[i][j] += dp[i - 1][j - k * a[i]];
                dp[i][j] %= mod;
            }
        }
    }
    cout << dp[n][s] << '\n';

    return 0;
}
