#include <bits/stdc++.h>

using namespace std;

const int mod = 1e9 + 7;
const int maxn = 505;

long long a[maxn][maxn];
long long dp[maxn][maxn];
long long maxx[maxn][maxn];

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
        {
            cin >> a[i][j];
        }
    }

    long long ans = 0;
    for (int i = n; i >= 1; --i)
    {
        for (int j = m; j >= 1; --j)
        {
            dp[i][j] = max(maxx[i + 1][j], maxx[i][j + 1]);
            dp[i][j] = max(dp[i][j], maxx[i + 1][j + 1]);
            if (dp[i][j] < 0) dp[i][j] = (dp[i][j] + mod + a[i][j]) % mod;
            else dp[i][j] = (dp[i][j] + a[i][j]) % mod;
            if (ans < 0 || dp[i][j] < 0) ans = (ans + mod + dp[i][j]) % mod;
            else ans = (ans + dp[i][j]) % mod;
            maxx[i][j] = max(maxx[i + 1][j], maxx[i][j + 1]);
            maxx[i][j] = max(maxx[i][j], maxx[i + 1][j + 1]);
            maxx[i][j] = max(maxx[i][j], dp[i][j]);
        }
    }
    cout << ans << '\n';




    return 0;
}
