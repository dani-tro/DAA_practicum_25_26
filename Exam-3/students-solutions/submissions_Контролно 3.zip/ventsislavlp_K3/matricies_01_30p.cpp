#include <bits/stdc++.h>

using namespace std;

const int maxn = 105;
long long dp[maxn][maxn];
int a[maxn];

long long rec(int l, int r)
{
    if (dp[l][r]) return dp[l][r];
    if (r - l == 2)
    {
        dp[l][r] = a[l] * a[l + 1] * a[l + 2];
        return dp[l][r];
    }
    dp[l][r] = min(rec(l + 1, r) + a[l] * a[l + 1] * a[r], rec(l, r - 1) + a[l] * a[r - 1] * a[r]);
    return dp[l][r];
}

int main()
{
    int n;
    cin >> n;
    for (int i = 0; i <= n; ++i)
    {
        cin >> a[i];
    }
    cout << rec(0, n) << '\n';





    return 0;
}
