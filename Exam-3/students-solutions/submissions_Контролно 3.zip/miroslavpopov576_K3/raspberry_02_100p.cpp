#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

int const MAX=500;
int n,m;
int grid[501][501];
int dp[501][501];
bool visited[501][501];
int values[501][501];
long long ans;

int solve(int i, int j){
    if(visited[i][j]) return dp[i][j];
    visited[i][j]=true;

    if(i+1<n && j+1<m){
        if(grid[i][j]<0){
            dp[i][j]=max(max(max(solve(i+1, j), solve(i, j+1)), solve(i+1, j+1)), 0);
        }
        else dp[i][j]=max(max(max(solve(i+1, j), solve(i, j+1)), solve(i+1, j+1)), 0)+grid[i][j];
        values[i][j]=max(max(max(solve(i+1, j), solve(i, j+1)), solve(i+1, j+1)), 0)+grid[i][j];
    }
    else if(i+1<n){
        if(grid[i][j]<0){
            dp[i][j]=max(solve(i+1, j), 0);
        }
        else dp[i][j]=max(solve(i+1, j), 0)+grid[i][j];
        values[i][j]=max(solve(i+1, j), 0)+grid[i][j];
    }
    else if(j+1<m){
        if(grid[i][j]<0){
            dp[i][j]=max(solve(i, j+1), 0);
        }
        else dp[i][j]=max(solve(i, j+1), 0)+grid[i][j];
        values[i][j]=max(solve(i, j+1), 0)+grid[i][j];
    }

    return dp[i][j];
}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr);

    cin >> n >> m;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            cin >> grid[i][j];
            dp[i][j]=-1;
            visited[i][j]=false;
            values[i][j]=0;
        }
    }
    values[n-1][m-1]=grid[n-1][m-1];
    dp[n-1][m-1]=grid[n-1][m-1];
    solve(0, 0);

    ans=0;

    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            ans+=values[i][j];
        }
    }

    cout << ans << endl;

    
}