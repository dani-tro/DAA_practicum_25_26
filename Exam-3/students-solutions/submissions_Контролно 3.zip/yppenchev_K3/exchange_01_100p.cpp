#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 200;
const int MAXS = 50000;
const int MOD = 1e9 + 7;

int a[MAXN + 5], b[MAXN + 5];
long long dp[MAXN + 5][MAXS + 5];

int main()
{
	ios :: sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	int s, n;
	cin >> s >> n;

	for (int i = 1; i <= n; ++ i)
	{
		cin >> a[i];
	}

	for (int i = 1; i <= n; ++ i)
	{
		cin >> b[i];
	}

	dp[0][0] = 1;
	for (int i = 1; i <= n; ++ i)
	{
		for (int j = 0; j <= s; ++ j)
		{
			dp[i][j] = dp[i - 1][j];
			if (j >= a[i])
			{
				dp[i][j] += dp[i][j - a[i]];
				dp[i][j] %= MOD;
				if (j >= (b[i] + 1) * a[i])
				{
					dp[i][j] -= dp[i - 1][j - (b[i] + 1) * a[i]];
					dp[i][j] %= MOD;
				}
			}
		}
	}
	cout << (dp[n][s] + MOD) % MOD << endl;

	return 0;
}