#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 100;
const long long INF = 1e18;

int r[MAXN + 5];
long long dp[MAXN + 5][MAXN + 5];

int main()
{
	ios :: sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	int n;
	cin >> n;

	for (int i = 0; i <= n; ++i)
	{
		cin >> r[i];
	}

	for (int i = 1; i <= n; ++ i)
	{
		dp[i][i] = 0;
	}

	for (int d = 1; d < n; ++ d)
	{
		for (int i = 1; i <= n - d; ++ i)
		{
			int j = i + d;
			dp[i][j] = INF;
			for (int k = i; k < j; ++ k)
			{
				dp[i][j] = min(dp[i][j], dp[i][k] + dp[k + 1][j] + 1ll * r[i - 1] * r[k] * r[j]);
			}
		}
	}
	cout << dp[1][n] << endl;

	return 0;
}