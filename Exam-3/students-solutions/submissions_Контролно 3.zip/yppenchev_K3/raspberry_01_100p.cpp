#include <iostream>
#define endl '\n'
using namespace std;

const int MAX = 500;
const int INF = 1e18;

int a[MAX + 5][MAX + 5];
long long dp[MAX + 5][MAX + 5];
long long dp2[MAX + 5][MAX + 5];

int main()
{
	ios :: sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	int n, m;
	cin >> n >> m;

	for (int i = 1; i <= n; ++ i)
	{
		for (int j = 1; j <= m; ++ j)
		{
			cin >> a[i][j];
		}
	}

	long long ans = 0;
	for (int i = n; i >= 1; -- i)
	{
		for (int j = m; j >= 1; -- j)
		{
			dp[i][j] = a[i][j] + max(dp2[i + 1][j], dp2[i][j + 1]);
			dp2[i][j] = max(max(dp2[i + 1][j], dp2[i][j + 1]), dp[i][j]);
			ans += dp[i][j];
		}
	}
	cout << ans << endl;

	return 0;
}