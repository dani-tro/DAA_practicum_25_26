#include <bits/stdc++.h>
using namespace std;

long long dp[101][101], n, arr[101];

long long f(long long l, long long r){
    if (l == r - 1) return 0;
    if (dp[l][r] != -1)return dp[l][r];

    dp[l][r] = 1e10;
    for (int t = l + 1; t < r; t++){
        dp[l][r] = min(dp[l][r], f(l, t) + f(t, r) + arr[l]*arr[t]*arr[r]);
    }
   // cout << l << " " << r << ": " << dp[l][r] << endl;
    return dp[l][r];
}
int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    memset(dp, -1, sizeof(dp));

    cin >> n;
    for (int i = 0; i <= n; i++){
        cin >> arr[i];
    }

    cout << f(0, n) << endl;
/*
    for (int i = 0; i < n; i++){
        for (int j = 1; j <=n; j++){
            cout << dp[i][j] << ' ';
        }
        cout << endl;
    }*/
return 0;
}
