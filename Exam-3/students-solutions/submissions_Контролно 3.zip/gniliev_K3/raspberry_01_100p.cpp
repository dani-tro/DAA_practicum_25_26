#include <bits/stdc++.h>
using namespace std;

int maxAll[501][501];
int n, m, table[501][501];

int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m;
    for (int i = 0; i < n ; i++){
        for (int j = 0; j < m; j++){
            cin >> table[i][j];
        }
    }
    for (int i = n - 1; i >= 0; i--){
        for (int j = m - 1; j >= 0; j--){
            int curr = table[i][j] > 0 ? table[i][j] : 0;
            maxAll[i][j] = max(maxAll[i][j + 1], maxAll[i + 1][j]) + curr;
           /* if (i + j == 0) {
                cout << maxAll[i + 1][j + 1] << " " <<  maxRow[i][j + 1] << " " <<  maxCol[i + 1][j]<< endl;
            }
                maxRow[i][j] = maxRow[i][j + 1] + curr;
                maxCol[i][j] = maxCol[i + 1][j] + curr;*/
        }
    }
    long long sum = 0;
    for (int i = 0; i < n ; i++){
        for (int j = 0; j < m; j++){
            sum += maxAll[i][j];
            if (table[i][j] < 0)sum += table[i][j];
        }
    }
    cout << sum << endl;
return 0;
}

