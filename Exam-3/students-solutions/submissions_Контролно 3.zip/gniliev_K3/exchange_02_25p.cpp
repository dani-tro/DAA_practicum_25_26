#include <bits/stdc++.h>
using namespace std;
long long mod = 1e9+7;
long long dp[200][50000], n, s, coun[200], value[200];

long long f(long long pos, long long sum){
    if (sum < 0)return 0;
    if(sum == 0)return 1;
    if (pos == n){
        return 0;
    }
    if (dp[pos][sum]!=-1)return dp[pos][sum];
    dp[pos][sum] = 0;
    for (int i = 0; i <= coun[pos]; i++){
        if (sum < i * i * value[pos])break;
        dp[pos][sum] += f(pos + 1, sum - i * value[pos]);
        dp[pos][sum] %= mod;
    }
    return dp[pos][sum];
}

int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    memset(dp, -1, sizeof(dp));

    cin >> s >> n;
    for (int i = 0; i < n; i++){
        cin >> value[i];
    }
    for (int i = 0; i < n; i++){
        cin >> coun[i];
    }
    cout << f(0, s) << endl;


return 0;
}
