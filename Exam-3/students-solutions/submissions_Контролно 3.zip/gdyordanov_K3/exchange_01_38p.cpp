#include <iostream>
#include <cstdint>

using u64 = uint64_t;
using i64 = int64_t;

constexpr u64 MAX_N = 210;
constexpr u64 MAX_S = 50010;
constexpr u64 MOD = 10e9 + 7;

i64 cache[MAX_S][MAX_N];
u64 coinsValue[MAX_N];
u64 coinsAmount[MAX_N];

u64 exchange(i64 cost, i64 pouches){
    if (cost == 0 && pouches == 0) return 1;
    if (pouches <= 0) return 0;
    if (cost < 0) return 0;
    if (cache[cost][pouches] != -1) {
        return cache[cost][pouches];
    }
    cache[cost][pouches] = 0;
    for (u64 i = 0; i <= coinsAmount[pouches - 1]; ++i){
        cache[cost][pouches] = (cache[cost][pouches] + exchange(cost - coinsValue[pouches - 1] * i, pouches - 1)) % MOD;
    }
    return cache[cost][pouches];
}

int main(){
    std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);

    u64 N, S;
    std::cin >> S >> N;
    for (u64 i = 0; i < N; ++i){
        std::cin>>coinsValue[i];
    }
    for (u64 i = 0; i < N; ++i){
        std::cin>>coinsAmount[i];
    }

    for (u64 i = 0; i <= S; ++i){
        for (u64 j = 0; j <= N; ++j){
            cache[i][j] = -1;
        }
    }

    std::cout<<exchange(S, N);
    return 0;
}