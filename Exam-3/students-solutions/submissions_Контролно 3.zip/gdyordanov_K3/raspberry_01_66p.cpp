#include <iostream>
#include <cstdint>

using u64 = uint64_t;
using i64 = int64_t;

constexpr u64 MAX_N = 510;
constexpr u64 MAX_M = 510;

i64 matrix[MAX_N][MAX_M];

int main(){
    u64 N, M;
    std::cin >> N >> M;
    for (u64 i = 0; i < N; ++i){
        for (u64 j = 0; j < M; ++j){
            std::cin >> matrix[i][j];
        }
    }

    i64 pos_y = N;
    i64 pos_x = M;
    i64 diag_start_x = M;
    i64 diag_start_y = N - 1;
    do {
        ++pos_x;
        --pos_y;
        if (pos_x >= M || pos_y < 0){
            if (diag_start_x != 0){
                --diag_start_x;
            }
            else{
                --diag_start_y;
            }
            pos_x = diag_start_x;
            pos_y = diag_start_y;
        }
        i64 optimal = 0;
        for (i64 x = M - 1; x >= pos_x; --x){
            for (i64 y = N - 1; y >= pos_y; --y){
                if (x == pos_x && y == pos_y) continue;
                optimal = std::max(optimal, matrix[y][x]);
            }   
        }
        optimal += matrix[pos_y][pos_x];
        matrix[pos_y][pos_x] = optimal;
    } while(pos_x != 0 || pos_y != 0);

    i64 result = 0;
    for (u64 i = 0; i < N; ++i){
        for (u64 j = 0; j < M; ++j){
            result += matrix[i][j];
        }
    }

    std::cout<<result;
    return 0;
}