#include <iostream>
#include <cstdint>
#include <list>
#include <algorithm>

using u64 = uint64_t;
using i64 = int64_t;

constexpr u64 MAX_N = 100;

struct Node{
    Node* left = nullptr;
    u64 value;
    Node* right = nullptr;
};

Node sizes[MAX_N];
Node* sortedSizesMiddle[MAX_N];

int main(){
    std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);

    u64 N;
    std::cin >> N;
    for (u64 i = 0; i <= N; ++i){
        sizes[i].left = &sizes[i-1];
        sizes[i].right = &sizes[i+1];
        std::cin>>sizes[i].value;
        if (i != 0 && i != N)
            sortedSizesMiddle[i-1] = &sizes[i];
    }
    sizes[0].right = &sizes[1];
    sizes[N-1].left = &sizes[N-2];

    std::sort(sortedSizesMiddle, sortedSizesMiddle + N - 1, [](const Node* a, const Node* b){
        return a->value > b->value;
    });

    u64 result = 0;
    u64 idx = 0;

    while(idx < N - 1){
        Node* x = sortedSizesMiddle[idx];
        result += x->value * x->left->value * x->right->value;
        // sortedSizesMiddle[idx] = nullptr;
        x->left->right = x->right;
        x->right->left = x->left;
        ++idx;
    }

    std::cout<<result;
    return 0;
}