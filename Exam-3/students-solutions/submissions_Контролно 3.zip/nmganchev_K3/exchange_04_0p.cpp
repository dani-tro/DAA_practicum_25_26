#include <bits/stdc++.h>

int s, n;

int a[205];
int b[205];

int dp[205][50010];

int partials[205][50010];

#define MOD 1000000007

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> s >> n;

    for (int i = 1; i <= n; i++) {
        std::cin >> a[i];
    }

    for (int i = 1; i <= n; i++) {
        std::cin >> b[i];
    }

    for (int i = 1; i <= s; i++) {
        if (i % a[1] == 0 && (i / a[1]) <= b[1]) {
            dp[1][i] = 1;
        }
    }

    for (int i = 2; i <= n; i++) {
        for (int j = 1; j <= s; j++) {
            
            int sum = 0;

            if (j > a[i]) {  
                partials[i][j] = partials[i][j - a[i]];
                if (j >= a[i] * (b[i] + 1)) {
                    partials[i][j] -= partials[i][j - a[i] * (b[i] + 1)];
                    partials[i][j] %= MOD;
                }
            }

            partials[i][j] += dp[i-1][j];
            partials[i][j] %= MOD;

            sum += partials[i][j];
            sum %= MOD;

            if (j % a[i] == 0 && (j / a[i]) <= b[i]) {
                sum += 1;
                sum %= MOD;
            }

            dp[i][j] = sum;
        }
    }


    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= s; j++) {
            std::cout << dp[i][j] << " ";
        }
        std::cout << "\n";
    }

    std::cout << dp[n][s] << "\n";
}