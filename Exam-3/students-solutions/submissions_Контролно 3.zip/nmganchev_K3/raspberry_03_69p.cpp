#include <bits/stdc++.h>

int input[505][505];
int dp[505][505];

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    int n, m;
    std::cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            std::cin >> input[i][j];
        }
    }

    dp[n][m] = input[n][m];

    for (int i = 1; i <= n; i++) {
        dp[i][m+1] = INT_MIN;
    }

    for (int i = 1; i <= m; i++) {
        dp[n+1][i] = INT_MIN;
    }

    int sum = dp[n][m];

    for (int i = n; i > 0; i--) {
        for (int j = m; j > 0; j--) {
            if (i == n && j == m) continue;
            int max1 = std::max(dp[i+1][j], dp[i][j+1]);
            int max2 = std::max(dp[i+1][j] - input[i+1][j], dp[i][j+1] - input[i][j+1]);

            int maxt = std::max(max1,max2);
            dp[i][j] = std::max(input[i][j], maxt + input[i][j]);
            sum += dp[i][j];
        }
    }

    std::cout << sum << "\n";
}