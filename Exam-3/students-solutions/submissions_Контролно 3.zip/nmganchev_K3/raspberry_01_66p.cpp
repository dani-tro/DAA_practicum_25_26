#include <bits/stdc++.h>

int input[505][505];
int dp[505][505];

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    int n, m;
    std::cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            std::cin >> input[i][j];
        }
    }

    dp[n][m] = input[n][m];

    int sum = dp[n][m];

    for (int i = n; i > 0; i--) {
        for (int j = m; j > 0; j--) {
            if (i == n && j == m) continue;
            int max = INT_MIN;

            for (int t = i; t <= n; t++) {
                for (int k = j; k <= m; k++) {
                    if (t != i || k != j) {
                        if (dp[t][k] > max) max = dp[t][k];
                    }
                }
            }

            dp[i][j] = std::max(input[i][j], max + input[i][j]);
            sum += dp[i][j];
        }
    }

    std::cout << sum << "\n";
}