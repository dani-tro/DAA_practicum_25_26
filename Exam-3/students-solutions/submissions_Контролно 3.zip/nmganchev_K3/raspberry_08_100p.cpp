#include <bits/stdc++.h>

long long input[505][505];
long long dp[505][505];
long long maxt[505][505];

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    int n, m;
    std::cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            std::cin >> input[i][j];
        }
    }

    dp[n][m] = input[n][m];

    long long sum = dp[n][m];

    for (int i = n; i > 0; i--) {
        for (int j = m; j > 0; j--) {
            if (i == n && j == m) continue;
            long long max1 = std::max(dp[i+1][j], dp[i][j+1]);
            long long max2 = 0;
            if (i + 1 > n) {
                max2 = maxt[i][j+1];
            } else if (j + 1 > m) {
                max2 = maxt[i+1][j];
            } else {
                max2 = std::max(maxt[i+1][j], maxt[i][j+1]);
            }

            maxt[i][j] = std::max(max1,max2);
            dp[i][j] = std::max(input[i][j], maxt[i][j] + input[i][j]);
            sum += dp[i][j];
        }
    }
    std::cout << sum << "\n";
}