#include <iostream>
#include <vector>

using namespace std;

int main(){

    int n = 0;
    cin>>n;
    vector<int> p(n+1);
    for(int i = 0; i<n+1; i++){
        cin>>p[i];
    }

    vector<vector<long long>>dp(n+1,vector<long long>(n+1));

    for(int l = 2; l<=n; l++){
        for(int i = 1; i <= n - l + 1; i++){
            int j = i + l - 1;
            dp[i][j] = LONG_MAX;
            for(int k = i; k <= j - 1; k++){
                long long cost = dp[i][k] + dp[k+1][j] + p[i-1]*p[k]*p[j];

                if(cost < dp[i][j]){
                    dp[i][j] = cost;
                }
            }
        }
    }

    cout<<dp[1][n]<<'\n';
    return 0;
}