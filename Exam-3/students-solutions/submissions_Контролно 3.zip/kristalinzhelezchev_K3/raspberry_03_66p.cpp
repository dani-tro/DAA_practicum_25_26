#include <iostream>
#include <vector>
#include <climits>

using namespace std;

long long getCurrMax(const vector<vector<long long>>& table, int n, int m, int i, int j){
    long long currMax = 0;
    for(int r = i; r < n; r++){
        for(int c = j; c < m; c++){
            if(r ==i && c == j){
                continue;
            }
            currMax = max(currMax, table[r][c]);
        }
    }

    return currMax;
}


int main(){
    int n = 0, m = 0;
    cin >> n >> m;

    vector<vector<long long>> table(n, vector<long long>(m));
    for(size_t i = 0; i < n; i++){
        for(size_t j = 0; j < m; j++){
            cin>>table[i][j];
        }
    }

    vector<vector<long long>>dpt(n, vector<long long>(m));
    dpt[n-1][m-1] = table[n-1][m-1];
    long long currmax = max((long long)0,table[n-1][m-1]);

    for(int i = n-2; i >=0; i--){
        dpt[i][m-1] = table[i][m-1] + currmax;
        currmax = max(currmax,dpt[i][m-1]);
        table[i][m-1] = currmax;
    }

    currmax = max((long long)0,table[n-1][m-1]);
    for(int i = m-2; i >=0; i--){
        dpt[n-1][i] = table[n-1][i] + currmax;
        currmax = max(currmax,dpt[n-1][i]);
        table[n-1][i] = currmax;
    }

    // cout<<"\n\n";
    // for(int i = 0; i < n; i++){
    //     for(int j = 0; j < m; j++){
    //         cout<< table[i][j]<<' ';
    //     }
    //     cout<<'\n';
    // }
    // cout<<"\n\n";

    table[n-1][m-1] = max((long long)0,table[n-1][m-1]);


    for(int i = n-2; i >=0; i--){
        for(int j = m-2; j>=0; j--){
            long long currMax = getCurrMax(table, n,m,i,j);
            dpt[i][j] = table[i][j] + currMax;
            table[i][j] = max(dpt[i][j], currMax);
        }
    }

    // cout<<"\n\n";
    // for(int i = 0; i < n; i++){
    //     for(int j = 0; j < m; j++){
    //         cout<< dpt[i][j]<<' ';
    //     }
    //     cout<<'\n';
    // }
    // cout<<"\n\n";

    long long ans = 0;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; j++){
            ans+=dpt[i][j];
        }
    }

    cout<<ans<<'\n';
    return 0;
}