#include <iostream>
#include <vector>
#include <climits>

using namespace std;

#define MAX 220
#define MAXCOINS 55000

int n;
int prices[MAX];
int amount[MAX];
long long s;
long long dp[MAX][MAXCOINS];


long long findSumsRec(int box, long long currSum){
    if(box > n) {
        return (currSum == s ? 1 : 0);
    }

    long long ans = 0;
    for(int i = 1; i <= amount[box]; i++){
        currSum += i*prices[box];
        ans += findSumsRec(box + 1, currSum);
        currSum -= i*prices[box];
    }

    return ans;
}

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    
    cin >> s >> n;
    for(int i = 1; i <= n; i++){
        cin>>prices[i];
    }

    for(int i = 1;i <= n; i++){
        cin>>amount[i];
    }

    cout<<findSumsRec(1,0)<<'\n';

    return 0;
}