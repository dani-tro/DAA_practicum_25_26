#include <bits/stdc++.h>
using namespace std;

const int maxVal = 505;
const int INF = 10005;

int main() {
  int N, M;
  cin >> N >> M;

  int mat[maxVal][maxVal];

  for (int i = 1; i <= N; ++i) {
    for (int j = 1; j <= M; ++j) {
      cin >> mat[i][j];
    }
  }

  int dp[maxVal][maxVal];
  dp[N][M] = mat[N][M];

  for (int i = N - 1; i >= 1; --i) {
    dp[i][M] = max(dp[i + 1][M] + mat[i][M], mat[i][M]);
  }

  for (int j = M - 1; j >= 1; --j) {
    dp[N][j] = max(dp[N][j + 1] + mat[N][j], mat[N][j]);
  }

  for (int i = N - 1; i >= 1; --i) {
    for (int j = M - 1; j >= 1; --j) {
      int k = -INF;
      //   for (int u = 1; u <= N - i; ++u) {
      //     k = max(k, dp[i + u][j]);
      //   }
      //   for (int u = 1; u <= M - j; ++u) {
      //     k = max(k, dp[i][j + u]);
      //   }
      for (int u = 0; u <= N - i; ++u) {
        for (int v = 0; v <= M - j; ++v) {
          if (u == 0 && v == 0) continue;
          k = max(k, dp[i + u][j + v]);
        }
      }

      if (k > 0)
        dp[i][j] = mat[i][j] + k;
      else
        dp[i][j] = mat[i][j];
    }
  }

  long long sum = 0;
  for (int i = 1; i <= N; ++i) {
    for (int j = 1; j <= M; ++j) {
      sum += dp[i][j];
      //   cout << dp[i][j] << " ";
    }
    // cout << endl;
  }

  cout << sum << endl;

  return 0;
}
