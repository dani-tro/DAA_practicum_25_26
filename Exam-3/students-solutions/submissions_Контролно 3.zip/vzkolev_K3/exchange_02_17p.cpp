#include <bits/stdc++.h>
using namespace std;

const long long maxS = 50005;
const long long maxN = 205;

vector<pair<long long, long long>> vec(maxN, pair<long long, long long>());

int main() {
  long long s, n;
  cin >> s >> n;

  for (long long i = 1; i <= n; ++i) {
    long long a;
    cin >> a;
    vec[i] = {a, 0};
  }

  for (long long i = 1; i <= n; ++i) {
    long long b;
    cin >> b;
    vec[i] = {vec[i].first, b};
  }

  cout << 0 << endl;
  return 0;
}
