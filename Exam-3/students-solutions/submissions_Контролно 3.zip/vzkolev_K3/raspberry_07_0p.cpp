#include <bits/stdc++.h>
using namespace std;

const long long maxVal = 505;
const long long INF = 10005;
long long mat[maxVal][maxVal];
long long dp[maxVal][maxVal];

int main() {
  long long N, M;
  cin >> N >> M;

  for (long long i = 1; i <= N; ++i) {
    for (long long j = 1; j <= M; ++j) {
      cin >> mat[i][j];
    }
  }

  dp[N][M] = mat[N][M];

  for (long long i = N - 1; i >= 1; --i) {
    long long k = -INF;
    for (long long v = 1; v <= N - i; ++v) {
      k = max(k, dp[i + v][M]);
    }
    if (k > 0)
      dp[i][M] = mat[i][M] + k;
    else
      dp[i][M] = mat[i][M];

    // dp[i][M] = max(dp[i + 1][M] + mat[i][M], mat[i][M]);
  }

  for (long long j = M - 1; j >= 1; --j) {
    long long k = -INF;
    for (long long v = 1; v <= M - j; ++v) {
      k = max(k, dp[N][j + v]);
    }
    if (k > 0)
      dp[N][j] = mat[N][j] + k;
    else
      dp[N][j] = mat[N][j];
  }

  for (long long i = N - 1; i >= 1; --i) {
    for (long long j = M - 1; j >= 1; --j) {
      long long k = -INF;
      for (long long u = 0; u <= N - i; ++u) {
        for (long long v = 0; v <= M - j; ++v) {
          if (u == 0 && v == 0) continue;
          k = max(k, dp[i + u][j + v]);
        }
      }
      //   k = max(dp[i + 1][j], max(dp[i][j + 1], dp[i + 1][j + 1]));

      if (k > 0)
        dp[i][j] = mat[i][j] + k;
      else
        dp[i][j] = mat[i][j];
    }
  }

  cout << "--------------------" << endl;

  long long sum = 0;
  for (long long i = 1; i <= N; ++i) {
    for (long long j = 1; j <= M; ++j) {
      sum += dp[i][j];
      cout << dp[i][j] << " ";
    }
    cout << endl;
  }

  cout << sum << endl;

  return 0;
}
