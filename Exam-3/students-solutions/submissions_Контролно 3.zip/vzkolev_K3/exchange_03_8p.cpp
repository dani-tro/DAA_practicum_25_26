#include <bits/stdc++.h>
using namespace std;

const long long maxS = 50005;
const long long maxN = 205;

vector<pair<long long, long long>> vec(maxN, pair<long long, long long>());

int main() {
  long long s, n;
  cin >> s >> n;

  for (long long i = 1; i <= n; ++i) {
    long long a;
    cin >> a;
    vec[i] = {a, 0};
  }

  for (long long i = 1; i <= n; ++i) {
    long long b;
    cin >> b;
    vec[i] = {vec[i].first, b};
  }

  long long dp[maxS];
  for (int i = 1; i <= n; ++i) {
    dp[i] = 0;
  }
  for (int i = 1; i <= n; ++i) {
    for (int j = 1; j < vec[i].second; ++j) {
      dp[vec[i].first * j] = 1;
    }
  }

  for (int i = 1; i <= s; ++i) {
    for(int j = 1; j <= i/2; ++j){
      dp[i] += min(dp[j], dp[i-j]);
    }
  }

  cout << dp[s] % 1000000007 << endl;
  return 0;
}
