#include <bits/stdc++.h>
using namespace std;

const long long INF = 1e18 + 5;

int main() {
  int n = 0;
  cin >> n;

  vector<int> Rs(n + 1);
  for (int i = 0; i < n + 1; i++) {
    cin >> Rs[i];
  }

  vector<vector<long long>> dp(n + 1, vector<long long>(n + 1));

  for (int v = 2; v <= n; v++) {
    for (int i = 1; i <= n - v + 1; i++) {
      int j = i + v - 1;
      dp[i][j] = INF;
      for (int k = i; k <= j - 1; ++k) {
        long long mults = dp[i][k] + dp[k + 1][j] + (Rs[i - 1] * Rs[k] * Rs[j]);
        if (mults < dp[i][j]) {
          dp[i][j] = mults;
        }
      }
    }
  }

  cout << dp[1][n] << endl;
  return 0;
}
