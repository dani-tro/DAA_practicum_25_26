#include <bits/stdc++.h>
using namespace std;

int main() {
  for (long long i = 1; i <= n; ++i) {
    long long a;
    cin >> a;
    vec[i] = {a, 0};
  }

  for (long long i = 1; i <= n; ++i) {
    long long b;
    cin >> b;
    vec[i] = {vec[i].first, b};
  }

  cout << 0 << endl;

  return 0;
}
