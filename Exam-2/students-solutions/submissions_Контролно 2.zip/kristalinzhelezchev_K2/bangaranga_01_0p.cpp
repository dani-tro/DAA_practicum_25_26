#include <iostream>
#include <vector>
#include <utility>
#include <queue>
#include <cstdint>
#include <algorithm>

using namespace std;
#define MAX 550
#define PA pair<size_t, size_t>

size_t n,t;
size_t table[MAX][MAX];
PA dists[MAX][MAX];

void buildDists(){
    for(size_t i = 1; i<=n; i++)
        for(size_t j =1; j<=n; j++){
            dists[i][j].first = SIZE_MAX;
            dists[i][j].second = 0;
        }
    dists[0][0] = {0,0};
    int dx[] = {-1,0,0,1,-2,-1,-1,0,0,1,1,2,-3,-2,-2,-1,-1,0,0,1,1,2,2,3};
    int dy[] = {0,-1,1,0,0,1,-1,2,-2,-1,1,0,0,-1,1,2,-2,3,-3,2,-2,1,-1,0};

    for(size_t i = 1; i <=n; i++){
        for(size_t j = 1; j<=n; j++){
            for(int c = 0; c < 24; c++){
                    int row = i + dx[c];
                    int col = j + dy[c];
                    if(row < 1 || row > n || col < 1 || col > n) continue;

                    int countMoves = abs(dx[c]) + abs(dy[c]);
                    if(3 - dists[i][j].second < countMoves)
                        continue;

                    size_t currTime = 0;
                    if(3 - countMoves == 0) {
                        currTime = table[row][col];
                    }else{
                        currTime = (3-countMoves) * t;
                    }
                    
                    dists[row][col].first = std::min(dists[row][col].first, dists[i][j].first + currTime);
                    dists[row][col].second = countMoves; 
            }
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>t;

    for(size_t i = 1; i <= n; i++){
        for(size_t j = 1; j <=n; j++){
            cin>>table[i][j];
        }
    }

    buildDists();

    cout<<dists[n][n].first<<'\n';

    return 0;
}

/*
4 2
30 92 36 10
38 85 60 16
41 13 5 68
20 97 13 80
*/