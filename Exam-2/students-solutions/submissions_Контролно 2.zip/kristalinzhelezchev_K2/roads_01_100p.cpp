#include <iostream>
using namespace std;

#define MAX 1100

size_t n, m;
bool grcopy[MAX][MAX];
bool used[MAX];
size_t comps;

void dfs(size_t node){
    if(used[node]){
        return;
    }

    used[node] = true;

    for(size_t j = 1; j <=n; j++){
        if(grcopy[node][j]){
            dfs(j);
        }
    }
}

int main(){

    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>m;

    for(size_t i = 1; i<=n; i++)
        fill(grcopy[i], grcopy[i] + n + 2, true);

    size_t u, v;
    for(size_t i = 0; i < m; i++){
        cin>>u>>v;
        grcopy[u][v] = false;
        grcopy[v][u] = false;
    }

    for(size_t i = 1; i<=n; i++){
        grcopy[i][i] = false;
    }

    for(size_t i = 1; i <=n; i++){
        if(used[i]) continue;

        dfs(i);
        comps++;
    }

    cout<<comps - 1<<'\n';
    return 0;
}

/*
4 4
1 2
2 3
3 4
4 1

3 3
1 2
2 3
1 3
*/