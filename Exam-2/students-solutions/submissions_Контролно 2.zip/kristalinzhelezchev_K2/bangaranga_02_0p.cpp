#include <iostream>
#include <vector>
#include <utility>
#include <queue>
#include <cstdint>
#include <algorithm>

using namespace std;
#define MAX 550
#define PA pair<edge, size_t>

struct edge {
    int row, col;
    size_t time;
    int type;

    bool operator<(const edge& other) const{
        return time < other.time;
    }

    bool operator>(const edge& other) const{
        return time > other.time;
    }

    bool operator==(const edge& other) const{
        return time == other.time;
    }
};

size_t n,t;
size_t table[MAX][MAX];
vector<edge> graph[MAX][MAX];
bool used[MAX][MAX];
size_t dists[MAX][MAX];
priority_queue<edge, vector<edge>, greater<edge>> pq;

void buildGraph(){
    int dx[] = {-1,0,0,1,-2,-1,-1,0,0,1,1,2,-3,-2,-2,-1,-1,0,0,1,1,2,2,3};
    int dy[] = {0,-1,1,0,0,1,-1,2,-2,-1,1,0,0,-1,1,2,-2,3,-3,2,-2,1,-1,0};

    for(int i = 1; i <=n; i++){
        for(int j =1; j <=n; j++){
            for(int c = 0; c < 24; c++){
                    int row = i + dx[c];
                    int col = j + dy[c];
                    if(row < 1 || row > n || col < 1 || col > n) continue;

                    int countMoves = abs(dx[c]) + abs(dy[c]);
                    size_t currTime = 0;
                    if(countMoves == 3) {
                        currTime = table[row][col];
                    }else{
                        currTime = countMoves * t;
                    }

                    graph[i][j].push_back({row, col, currTime, countMoves});
            }
        }
    }
}

void dijkstra() {
    for(size_t i = 1; i<=n; i++)
        fill(dists[i], dists[i] + n + 2, SIZE_MAX);
    
    dists[1][1] = 0;
    pq.push({1,1,0,0});

    while(!pq.empty()){
        size_t nodeRow = pq.top().row;
        size_t nodeCol = pq.top().col;
        int type = pq.top().type;
        pq.pop();

        if(used[nodeRow][nodeCol]) continue;
        used[nodeRow][nodeCol] = true;
        int prehodType = 0;

        for(auto e : graph[nodeRow][nodeCol]){
            if(type == 0){
                prehodType = e.type;
            }
            else if(type == 1 && e.type == 3){
                continue;
            }
            else if(type == 2 && e.type >=2){
                continue;
            }else if(type == 3){
                prehodType = 0;
            }

            size_t candidate = dists[nodeRow][nodeCol] + e.time;

            if(candidate < dists[e.row][e.col]){
                dists[e.row][e.col] = dists[nodeRow][nodeCol] + e.time;
                pq.push({e.row, e.col, dists[e.row][e.col], prehodType});
            }
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>t;

    for(size_t i = 1; i <= n; i++){
        for(size_t j = 1; j <=n; j++){
            cin>>table[i][j];
        }
    }

    buildGraph();

    dijkstra();

    cout<<dists[n][n]<<'\n';

    return 0;
}

/*
4 2
30 92 36 10
38 85 60 16
41 13 5 68
20 97 13 80
*/