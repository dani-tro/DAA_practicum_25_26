#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

using namespace std;

struct edge{
    size_t from, to, w, idx, party;
    bool isUsed;
};

#define MAX 1100

bool cmp(const edge& e1,const edge& e2){
    return e1.w > e2.w;
}

size_t n, m , k, par[MAX], d[MAX], countUsed;
vector<edge> edges;
vector<size_t> ans;

size_t find(size_t node){
    if(par[node] == 0){
        return node;
    }

    return par[node] = find(par[node]);
}

bool unify(size_t u, size_t v){
    u = find(u);
    v = find(v);

    if(u == v) return false;

    if(d[u] > d[v]) swap(u,v);

    par[u] = v;

    if(d[u] == d[v]) d[v]++;
    return true;
}

void Kruskal(size_t party) {
    fill(par, par + n + 2, 0);
    fill(d, d + n + 2, 0);

    for(size_t i = 0; i < m; i++){
        if(edges[i].isUsed) continue;

        bool canunify = unify(edges[i].from, edges[i].to);
        if(canunify){
            edges[i].isUsed = true;
            edges[i].party = party;
            countUsed++;
        }
    }
}

int main(){

    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>m>>k;

    edges.resize(m);
    ans.resize(m);
    size_t u,v,w;
    for(size_t i = 0; i < m; i++){
        cin>>u>>v>>w;
        edges[i] = {u,v,w,i,0, false };
    }

    sort(edges.begin(), edges.end(), cmp);

    for(size_t i = 1; i <=k; i++){
        if(countUsed == m)
            break;
        Kruskal(i);
    }

    for(size_t i =0; i < m; i++){
        ans[edges[i].idx] = edges[i].party;
    }

    for(size_t i =0; i < m; i++){
        cout<<ans[i]<<'\n';
    }
    return 0;
}

/*
3 5 2
1 2 3
1 2 1
2 3 4
2 3 6
1 3 2

3 6 5
1 2 1
1 2 2
2 3 3
2 3 4
3 1 5
3 1 6
*/