#include <iostream>
#include <vector>
#include <queue>	
#include <utility>
#include <algorithm>
#include <climits>

using namespace std;
#define int long long
const int MAX = 100005;

int n, m;

vector<int> g[MAX];
vector<int> gr[MAX];

bool visited[MAX];

void dfs(int node) {
	if (visited[node]) {
		return;
	}

	visited[node] = true;

	for (auto v : gr[node]) {
		if (!visited[v]) {
			dfs(v);
		}
	}
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	cin >> n >> m;
	for (int i = 0; i < m; ++i) {
		int a, b;
		cin >> a >> b;

		g[a].push_back(b);
		g[b].push_back(a);
	}

	vector<int> contains(n + 1, 0);

	for (int i = 1; i <= n; ++i) {
		vector<int> adj = g[i];
		for (auto v : adj) {
			contains[v] = 1;
		}

		for (int j = 1; j <= n; ++j) {
			if (contains[j] == 0) {
				gr[i].push_back(j);
			}
			else {
				contains[j] = 0;
			}
		}
	}
	int cnt = 0;
	for (int i = 1; i <= n; ++i) {
		if (!visited[i]) {
			dfs(i);
			cnt++;
		}
	}

	cout << cnt - 1 << "\n";
}
