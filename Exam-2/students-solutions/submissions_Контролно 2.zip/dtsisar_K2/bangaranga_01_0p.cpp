#include <iostream>
#include <vector>
#include <queue>	
#include <utility>
#include <algorithm>
#include <climits>

using namespace std;
#define int long long
const int MAX = 505;

int n, t, dist[MAX][MAX];
int matrix[MAX][MAX];

struct Node {
	int r, c, t, cnt;

	bool operator>(const Node& other) const {
		return (t > other.t);
	}
};

const int INF = 1e9;

int dr[] = { -1, 1, 0, 0 };
int dc[] = { 0, 0, 1, -1 };

bool isValid(int r, int c) {
	return r >= 0 && r < n && c >= 0 && c < n;
}

bool visited[MAX][MAX];

void dijkstra(int start_r, int start_c) {
	priority_queue<Node, vector<Node>, greater<Node>> pq;
	

	dist[start_r][start_c] = 0;
	pq.push({ start_r, start_c, 0, 0 });

	while (!pq.empty()) {
		Node curr = pq.top();
		pq.pop();
		int r = curr.r;
		int c = curr.c;
		int time = curr.t;
		int cnt = curr.cnt + 1;


		if (visited[r][c]) {
			continue;
		}
		visited[r][c] = true;

		for (int i = 0; i < 4; ++i) {
			int nr = dr[i] + r;
			int nc = dc[i] + c;

			if (!isValid(nr, nc)) {
				continue;
			}

			if (cnt == 3) {
				if (dist[r][c] + t + matrix[nr][nc] < dist[nr][nc]) {
					dist[nr][nc] = dist[r][c] + t + matrix[nr][nc];
					pq.push({ nr, nc, dist[nr][nc], 0 });
				}
			}

			else {
				if (dist[r][c] + t < dist[nr][nc]) {
					dist[nr][nc] = dist[r][c] + t;
					pq.push({ nr, nc, dist[nr][nc], cnt });
				}
			}
		}
	}
	return;
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> t;

	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			cin >> matrix[i][j];
		}
	}

	for (int i = 0; i < MAX; ++i) {
		for (int j = 0; j < MAX; ++j) {
			dist[i][j] = INF;
		}
	}

	dijkstra(0, 0);

	cout << dist[n - 1][n - 1] << "\n";
}
