#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
#define int long long
#define endl "\n"

const int maxn = 500;
const int inf = 99999999999999999;
int n, t;

int w[maxn * maxn];

pair<int, int> reldir[16] = { 
    {1, 0}, {-1, 0}, {0, 1}, {0, -1},
    {3, 0}, {2, 1}, {1, 2}, {0, 3}, {-1, 2}, {-2, 1}, {-3, 0},
    {2, -1}, {1, -2}, {0, -3}, {-1, -2}, {-2, -1}
};

vector<pair<int, int>> adj[maxn * maxn];
void build(int i) {
    int ix = i / n, iy = i % n;
    for (auto p : reldir) {
        int ax = p.first + ix, ay = p.second + iy;
        int aip = ax * n + ay;
        if (ax < 0 || ax >= n || ay < 0 || ay >= n) continue;

        adj[i].push_back({w[aip] + 3 * t, aip});
    }
}

int dist[maxn * maxn];
pair<pair<int, int>, int> reltbl[6] = {
    {{0, 0}, 0},
    {{-1, 0}, 1}, {{-2, 0}, 2},
    {{0, -1}, 1}, {{0, -2}, 2},
    {{-1, -1}, 2}
};
int pluss(int i, pair<int, int> xy) {
    int ix = i / n, iy = i % n;
    int ax = ix + xy.first, ay = iy + xy.second;
    if (ax < 0 || ax >= n || ay < 0 || ay >= n) return -1;
    else return ax * n + ay;
}

pair<int, int> tbl[6];
void Dijkstra(int s, int t) {
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;

    for (int i = 0; i < n * n; i++) dist[i] = inf;
    dist[s] = 0; q.push({ 0, s });
  
    int brtbl = 6;
    for (int i = 0; i < 6; i++) {
        tbl[i] = { pluss(t, reltbl[i].first), reltbl[i].second};
    }
    
    while (!q.empty()) {
        int v = q.top().second;
        int d = q.top().first;
        q.pop();

        if (dist[v] < d) continue;
        if (v == tbl[0].first || v == tbl[1].first || v == tbl[2].first || v == tbl[3].first || v == tbl[4].first || v == tbl[5].first) {
            brtbl--;
            if (brtbl == 0) break;
        }

        for (auto sus : adj[v]) {
            int u = sus.second, w = sus.first;
            if (dist[u] > dist[v] + w) {
                dist[u] = dist[v] + w;
                q.push({dist[u], u});
            }
        }
    }
}

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

    cin >> n >> t;
    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            cin >> w[x * n + y];
        }
    }

    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            build(x * n + y);
        }
    }

    Dijkstra(0, (n-1) * n + (n-1));
    int minn = inf;
    for (int i = 0; i < 6; i++) {
        minn = min(minn, dist[tbl[i].first] + tbl[i].second * t);
    }
    cout << minn;

    return 0;
}