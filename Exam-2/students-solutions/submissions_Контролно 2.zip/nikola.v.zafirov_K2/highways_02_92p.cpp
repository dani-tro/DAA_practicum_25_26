#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;
//#define int short
#define endl "\n"

const int maxn = 1000 + 2;
const int maxm = 300000 + 2;

int parent[maxn];
int grosse[maxn];
void create(int e) {
    parent[e] = e;
    grosse[e] = 1;
}
int findset(int e) {
    if (e == parent[e]) return e;
    return parent[e] = findset(parent[e]);
}
int combine(int a, int b) {
    a = findset(a);
    b = findset(b);
    if (a == b) return -1;
    if (grosse[a] < grosse[b]) swap(a, b);
    parent[b] = a;
    grosse[a] += grosse[b];
    return a;
}

void DSU(int n) {
    for (int i = 0; i < n; i++) create(i);
}


struct Edge {
    int u;
    int v;
    int w;
    int partia = 0;
    int i;
};
Edge e[maxm];
bool compw(Edge a, Edge b) { return a.w >= b.w; }
bool compi(Edge a, Edge b) { return a.i < b.i; }
bool compz(int a, int b) { return e[a].w >= e[b].w; }


signed main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

    int n, m, k; cin >> n >> m >> k;
    for (int i = 0; i < m; i++) {
        cin >> e[i].u >> e[i].v >> e[i].w;
        e[i].i = i;
        e[i].u--; e[i].v--;
    }
    vector<int> zarazdavane(m);
    for (int i = 0; i < m; i++) {
        zarazdavane[i] = i;
    }
    sort(zarazdavane.begin(), zarazdavane.end(), compz);

    for (int p = 1; p <= k; p++) {
        DSU(n);
        for (int ii = 0; ii < zarazdavane.size(); ii++) {
            int i = zarazdavane[ii];
            int res = combine(e[i].u, e[i].v);
            if (res != -1) {
                e[i].partia = p;
                zarazdavane.erase(zarazdavane.begin() + ii, zarazdavane.begin() + ii + 1);
                ii--;
            }
        }
    }

    for (int i = 0; i < m; i++) {
        cout << e[i].partia << endl;
    }

    return 0;
}