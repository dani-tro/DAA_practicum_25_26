#include <iostream>
#include <vector>
using namespace std;
//#define int short

const int maxn = 1000 + 2;

//struct DSU {
    int parent[maxn];
    int grosse[maxn];


    void create(int e) {
        parent[e] = e;
        grosse[e] = 1;
    }
    int findset(int e) {
        if (e == parent[e]) return e;
        return parent[e] = findset(parent[e]);
    }
    int combine(int a, int b) {
        a = findset(a);
        b = findset(b);
        if (a == b) return -1;
        if (grosse[a] < grosse[b]) swap(a, b);
        parent[b] = a;
        grosse[a] += grosse[b];
        return a;
    }

    void DSU(int n) {
        for (int i = 0; i < n; i++) create(i);
    }
//};

bool r[maxn][maxn];

signed main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

    int n, m; cin >> n >> m;
    DSU(n);

    for (int i = 0; i < m; i++) {
        int a, b; cin >> a >> b;
        if (a < b) swap(a, b);
        r[a - 1][b - 1] = true;
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (r[i][j] == false) {
                combine(i, j);
            }
        }
    }

    int otg = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (r[i][j] == true) {
                int res = combine(i, j);
                if (res != -1) otg++;
            }
        }
    }
    cout << otg;

    return 0;
}