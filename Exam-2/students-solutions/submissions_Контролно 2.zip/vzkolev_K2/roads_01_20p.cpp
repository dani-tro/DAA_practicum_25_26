#include<bits/stdc++.h>
using namespace std;

vector<vector<bool>> adj;
int n,m;
vector<bool> visited;

void DFS(int start){
    visited[start] = true;
    // cout << start << " ";

    for(int i = 1; i <= n; ++i){
        if(i == start) continue;
        if(adj[start][i]){
            if(!visited[i]) DFS(i);
        }
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m;

    visited.resize(n+1);
    adj.assign(n+1, vector<bool>(n+1, true));

    for(int i = 1; i <=n; ++i){
        int u,v;

        cin >> u >> v;

        adj[v][u] = 0;
        adj[u][v] = 0;
    }

    for(int i = 1; i <=n ;++i) adj[i][i] = 0;

    // for(int i = 1; i <= n; ++i){
    //     for(int j = 1; j <= n; ++j){
    //         cout << adj[i][j] << " ";
    //     }
    //     cout << endl;
    // }

    visited.assign(n+1, false);

    int cnt = 0;
    for(int i = 1; i <= n; ++i){
        if(!visited[i]) {
            DFS(i);
            cnt++;
        }
    }

    cout << cnt - 1;


    return 0;
}