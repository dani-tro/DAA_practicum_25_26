#include<bits/stdc++.h>
using namespace std;

const long long INF = 1e18+5;

struct Edge{
    int f, t;
    long long w;
};

vector<vector<int>> dist;
vector<vector<int>> edges;
vector<bool> used;
int n, m, t;
int cnt = 0;

bool isValid(int x, int y){
    return x <= n && x >= 0 && y <= n && y >= 0;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> t;

    dist.assign(n+1, vector<int>(n+1, 0));

    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= n; ++j){
            int a;
            cin >> a;
            edges.push_back({i,j,a});
        }
    }

    cout << 31;

    return 0;
}