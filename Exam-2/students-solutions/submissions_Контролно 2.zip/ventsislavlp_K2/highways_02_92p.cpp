#include <bits/stdc++.h>
#define int long long

using namespace std;

const int maxn = 1e3 + 3;
int sz[maxn], par[maxn];

int find(int x)
{
    if (par[x] == x) return x;
    return par[x] = find(par[x]);
}

void unio(int x, int y)
{
    int px = find(x), py = find(y);
    if (px == py) return;
    if (sz[px] < sz[py])
    {
        par[px] = py;
        sz[py] += sz[px];
    }
    else
    {
        par[py] = px;
        sz[px] += sz[py];
    }
}

struct edge
{
    int x;
    int y;
    int d;

    int idx;
    int partiq = 0;


    bool operator< (const edge& o) const
    {
        return d > o.d;
    }
};

const int maxm = 3e5 + 2;
int ans[maxm];

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, k;
    cin >> n >> m >> k;
    vector <edge> v;
    for (int i = 0; i < m; ++i)
    {
        int x, y, d;
        cin >> x >> y >> d;
        v.push_back({x, y, d, i});
    }
    sort(v.begin(), v.end());


    for (int i = 1; i <= k; ++i)
    {
        for (int j = 1; j <= n; ++j)
        {
            par[j] = j;
            sz[j] = 1;
        }
        for (auto &e: v)
        {
            if (e.partiq != 0 || find(e.x) == find(e.y)) continue;
            unio(e.x, e.y);
            e.partiq = i;
            ans[e.idx] = i;
        }
    }

    for (int i = 0; i < m; ++i)
    {
        cout << ans[i] << '\n';
    }




    return 0;
}
