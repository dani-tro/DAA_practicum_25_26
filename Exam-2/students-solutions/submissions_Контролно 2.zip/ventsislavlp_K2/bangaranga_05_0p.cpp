#include <bits/stdc++.h>
#define int long long

using namespace std;

const int maxn = 505;
int m[maxn][maxn];
int dist[2][maxn][maxn]; // 0 ako e napravila 3 stapki, 1 ako stiga za po-malko

int n, t;

void dijkstra(pair <int, int> start)
{
    dist[0][start.first][start.second] = 0;
    priority_queue <pair <int, pair <int, int> > > q;
    q.push({0, start});

    while (!q.empty())
    {
        auto curr = q.top();
        q.pop();
        if (-curr.first > dist[0][curr.second.first][curr.second.second]) continue;

        for (int i = 0; i <= 3; ++i)
        {
            for (int j = 0; j <= 3; ++j)
            {
                if (i + j > 3) break;
                pair <int, int> dirs[] = {{i, j}, {-i, j}, {i, -j}, {-i, -j}};
                for (auto dir: dirs)
                {
                    pair <int, int> hex = {curr.second.first + dir.first, curr.second.second + dir.second};
                    if (hex.first < 0 || hex.first >= n || hex.second < 0 || hex.second >= n) continue;
                    if (i + j == 3 || i + j == 1 || (i + j == 2 && (i == 0 || j == 0)))
                    {
                        if (dist[0][hex.first][hex.second] <= -curr.first + 3 * t + m[hex.first][hex.second]) continue;
                        dist[0][hex.first][hex.second] = -curr.first + 3 * t + m[hex.first][hex.second];
                        q.push({-dist[0][hex.first][hex.second], hex});
                    }
                    else
                    {
                        if (dist[1][hex.first][hex.second] <= -curr.first + (i + j) * t) continue;
                        dist[1][hex.first][hex.second] = -curr.first + (i + j) * t;
                    }
                }
            }
        }
    }
    cout << min(dist[0][n - 1][n - 1], dist[1][n - 1][n - 1]) << '\n';
}


signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n >> t;
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            cin >> m[i][j];
            dist[0][i][j] = LLONG_MAX;
            dist[1][i][j] = LLONG_MAX;
        }
    }

    dijkstra({0, 0});


    return 0;
}
