#include <bits/stdc++.h>

using namespace std;

const int maxn = 1e3 + 3;
bool vis[maxn];

void dfs(vector <vector <int> >& v, int node)
{
    if (node == -1) return;
    if (vis[node]) return;
    vis[node] = true;
    for (int i = 0; i < v[node].size(); ++i)
    {
        dfs(v, v[node][i]);
    }
}

int main()
{
    int n, m;
    cin >> n >> m;

    vector <vector <int> > v, g;
    v.resize(n + 1);
    g.resize(n + 1);

    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= n; ++j)
        {
            v[i].push_back(j);
        }
    }

    for (int i = 0; i < m; ++i)
    {
        int x, y;
        cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    for (int i = 1; i <= n; ++i)
    {
        for (auto e: g[i])
        {
            v[i][e - 1] = -1;
        }
    }

    int ans = -1;
    for (int i = 1; i <= n; ++i)
    {
        if (!vis[i])
            ans++;
        dfs(v, i);
    }
    cout << ans << '\n';




    return 0;
}
