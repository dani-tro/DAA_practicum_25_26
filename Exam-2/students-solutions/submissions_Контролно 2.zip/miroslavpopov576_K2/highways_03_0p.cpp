#include <iostream>
#include <queue>
#include <algorithm>
#include <string>
#include <map>
using namespace std;

long long const maxN=1e3+5;
long long const maxK=10;
vector<pair<long long, pair<long long, long long>>> v;
long long adj[maxN][maxN];

void solve(){
    long long n,m,k;
    cin >> n >> m >> k;
    map<long long, long long> ans;
    for(int i=0; i<m; i++){
        long long u,vi,w;
        cin >> u >> vi >> w;
        u--;
        vi--;
        ans[w]=0;
        v.push_back({w, {vi, u}});
    }

    
    
    for(int i=1; i<k; i++){
        for(int p=0; p<n; p++){
            for(int j=0; j<n; j++){
                adj[p][j]=0;
            }
        }

        for(int p=0; p<m; p++){
            if(ans[v[p].first]==0) continue;
            adj[v[p].second.first][v[p].second.second]=max(adj[v[p].second.first][v[p].second.second], v[p].first);
            adj[v[p].second.second][v[p].second.first]=max(adj[v[p].second.second][v[p].second.first], v[p].first);
        }
        
        vector<pair<long long, long long>> adj2[maxN];
        
        for(int p=0; p<n; p++){
            for(int j=0; j<n; j++){
                if(adj[p][j]!=0)
                    adj2[p].push_back({j, adj[p][j]});
            }
        }

        bool visited[maxN];
        //max spanning tree
        long long key[maxN];
        priority_queue<pair<long long, long long>> pq;

        for(int p=0; p<n; p++){
            if(visited[p]) continue; //weightovete
        
            for(int l=0; l<n; l++) key[l]=0;

            key[p]=0;
            pq.push({0, p});

            while(!pq.empty()){
                int node=pq.top().second;
                if(visited[node]) continue;
                visited[node]=true;
                pq.pop();

                for(int f=0; f<adj2[node].size(); f++){
                    if(!visited[adj2[node][f].first] && adj2[node][f].second>key[adj2[node][f].first]){
                        key[adj2[node][f].first]=adj2[node][f].second;
                        pq.push({adj2[node][f].second, adj2[node][f].first});
                    }
                }
            }

            for(int f=0; f<n; f++){
                ans[key[f]]=i;
            }

        }

    }

    for(int i=0; i<m; i++){
        cout << ans[v[i].first] << endl;
    }


}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr);

    solve();
}












