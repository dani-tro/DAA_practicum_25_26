#include <iostream>
#include <queue>
#include <algorithm>
#include <string>
#include <map>
using namespace std;

long long const maxN=1e3;
long long const maxK=10;
bool visited[maxK][maxN];
vector<pair<long long, pair<long long, long long>>> v;
vector<pair<long long, pair<long long, long long>>> v2;


void solve(){
    long long n,m,k;
    cin >> n >> m >> k;

    

    for(int i=0; i<m; i++){
        long long u,vi,w;
        cin >> u >> vi >> w;
        u--;
        vi--;

        v.push_back({w, {vi, u}});
    }

    for(int i=0; i<m; i++){
        v2.push_back({v[i].first, v[i].second});
    }

    sort(v.rbegin(), v.rend());

    map<long long, long long> ma;

    for(int i=0; i<m; i++){
        int p=v[i].second.first;
        int q=v[i].second.second;

        for(int j=0; j<k; j++){
            if(!visited[j][p] || !visited[j][q]){
                ma[v[i].first]=j+1;
                visited[j][p]=true;
                visited[j][q]=true;
                break;
            }

            if(j==k-1) ma[v[i].first]=0;
        }
    }

    for(int i=0; i<m; i++){
        cout << ma[v2[i].first] << endl;
    }


}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr);

    solve();
}












