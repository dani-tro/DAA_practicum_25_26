#include <iostream>
#include <queue>
#include <algorithm>
#include <string>
using namespace std;

long long const maxN=1e3;
long long const maxS=1e6;
bool adj[maxN][maxN];
bool visited[maxN];

void dfs(int s){
    if(visited[s]) return;
    visited[s]=true;

    for(int i=0; i<maxN; i++){
        if(adj[s][i]) dfs(i);
    }
}


void solve(){
    long long n,m;
    cin >> n >> m;

    for(int i=0; i<m; i++){
        long long u,v;
        cin >> u >> v;
        u--;
        v--;
        adj[u][v]=true;
        adj[v][u]=true; 
    }

    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            if(i!=j){
                if(adj[i][j]) adj[i][j]=false;
                else adj[i][j]=true;

            }
        }
    }

    int ans=0;
    
    for(int i=0; i<n; i++){
        if(visited[i]) continue;
        else{
            ans++;
            dfs(i);
        }
    }

    cout << ans-1 << endl;

}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr);

    solve();
}












