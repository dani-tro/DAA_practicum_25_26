#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

using namespace std;

const int maxN = 520;
int N, T;
vector<pair<int, int>> gr[maxN*3];
int t[maxN][maxN];
long long dist[maxN*3];
bool vis[maxN*3];
inline bool isIn(int gr, int i)
{
    return (gr - 1)*N*N < i && i <= gr*N*N;
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> N >> T;

    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= N; j++)
        {
            cin >> t[i][j];   
        }
    }

    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= N; j++)
        {
            int cel = N*(i-1) + j;
            {
                if(isIn(2, N*N + cel + 1) && (cel + 1)%N != 1) gr[cel].push_back({T, N*N + cel + 1});
                if(isIn(2, N*N + cel - 1) && (cel - 1)%N != 0) gr[cel].push_back({T, N*N + cel - 1});
                if(isIn(2, N*N + cel + N)) gr[cel].push_back({T, N*N + cel + N});
                if(isIn(2, N*N + cel - N)) gr[cel].push_back({T, N*N + cel - N});

                if(isIn(3, 2*N*N + cel + 1) && (cel + 1)%N != 1) 
                    gr[cel + N*N].push_back({T+t[i][j + 1],2*N*N + cel + 1});
                if(isIn(3, 2*N*N + cel - 1) && (cel - 1)%N != 0) 
                    gr[cel + N*N].push_back({T+t[i][j - 1],2*N*N + cel - 1});
                if(isIn(3, 2*N*N + cel + N)) 
                    gr[cel + N*N].push_back({T+t[i + 1][j],2*N*N + cel + N});
                if(isIn(3, 2*N*N + cel - N)) 
                    gr[cel + N*N].push_back({T+t[i - 1][j],2*N*N + cel - N});

                if(isIn(1, cel + 1) && (cel+1)%N != 1) gr[N*N*2 + cel].push_back({T,cel + 1});
                if(isIn(1, cel - 1) && (cel-1)%N != 0) gr[N*N*2 + cel].push_back({T,cel - 1});
                if(isIn(1, cel + N)) gr[N*N*2 + cel].push_back({T,cel + N});
                if(isIn(1, cel - N)) gr[N*N*2 + cel].push_back({T,cel - N});
            }
            
        }
    }

    // for(int i = 1; i <= 3*N*N; i++)
    // {
    //     for(auto [w, j] : gr[i])
    //     {
    //         cout << i << "," << j << " = " << w << "\n";
    //     }
    //     cout << "\n";
    // }

    gr[0].push_back({T,2});
    gr[0].push_back({T, N + 1});

    const int MAXINT = 2147483648 - 1;
    fill(dist, dist + (N*N + 19)*3, MAXINT);

    dist[0] = 0;
    priority_queue<pair<int, int>> pq;
    pq.push({0, 0});
    
    while(!pq.empty())
    {
        int node = pq.top().second;
        pq.pop();
        if(vis[node]) continue;
        vis[node] = true;

        for(auto [w, u] : gr[node])
        {
            //cout << "proc node: " << u << "\n";
            if(dist[u] > dist[node] + w)
            {
                //cout << w << " =w " << u << " " << node << "\n";
                dist[u] = dist[node] + w;
                pq.push({-dist[u], u});
            }
        }
    }

    //for(int i = 0; i < (N + 19)*3; i++) cout << dist[i] << "\n";
    //cout << dist[N*N] << " " << dist[2*N*N] << " " << dist[3*N*N] << "\n";
    cout << min(dist[N*N], min(dist[2*N*N], dist[3*N*N])) << "\n";

    return 0;
}

/*
2 1
3 4 5 6
*/