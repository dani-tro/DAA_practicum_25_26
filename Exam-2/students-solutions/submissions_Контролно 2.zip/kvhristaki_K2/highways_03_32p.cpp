#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

using namespace std;

struct highway
{
    int cost;
    int red;
};

const int maxN = 1010, maxM = 3e5 + 100;
int N, M, K;
vector<pair<int, highway>> gr[maxN];
int owner[maxM];
int vis[maxN];

void steal(int h, int o)
{
    priority_queue<pair<int, pair<int, int>>> pq;
    pq.push({0, {h,0}});

    while(!pq.empty())
    {
        int node = pq.top().second.first;
        int num = pq.top().second.second;
        int weight = pq.top().first;
        pq.pop();
        if(vis[node] == o) continue;
        vis[node] = o;
        owner[num] = o;

        for(auto [u, h] : gr[node])
        {
            int r = h.red;
            int c = h.cost;
            if(!vis[u] && owner[r] < 1)
            {
                pq.push({c, {u, r}});
            }
        }
    }
}

signed main()
{
    // ios_base::sync_with_stdio(false);
    // cin.tie(nullptr);
    // cout.tie(nullptr);

    cin >> N >> M >> K;
    int a, b, c;
    for(int i = 1; i <= M; i++) 
    {
        cin >> a >> b >> c;
        gr[a].push_back({b,{c, i}});
        gr[b].push_back({a,{c, i}});
    }

    for(int i = 1; i <= K; i++)
    {
        //fill(vis, vis + N + 5, false); //mozhe po dobre s intove
        for(int j = 1; j <= N; j++)
        {
            //cout << "stealing " << j << "\n";
            if(vis[j] != i) steal(j, i);
        }
    }

    for(int i = 1; i <= M; i++)
    {
        cout << owner[i] << "\n";
    }

    return 0;
}