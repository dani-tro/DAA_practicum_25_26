#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
#include <set>

using namespace std;

const int maxN = 1010;
int N, M;
bool roads[maxN][maxN];
int par[maxN];
int d[maxN];
int find(int u)
{
    if(par[u] == -1 || par[u] == u) return u;
    //cout << "u = " << u << "\n";
    return (par[u] = find(par[u]));
}

void myUnion(int u, int v)
{
    //cout << "calling find with " << u << " " << v << "\n";
    u = find(u);
    v = find(v);

    if(d[u] < d[v]) swap(u,v);
    par[v] = u;
    if(d[u] == d[v]) d[u]++;
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> N >> M;
    fill(par, par + N + 7, -1);

    int a, b;
    for(int i = 1; i <= M; i++)
    {
        cin >> a >> b;
        //cout << a << " " << b << " = true \n";
        roads[a][b] = true;
        roads[b][a] = true;
    }

    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= N; j++)
        {
            if(i == j || roads[i][j]) continue;
            myUnion(i,j);
            //cout << "unino " << i << " " << j << " roads: " << roads[i][j] << "\n";
        }
    }

    set<int> ans;
    for(int i = 1; i <= N; i++)
    {
        int f = find(i);
        //cout << f << " ";
        ans.insert(f);
    }
    //cout << "\n";

    cout << ans.size() - 1 << "\n";

    return 0;
}