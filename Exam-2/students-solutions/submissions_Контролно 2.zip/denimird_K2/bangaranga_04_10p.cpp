#include<iostream>
#include<vector>
#include<queue>
#include<cmath>
using namespace std;
#define MAXN 505
#define INF 2e9
int dx[] = {-3, -2, -1, 0, 1, 2, 3, -2, -1, 0, 1, 2};
int dy[] = {0, -1, -2, -3, -2, -1, 0, 1, 2, 3, 2, 1};
int n;
struct Cell{
    int x, y;
    long long price;
};
bool operator>(const Cell& one, const Cell& two){
    return one.price>two.price;
}
bool operator<(const Cell& one, const Cell& two){
    return one.price<two.price;
}
int distanceCells(const Cell& a, const Cell& b){
    return abs(a.x-b.x) + abs(a.y-b.y);
}
long long t;
long long d[MAXN][MAXN];
long long times[MAXN][MAXN];
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>t;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            cin>>times[i][j];
        }
    }
    d[1][1] = 0;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            if(i!=1 || j!=1) d[i][j] = INF;
        }
    }
    Cell Last_cell = {n, n, d[n][n]};
    priority_queue<Cell, vector<Cell>, greater<Cell>> pq;
    pq.push({1, 1, 0});
    while(!pq.empty()){
        Cell cell = pq.top();
        pq.pop();
        for(int i=0; i<12; i++){
            if(cell.x + dx[i] >= 1 && cell.x+dx[i] <=n && cell.y+dy[i]>=1 && cell.y+dy[i]<=n){
                if(d[cell.x+dx[i]][cell.y+dy[i]]>3*t + cell.price + times[cell.x+dx[i]][cell.y+dy[i]]){
                    d[cell.x+dx[i]][cell.y+dy[i]] = 3*t + cell.price + times[cell.x+dx[i]][cell.y+dy[i]];
                    pq.push({cell.x+dx[i], cell.y+dy[i], d[cell.x+dx[i]][cell.y+dy[i]]});
                }
            }
        }
        if(distanceCells(cell, Last_cell)<3){
                if(d[n][n]>t*distanceCells(cell, Last_cell)+cell.price){
                    d[n][n] = t*distanceCells(cell, Last_cell) + cell.price;
                }
        }
    }
    cout<<d[n][n]<<endl;
    return 0;
}