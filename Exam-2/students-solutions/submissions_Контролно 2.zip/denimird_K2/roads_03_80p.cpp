#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
const int maxn = 1005;
const int maxm = 1000005;
struct Edge{
    int m, n, price;
    bool operator<(const Edge& b){
        return price<b.price;
    }
};
int par[maxn];
int d[maxn];
bool bularr[maxn][maxn];
int find(int v){
    if(par[v]==v) return v;
    else{
        par[v] = find(par[v]);
        return par[v];
    }
}
bool unionBerlin(int u, int v){
    if(find(u)==find(v)) return false;
    if(d[u]>d[v]){
        par[v] = u;
    }
    else if(d[u]<d[v]){
        par[u] = v;
    }
    else{
        par[v] = u;
        d[u]++;
    }
    return true;
}
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    int n;
    long long m;
    cin>>n>>m;
    long long edge_count = 0;
    vector<Edge> new_edges;
    for(int i=0; i<m; i++){
        int a, b;
        cin>>a>>b;
        bularr[a][b] = true;
        bularr[b][a] = true;
        new_edges.push_back({a,b,1});
    }
    for(int i=1; i<=n; i++){
        par[i] = i;
        for(int j=1; j<i; j++){
            if(!bularr[i][j]){
                new_edges.push_back({i, j, 0});
            }
        }
    }
    sort(new_edges.begin(), new_edges.end());
    long long cnt = 0;
    long long price = 0;
    for(Edge e: new_edges){
        if(unionBerlin(e.m, e.n)){
            price+=e.price;
            cnt++;
        } 
        if(cnt==n-1){
            cout<<price<<endl;
            return 0;
        }
    }
}