#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
const int maxn = 1005;
const int maxm = 300005;
struct Edge{
    int m, n, price, id;
    bool operator<(const Edge& b){
        return price>b.price;
    }
};
int par[maxn];
int d[maxn];
int posses[maxm];
int find(int v){
    if(par[v]==v) return v;
    else{
        par[v] = find(par[v]);
        return par[v];
    }
}
bool unionBerlin(int u, int v){
    if(find(u)==find(v)) return false;
    if(d[u]>d[v]){
        par[v] = u;
    }
    else if(d[u]<d[v]){
        par[u] = v;
    }
    else{
        par[v] = u;
        d[u]++;
    }
    return true;
}
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    int n;
    long long m;
    int k;
    cin>>n>>m>>k;
    long long edge_count = 0;
    vector<Edge> new_edges;
    for(int i=0; i<m; i++){
        int a, b, l;
        cin>>a>>b>>l;
        new_edges.push_back({a,b,l,i});
    }
    for(int i=1; i<=n; i++){
        par[i] = i;
    }
    sort(new_edges.begin(), new_edges.end());
    long long cnt = 0;
    long long price = 0;
    for(Edge e: new_edges){
        if(unionBerlin(e.m, e.n)){
            posses[e.id] = 1;
            price+=e.price;
            cnt++;
        }
    }
    for(int i=0; i<m; i++){
        cout<<posses[i]<<"\n";
    }
    return 0;
}