#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
const int maxn = 1005;
const int maxm = 1000005;
struct Edge{
    int m, n, price;
    bool operator<(const Edge& b){
        return price<b.price;
    }
} edgesarr[maxm];
int par[maxn];
int d[maxn];
bool edges[maxn][maxn];
int find(int v){
    if(par[v]==v) return v;
    else{
        par[v] = find(par[v]);
        return par[v];
    }
}
bool unionBerlin(int u, int v){
    if(find(u)==find(v)) return false;
    if(d[u]>d[v]){
        par[v] = u;
    }
    else if(d[u]<d[v]){
        par[u] = v;
    }
    else{
        par[v] = u;
        d[u]++;
    }
    return true;
}
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    int n, m;
    cin>>n>>m;
    int a, b;
    vector<Edge> edges;
    int edge_count = 0;
    for(int i=0; i<m; i++){
        cin>>a>>b;
        edges[a][b] = true;
        edges[b][a] = true;
        edgesarr[edge_count++] = {a,b,1};
    }
    for(int i=1; i<=n; i++){
        par[i] = i;
        for(int j=1; j<i; j++){
            if(!edges[i][j]){
                edgesarr[edge_count++] = {i, j, 0};
            }
        }
    }
    sort(edgesarr, edgesarr+edge_count);
    int cnt = 0;
    int price = 0;
    int curr = 0;
    while(cnt<n-1){
        Edge e = edgesarr[curr++];
        if(unionBerlin(e.m, e.n)){
            price+=e.price;
            cnt++;
        }
    }
    cout<<price<<endl;
}
