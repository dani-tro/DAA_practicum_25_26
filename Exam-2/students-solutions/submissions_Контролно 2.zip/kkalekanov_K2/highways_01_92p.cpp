#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

using namespace std;

#define MAX 300009
#define MAXN 1009
// gradove, magistrali, partii
int N, M, K;

struct Edge
{
    int w;
    int u;
    int v;
    int idx;
};

bool cmp(Edge a, Edge b)
{
    return a.w > b.w;
}

vector<Edge> edges(MAX);

// ----------------------------------------------------------------

vector<int> parent(MAXN, -1);
vector<int> ranker(MAXN, 1);

int myfind(int v)
{
    if (parent[v] == -1)
    {
        return v;
    }
    return parent[v] = myfind(parent[v]);
}

bool myunion(int a, int b)
{
    a = myfind(a);
    b = myfind(b);

    if (a != b)
    {
        if (ranker[a] < ranker[b])
        {
            swap(a, b);
        }
        parent[b] = a;
        if (ranker[a] = ranker[b])
        {
            ranker[a]++;
        }
        return true;
    }
    return false;
}

// ----------------------------------------------------------------

vector<int> result(MAX, 0);
vector<bool> used(MAX, false);

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int a, b, t;

    cin >> N >> M >> K;
    for (int i = 0; i < M; i++)
    {
        cin >> a >> b >> t;
        edges[i].w = t;
        edges[i].u = a;
        edges[i].v = b;
        edges[i].idx = i;
    }

    sort(edges.begin(), edges.begin() + M, cmp);

    // kruskal

    for (int j = 1; j <= K; j++)
    {

        for (int i = 1; i <= N; i++)
        {
            parent[i] = -1;
            ranker[i] = 1;
        }

        for (int i = 0; i < M; i++)
        {
            if (!used[i])
            {
                int u = edges[i].u;
                int v = edges[i].v;
                
                if (myfind(u) != myfind(v))
                {
                    result[edges[i].idx] = j;
                    used[i] = true;
                    myunion(u, v);
                }
            }
        }
    }

    // for (int i = 0; i < M; i++)
    // {
    //     int u = edges[i].u;
    //     int v = edges[i].v;

    //     if (myfind(u) != myfind(v))
    //     {
    //         result[edges[i].idx] = partiya;
    //         highways_taken++;
    //         myunion(u, v);
    //         if (highways_taken == N - 1)
    //         {
    //             break;
    //         }
    //     }
    // }

    for (int i = 0; i < M; i++)
    {
        cout << result[i] << '\n';
    }
}