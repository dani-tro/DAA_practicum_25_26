#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

using namespace std;

#define MAX 1009

int gr[MAX][MAX] = {0};
bool visited[MAX] = {false};

int N, M;

vector<int> newgr[MAX];

void dfs(int u)
{
    if (visited[u])
    {
        return;
    }

    visited[u] = true;

    for (int v : newgr[u])
    {
        dfs(v);
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int a, b;

    cin >> N >> M;
    for (int i = 0; i < M; i++)
    {
        cin >> a >> b;

        gr[a][b] = 1;
        gr[b][a] = 1;
    }

    // print
    // for (int i = 1; i <= N; i++)
    // {
    //     for (int j = 1; j <= N; j++)
    //     {
    //         cout << gr[i][j] << ' ';
    //     }
    //     cout << endl;
    // }

    for (int i = 1; i <= N; i++)
    {
        for (int j = 1; j <= N; j++)
        {
            if (i != j)
            {
                gr[i][j] = 1 - gr[i][j];
            }
        }
    }


    //print
    // cout << endl;
    // cout << endl;

    // for (int i = 1; i <= N; i++)
    // {
    //     for (int j = 1; j <= N; j++)
    //     {
    //         cout << gr[i][j] << ' ';
    //     }
    //     cout << endl;
    // }

    for (int i = 1; i <= N; i++)
    {
        for (int j = 1; j <= N; j++)
        {
            if (gr[i][j] == 1)
            {
                newgr[i].push_back(j);
                newgr[j].push_back(i);
            }
        }
    }

    int cc = 0;
    for (int i = 1; i <= N; i++)
    {
        if (!visited[i])
        {
            cc++;
            dfs(i);
        }
    }

    // cout << cc << endl;
    // cout << M - cc << endl;
    cout << cc - 1 << endl;
}