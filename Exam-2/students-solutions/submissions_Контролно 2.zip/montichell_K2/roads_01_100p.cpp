#include <bits/stdc++.h>
using namespace std;

int n,m;
const int MAXN = 1005, MAXM = 500005;

int cnt [MAXN];
int uf[MAXN];

int find(int a)
{
    if(uf[a] == 0)
        return a;

    uf[a] = find(uf[a]);
    return uf[a];
}

int Union(int a, int b)
{
    if(a == b)
        return cnt[a];

    if(cnt[a] < cnt[b])
    {
        uf[a] = b;
        cnt[b] += cnt[a];
        return cnt[b];
    }
    else
    {
        uf[b] = a;
        cnt[a] += cnt[b];
        return cnt[a];
    }
}

int g[MAXN][MAXN];
vector<int> G[MAXN];
bool visited[MAXN];

void dfs(int u)
{
    visited[u] = true;

    for(int v : G[u])
    {
        if(visited[v] == false)
        {
            dfs(v);
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin >> n >> m;

    for(int i=1; i<=m; i++)
    {
        int a, b;
        cin >> a >> b;

        g[a][b] = 1;
        g[b][a] = 1;
    }

    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(g[i][j] == 0)
            {
                G[i].push_back(j);
            }
        }
    }

    int comps = 0;
    for(int i=1; i<=n; i++)
    {
        if(visited[i] == false)
        {
            dfs(i);
            comps++;
        }
    }

    cout << comps - 1 << endl;

    return 0;
}