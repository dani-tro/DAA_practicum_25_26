#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1005;
int uf[MAXN], cnt[MAXN];

int find(int a)
{
    if(uf[a] == 0)
        return a;

    uf[a] = find(uf[a]);
    return uf[a];
}

int Union(int a, int b)
{
    if(a == b)
        return cnt[a];

    if(cnt[a] < cnt[b])
    {
        uf[a] = b;
        cnt[b] += cnt[a];
        return cnt[b];
    }
    else
    {
        uf[b] = a;
        cnt[a] += cnt[b];
        return cnt[a];
    }
}

struct Edge{
    int from;
    int to;
    int w;
    int party;
    int ind;

    friend bool operator<(const Edge& a, const Edge& b)
    {
        return a.w > b.w;
    }
};

const int MAXM = 300005;
Edge g[MAXM];

int main()
{
    int n,m,k;
    cin >> n >> m >> k;

    for(int i=0; i<m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;

        g[i] = {u, v, w, 0, i};
    }

    sort(g, g+m);

    for(int p = 1; p<=k; p++)
    {
        for(int i=1; i<=n; i++)
        {
            uf[i] = 0;
            cnt[i] = 1;
        }

        for(int i=0; i<m; i++)
        {
            auto e = g[i];
            if(e.party != 0)
                continue;
            
            int fa = find(e.from), fb = find(e.to);
            if(fa == fb)
                continue;
            
            g[i].party = p;
            Union(fa, fb);
        }
    }

    int res[MAXM];
    
    for(int i=0; i<m; i++)
    {
        res[g[i].ind] = g[i].party;
    }

    for(int i=0; i<m; i++)
    {
        cout << res[i] << endl;
    }

    return 0;
}