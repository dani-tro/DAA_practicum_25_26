#include <bits/stdc++.h>
using namespace std;

const int MAXN = 505;
int board[MAXN][MAXN];

int n, t;

struct Edge{
    int to;
    int w;
};

struct Vertex{
    int v;
    int dist;

    friend bool operator<(const Vertex& a, const Vertex &b)
    {
        return a.dist > b.dist;
    }
};

bool in_board(int i, int j)
{
    return i>=0 && j>=0 && i<n && j<n;
}

vector<Edge> g[MAXN*MAXN*3];
int dist[MAXN*MAXN*3];

const int B1 = 0;
const int B2 = MAXN * MAXN;
const int B3 = MAXN * MAXN * 2;

int main()
{
    cin >> n >> t;

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            cin >> board[i][j];
        }
    }

    int movements[4][2] = {{0,1},{0,-1},{1,0},{-1,0}};

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            for(int k=0; k<4; k++)
            {
                int n_i = i + movements[k][0];
                int n_j = j + movements[k][1];

                if(!in_board(n_i, n_j))
                    continue;
                g[B1 + i*n + j].push_back({B2 + n_i * n + n_j, t});
                g[B2 + i*n + j].push_back({B3 + n_i * n + n_j, t + board[n_i][n_j]});
                g[B3 + i*n + j].push_back({B1 + n_i * n + n_j, t});
            }
        }
    }

    //start is B3
    //end is n-1 n-1 on either board

    for(int i=0; i<3*MAXN*MAXN; i++)
    {
        dist[i] = INT_MAX;
    }

    priority_queue<Vertex> q;
    q.push({B3, 0});
    dist[B3] = 0;

    while(!q.empty())
    {
        auto v = q.top();
        q.pop();

        if(dist[v.v] < v.dist)
            continue;
        
        for(auto u : g[v.v])
        {
            if(dist[u.to] > dist[v.v] + u.w)
            {
                dist[u.to] = dist[v.v] + u.w;
                q.push({u.to, dist[u.to]});
            }
        }
        
    }

    int res = min(dist[n*n - 1 + B1], dist[n*n-1 + B2]);
    res = min(res, dist[n*n-1 + B3]);

    cout << res << endl;
    
    return 0;
}