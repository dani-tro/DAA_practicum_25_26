#include <bits/stdc++.h>

const int maxn = 1100;
const int maxhighway = 300'300;
int h[maxn];
int par[maxn];

int n, m, k;

struct edge {
    int a;
    int b;
    int price;
    int id;
    int seenby;
};

class Comparator {
    bool operator()(edge& l, edge& r) {
        return l.price < r.price;
    }
};

std::queue<edge> q;
std::vector<edge> edges;

int find(int a) {
    if (par[a] == -1) return a;
    return par[a] = find(par[a]);
}

void uni(int a, int b) {
    a = find(a);
    b = find(b);

    if (h[a] > h[b]) {
        par[b] = a;
    } else {
        if (h[a] == h[b]) {
            h[a] += h[b];
        }
        par[a] = b;
    }
}

int highways[300'300];

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> m >> k;

    std::fill(par, par+maxn, -1);
    
    for (int i = 0; i < m; i++) {
        int u, v, w;
        std::cin >> u >> v >> w;
        edges.push_back({u, v, w, i, -1});
    }

    std::sort(edges.begin(), edges.end(), [](edge& l, edge& r) {
        return l.price > r.price;
    });

    for (int i = 0; i < edges.size(); i++) {
        q.push(edges[i]);
    }
    edges.clear();

    int party = 1;
    while (party <= k) {
        while (!q.empty()) {
            edge e = q.front();
            if (e.seenby == party) {
                party++;
                std::fill(par, par+maxn, -1);
                std::fill(h, h+maxn, 0);
                break;
            }
            q.pop();
            e.seenby = party;
            if (find(e.a) == find(e.b)) {
                q.push(e);
                continue;
            }
            
            highways[e.id] = party;
            uni(e.a, e.b);
        }

        if (q.empty()) break;
    }
    
    for (int i = 0; i < m; i++) {
        std::cout << highways[i] << "\n";
    }
}