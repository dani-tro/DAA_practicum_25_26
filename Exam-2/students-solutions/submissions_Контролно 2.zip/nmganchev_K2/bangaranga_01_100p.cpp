#include <bits/stdc++.h>

const int maxn = (510 * 510) * 3;
int n;
int t;
std::vector<std::pair<int, int>> g[maxn];

long long dist[maxn];
using node = std::pair<long long, int>;
std::priority_queue<node, std::vector<node>, std::greater<node>> pq;
bool visited[maxn];

void dijkstra() {
    std::fill(dist, dist + maxn, std::numeric_limits<long long>::max());

    dist[0] = 0;
    pq.push({dist[0], 0});

    while (!pq.empty()) {
        node n1 = pq.top();
        pq.pop();

        if (visited[n1.second] || dist[n1.second] != n1.first) continue;
        visited[n1.second] = true;

        for (auto [n2, w] : g[n1.second]) {
            if (dist[n2] > dist[n1.second] + (long long) w) {
                dist[n2] = dist[n1.second] + (long long) w;
                pq.push({dist[n2], n2});
            }
        }

    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n;
    std::cin >> t;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int a;
            std::cin >> a;
            int edge = i * n + j;
            int trans1 = n * n;
            int trans2 = n * n * 2;
            if (i > 0) {
                int edge1 = (i - 1) * n + j;
                g[edge1].push_back({trans1 + edge, t});
                g[trans1 + edge1].push_back({trans2 + edge, t});
                g[trans2 + edge1].push_back({edge, t + a});
            }
            if (j > 0) {
                int edge1 = i * n + j - 1;
                g[edge1].push_back({trans1 + edge, t});
                g[trans1 + edge1].push_back({trans2 + edge, t});
                g[trans2 + edge1].push_back({edge, t + a});
            }
            if (i < n - 1) {
                int edge1 = (i + 1) * n + j;
                g[edge1].push_back({trans1 + edge, t});
                g[trans1 + edge1].push_back({trans2 + edge, t});
                g[trans2 + edge1].push_back({edge, t + a});
            }
            if (j < n - 1) {
                int edge1 = i * n + j + 1;
                g[edge1].push_back({trans1 + edge, t});
                g[trans1 + edge1].push_back({trans2 + edge, t});
                g[trans2 + edge1].push_back({edge, t + a});
            }
        }
    }

    dijkstra();

    std::cout << std::min(dist[n * n - 1], std::min(dist[n * n * 2 - 1], dist[n * n * 3 - 1])) << "\n";
}