#include <bits/stdc++.h>

const int maxn = 1100;
int n, m;

bool g[maxn][maxn];
bool visited[maxn];

void dfs(int start) {
    if (visited[start]) return;

    visited[start] = true;

    for (int i = 1; i <= n; i++) {
        if (!g[i][start]) {
            dfs(i);
        }
    }
}


int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        std::cin >> x >> y;
        g[x][y] = true;
        g[y][x] = true;
    }

    int count = 0;

    for (int i = 1; i <= n; i++) {
        if (visited[i]) continue;
        count++;
        dfs(i);
    }
    std::cout << count - 1 << "\n";
}