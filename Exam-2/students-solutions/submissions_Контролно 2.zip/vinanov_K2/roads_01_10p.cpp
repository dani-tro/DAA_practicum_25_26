#include <bits/stdc++.h>
#include <vector>
using namespace std;

const int MAX_M = 1e5; 
int n,m, d[1005], par[1005], sz[1005];
vector<int> gr[1005];

int findU(int v){
    if(par[v] == -1) return v;
    return par[v] = findU(par[v]);
}

void myunion(int u, int v){
    u = findU(u);
    v = findU(v);

    if(u == v) return;
    if(d[u] > d[v]){
        par[v] = u;
        sz[u]+=sz[v];
    }
    else{
        par[u] = v;
        if(d[u] == d[v]) ++d[v];
        sz[v]+=sz[u];
    }
}

void bfsuni(int u){
    for(auto v : gr[u]){
        for(auto t : gr[v]){
            if(findU(u) != findU(t)){
                myunion(u,t);
            }
        }
    }
}

int main(){
    cin >> n >> m;
    int u,v;
    for(int i = 1; i <= n; ++i){
       cin >> u >> v;
       gr[u].push_back(v);
       gr[v].push_back(u); 
    }

    fill(par,par + n, -1);
    fill(sz,sz + n, 1);

    for(int i = 1; i <= n; ++i){
       bfsuni(i); 
    }

    sort(par, par + 1005);
    int ctr = 0;
    int start = par[0];

    for(int i = 2; i < n; ++i){
        if(start != par[i]){
            ++ctr;
            start = par[i];
        }
    }

    cout << n - ctr;

    // for(int i = 1; i <= n; ++i){
    //     cout << d[i] << endl;
    // }

}
