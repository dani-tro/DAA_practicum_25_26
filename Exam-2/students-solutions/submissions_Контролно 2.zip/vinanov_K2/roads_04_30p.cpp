#include <bits/stdc++.h>
#include <vector>
#include <set>
using namespace std;

const int MAX_M = 1e5; 
int n,m, d[1005], par[1005];
vector<int> gr[1005];

int findU(int v){
    if(par[v] == -1) return v;
    return par[v] = findU(par[v]);
}

void myunion(int u, int v){
    u = findU(u);
    v = findU(v);

    if(u == v) return;
    if(d[u] > d[v]){
        par[v] = u;
    }
    else{
        par[u] = v;
        if(d[u] == d[v]) ++d[v];
    }
}

// void bfsuni(int u){
//     for(auto v : gr[u]){
//         for(auto t : gr[v]){
//             if(findU(u) != findU(t)){
//                 myunion(u,t);
//             }
//         }
//     }
// }

int main(){
    cin >> n >> m;
    int u,v;
    for(int i = 1; i <= n; ++i){
       cin >> u >> v;
       gr[u].push_back(v);
       gr[v].push_back(u); 
    }

    fill(par,par + n + 1, -1);
    //cout << endl;
    for(int i = 1; i <= n; ++i){
        for(auto v : gr[i]){

            for(auto t : gr[v]){
                if(i != t && findU(i) != findU(t)){
                    // cout << i << " "<< t << endl;
                    myunion(i,t);
                }
            }

        }
    }
    sort(par, par + n + 1);
    int ctr = 0;
    int start = par[0];

    // for(int i = 1; i <= n; ++i){
    //     cout << par[i] << endl;
    // }


    

    for(int i = 1; i <= n; ++i){
        if(start != par[i]){
            ++ctr;
            start = par[i];
        }
    }

    if(ctr != 1){
        cout << (n - 1) - ctr;
    }
    else{
        cout << n - ctr;
    }
    
}