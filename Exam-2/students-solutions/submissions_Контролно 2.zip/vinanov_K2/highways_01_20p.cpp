#include <bits/stdc++.h>
#include <vector>
using namespace std;
const int MAX_N = 1005;
const int MAX_M = 3e6+ 3e4;
// d[MAX_N], par[MAX_N]
int n,m,k, hiway[MAX_M];
bool vis[MAX_N];
struct edge
{
    int u,v;
    long long w;
    int id;
};

vector<edge> edges;


// int findU(int v){
//     if(par[v] == -1) return v;
//     return par[v] = findU(par[v]);
// }

// void myunion(int u, int v){
//     u = findU(u);
//     v = findU(v);

//     if(u == v) return;
//     if(d[u] > d[v]) par[v] = u;
//     else{
//         par[u] = v;
//         if(d[u] == d[v]) ++d[v];
//     }
// }

void fillway(int partiq){
    fill(vis,vis + n,0);
    for(auto [u,v,w,id] : edges){
        if(hiway[id] == -1 && (!vis[u] || !vis[v]) ){
            vis[u] = true;
            vis[v] = true;
            hiway[id] = partiq;
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin >> n >> m >> k;

    int u,v,w;
    for(int i = 1; i <= m; ++i){
        cin >> u >> v >> w;
        edges.push_back({u,v,w,i});
    }
    sort(edges.begin(),edges.end(), [](edge a, edge b){return a.w > b.w;});
    fill(hiway,hiway + m + 1, -1);

    for(int i = 1; i <= k; ++i){
        fillway(i);
    }

    // fillway(1);
    // cout <<  "\n";
    for(int i = 1; i <= m; ++i){
        if(hiway[i] == -1) cout << 0 << "\n";
        else cout << hiway[i] << "\n";
    }


}