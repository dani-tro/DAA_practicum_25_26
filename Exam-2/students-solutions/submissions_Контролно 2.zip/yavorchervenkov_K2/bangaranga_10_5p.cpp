#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

#define int long long

const int MAX = 2e6 + 10;
int n, t, times[MAX], minVal, minVertice, minDist, sum, dist[MAX];
bool used[MAX], performed[MAX];
vector<int> gr[MAX];
queue<pair<int, int>> q;

int getIndex(int i, int j)
{
	return (i - 1) * n + j;
}

bool isValid(int i, int j)
{
	return 1 <= i && i <= n && 1 <= j && j <= n;
}

void distBFS()
{
	q.push({ n * n, 0 });
	used[n * n] = true;

	while(!q.empty())
	{
		auto p = q.front();
		q.pop();

		int v = p.first;
		dist[v] = p.second;
		for(int u : gr[v])
		{
			if(!used[u])
			{
				used[u] = true;
				q.push({ u, p.second + 1 });
			}
		}
	}
}

int BFS(int v)
{
	minVal = 1e9;
	minVertice = v;
	minDist = 1e9;
	used[v] = true;

	int val = 0;
	q.push({ v, 1 });
	while(!q.empty())
	{
		auto p = q.front();
		q.pop();

		int v = p.first;
		for(int u : gr[v])
		{
			q.push({ u, p.second + 1 });
			
			if(p.second == 3
					&& minVal > times[u]
					&& !performed[u])
			{	
				minVal = times[u];
				minVertice = u;
			}

			if(p.second < 3 && u == n * n)
			{
				minVertice = n * n;
				val += p.second * t;
				return val;
			}
		}

		if(p.second == 3 && !q.empty() && q.front().second == 4)
		{
			val += minVal;
			val += p.second * t;
			return val;
		}
	}
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> t;

	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			if(isValid(i - 1, j))
				gr[getIndex(i, j)].push_back(getIndex(i - 1, j));
			if(isValid(i + 1, j))
				gr[getIndex(i, j)].push_back(getIndex(i + 1, j));
			if(isValid(i, j - 1))
				gr[getIndex(i, j)].push_back(getIndex(i, j - 1));
			if(isValid(i, j + 1))
				gr[getIndex(i, j)].push_back(getIndex(i, j + 1));
		}
	}

	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			cin >> times[getIndex(i, j)];
		}
	}

	distBFS();
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			used[getIndex(i, j)] = false;
		}
	}

	sum = 0, minVertice = 1;
	performed[1] = true;
	while(minVertice != n * n)
	{
		sum += BFS(minVertice);
		performed[minVertice] = true;
		while(!q.empty()) q.pop();
	}

	cout << sum;
}