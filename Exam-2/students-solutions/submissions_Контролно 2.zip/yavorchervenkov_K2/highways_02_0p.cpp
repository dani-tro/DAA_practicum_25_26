#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

struct Edge
{
	int from, to, w, num;
};

const long long MAX = 3e5 + 10;
long long n, m, k, par[MAX], sz[MAX], party[MAX];
vector<long long> gr[MAX];
Edge edges[MAX];

int find(int x)
{
	if(x == par[x]) return x;
	else return par[x] = find(par[x]);
}

void unite(int rx, int ry)
{
	if(sz[rx] > sz[ry])
	{
		sz[rx] += sz[ry];
		par[ry] = rx;
	}
	else
	{
		sz[ry] += sz[rx];
		par[rx] = ry;
	}
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> k;

	for(int i = 1; i <= m; i++)
	{
		long long a, b, w;
		cin >> a >> b >> w;

		Edge e = { a, b, w, i };
		edges[i] = e;
	}

	sort(edges + 1, edges + m + 1);

	int curr = 1;
	while(curr <= k)
	{
		for(int i = m; i >= 1; i--)
		{
			Edge e = edges[i];
			if(party[e.num] != 0) continue;

			int x = e.from, y = e.to;
			int rx = find(x), ry = find(y);

			if (rx == ry) continue;
			unite(rx, ry);

			party[e.num] = curr;
		}
	}

	for(int i = 1; i <= m; i++)
	{
		cout << party[i] << endl;
	}
}