#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

const long long MAX = 1010;
long long n, m;
long long gr[MAX][MAX];
bool used[MAX];
vector<long long> lists[MAX];

void DFS(int v)
{
	used[v] = true;

	for(int u : lists[v])
	{
		if(!used[u]) DFS(u);
	}
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m;
	for(int i = 0; i < m; i++)
	{
		long long a, b;
		cin >> a >> b;
		
		gr[a][b] = 1;
		gr[b][a] = 1;
	}

	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			if(gr[i][j] == 1) gr[i][j] = 0;
			else
			{
				gr[i][j] = 1;
				lists[i].push_back(j);
			}
		}
	}

	int cnt = 0;
	for(int i = 1; i <= n; i++)
	{
		if(!used[i])
		{
			DFS(i);
			cnt++;
		}
	}

	cout << cnt - 1;
}