#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
using namespace std;

#define int long long

struct Edge
{
	int from, to, w, num;

	bool operator < (Edge e)
	{
		return w < e.w;
	}
};

const int MAX = 3e5 + 10;
int n, m, k, par[MAX], sz[MAX], party[MAX], used;
vector<int> gr[MAX];
vector<Edge> edges;

int find(int x)
{
	if(x == par[x]) return x;
	else return par[x] = find(par[x]);
}

void unite(int rx, int ry)
{
	if(sz[rx] > sz[ry])
	{
		sz[rx] += sz[ry];
		par[ry] = rx;
	}
	else
	{
		sz[ry] += sz[rx];
		par[rx] = ry;
	}
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m >> k;

	for(int i = 1; i <= n; i++)
	{
		par[i] = i;
		sz[i] = 1;
	}

	for(int i = 1; i <= m; i++)
	{
		int a, b, w;
		cin >> a >> b >> w;

		Edge e = { a, b, w, i };
		edges.push_back(e);
	}

	sort(edges.begin(), edges.end());

	int curr = 1;
	while(curr <= k)
	{
		for(int i = edges.size() - 1; i >= 0; i--)
		{
			Edge e = edges[i];
			if(party[e.num] != 0) continue;

			int x = e.from, y = e.to;
			int rx = find(x), ry = find(y);

			if(rx == ry) continue;
			unite(rx, ry);

			party[e.num] = curr;
			used++;

			if(used == m)
			{
				for(int i = 1; i <= m; i++)
				{
					cout << party[i] << endl;
				}
				return 0;
			}
		}

		curr++;

		for(int i = 1; i <= n; i++)
		{
			par[i] = i;
			sz[i] = 1;
		}
	}

	for(int i = 1; i <= m; i++)
	{
		cout << party[i] << endl;
	}
}