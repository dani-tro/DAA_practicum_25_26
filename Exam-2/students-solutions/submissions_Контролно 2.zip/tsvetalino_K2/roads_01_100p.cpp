#include <bits/stdc++.h>
#define int long long
using namespace std;

void sol() {
	int n; cin >> n;
	int m; cin >> m;
	
	vector<array<int, 2>> e;
	
	for (int i = 0; i < m; i += 1) {
		int u; cin >> u; u -= 1;
		int v; cin >> v; v -= 1;
		if (u > v) swap(u, v);
		e.push_back({u, v});
	}
	
	sort(e.begin(), e.end());
	
	vector<vector<int>> adj(n);
	
	{
		int ei = 0;
		for (int u = 0; u < n; u += 1) {
			for (int v = u+1; v < n; v += 1) {
				if (ei != e.size() && e[ei] == array<int,2>{u, v}) {
					ei += 1;
				} else {
					adj[u].push_back(v);
					adj[v].push_back(u);
				}
			}
		}
	}
	
	int c = 0;
	vector<int> vis(n);
	for (int i = 0; i < n; i += 1) {
		if (vis[i]) continue;
		queue<int> q;
		q.push(i);
		vis[i] = true;
		while (!q.empty()) {
			int u = q.front(); q.pop();
			for (auto v: adj[u]) {
				if (vis[v]) continue;
				vis[v] = true;
				q.push(v);
			}
		}
		c += 1;
	}
	cout << c-1 << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
}