#include <bits/stdc++.h>
#define int long long
using namespace std;

void sol() {
	int n; cin >> n;
	int t; cin >> t;
	vector<int> w(n*n);
	for (int i = 0; i < n*n; i += 1) cin >> w[i];
	
	vector<bool> vis(3*n*n);
	priority_queue<array<int, 4>> pq;
	pq.push({0, 0, 0, 0});
	vis[0] = false;
	
	auto maybe_push = [&](int d, int m, int y, int x) {
		if (y < 0 || y >= n || x < 0 || x >= n) return;
		if (vis[m*n*n+y*n+x]) return;
		if (m == 0) d -= w[y*n+x];
		pq.push({d, m, y, x});
	};
	
	while (true) {
		auto [d, m, y, x] = pq.top(); pq.pop();
		if (vis[m*n*n + y*n + x]) continue;
		vis[m*n*n + y*n + x] = true;
		if (y == n-1 && x == n-1) {
			cout << -d << "\n" << flush;
			return;
		}
		maybe_push(d-t, (m+1)%3, y+1, x);
		maybe_push(d-t, (m+1)%3, y-1, x);
		maybe_push(d-t, (m+1)%3, y, x+1);
		maybe_push(d-t, (m+1)%3, y, x-1);
	}
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
}