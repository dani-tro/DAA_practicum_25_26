#include <bits/stdc++.h>
#define int long long
using namespace std;

void sol() {
	int n; cin >> n;
	int m; cin >> m;
	int k; cin >> k;
	vector<int> ans(m, 0);
	vector<array<int, 4>> e(m);
	for (int i = 0; i < m; i += 1) {
		cin >> e[i][1]; e[i][1] -= 1;
		cin >> e[i][2]; e[i][2] -= 1;
		cin >> e[i][0];
		e[i][3] = i;
	}
	
	sort(e.begin(), e.end(), [&](auto x, auto y){return x > y;});
	
	vector<int> up(n);
	vector<int> us(n);
	
	auto find = [&](int x) {
		int y = x;
		while (up[y] != -1) y = up[y];
		while (x != y) {
			int p = up[x];
			up[x] = y;
			x = p;
		}
		return y;
	};
	
	auto uni = [&](int a, int b) {
		a = find(a);
		b = find(b);
		if (a == b) return;
		if (us[a] < us[b]) swap(a, b);
		up[b] = a;
		us[a] += us[b];
	};
	
	for (int t = 1; t <= k && !e.empty(); t += 1) {
		for (auto &x: us) x = 1;
		for (auto &x: up) x = -1;
		vector<array<int, 4>> f;
		for (auto [w, u, v, i]: e) {
			if (find(u) == find(v)) {
				f.push_back({w, u, v, i});
			} else {
				ans[i] = t;
				uni(u, v);
			}
		}
		swap(e, f);
	}
	
	for (auto x: ans) cout << x << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
}