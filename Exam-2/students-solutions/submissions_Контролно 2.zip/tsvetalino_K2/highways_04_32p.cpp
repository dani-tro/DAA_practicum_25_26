#include <bits/stdc++.h>
#define int long long
using namespace std;

void sol() {
	int n; cin >> n;
	int m; cin >> m;
	int k; cin >> k;
	vector<int> ans(m, 0);
	
	vector<vector<array<int, 3>>> adj(n);
	
	for (int i = 0; i < m; i += 1) {
		int u; cin >> u; u -= 1;
		int v; cin >> v; v -= 1;
		int w; cin >> w;
		adj[u].push_back({w, v, i});
		adj[v].push_back({w, u, i});
	}
	
	vector<bool> vis(n);
	
	for (int i = 0; i < n; i += 1) {
		if (vis[i]) continue;
		priority_queue<array<int, 3>> pq;
		pq.push({0, i, -1});
		
		while (!pq.empty()) {
			auto [w, u, idx] = pq.top(); pq.pop();
			if (vis[u]) continue;
			vis[u] = true;
			if (idx != -1) ans[idx] = 1;
			
			for (auto e: adj[u]) {
				if (vis[e[1]]) continue;
				pq.push(e);
			}
		}
	}
	
	for (auto x: ans) cout << x << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
}