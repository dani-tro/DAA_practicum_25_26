#include <bits/stdc++.h>
#define int long long
using namespace std;

void sol() {
	int n; cin >> n;
	int m; cin >> m;
	int k; cin >> k;
	vector<int> ans(m, 0);
	vector<array<int, 4>> e(m);
	for (int i = 0; i < m; i += 1) {
		cin >> e[i][1]; e[i][1] -= 1;
		cin >> e[i][2]; e[i][2] -= 1;
		cin >> e[i][0];
		e[i][3] = i;
	}
	
	sort(e.begin(), e.end(), [&](auto x, auto y){return x > y;});
	
	vector<int> vis(n);
	
	for (int t = 1; t <= k; t += 1) {
		vector<array<int, 4>> f;
		for (auto [w, u, v, i]: e) {
			if (vis[u] == t && vis[v] == t) f.push_back({w, u, v, i});
			else vis[u] = vis[v] = ans[i] = t;
		}
		swap(e, f);
	}
	
	for (auto x: ans) cout << x << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
}