#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 1010;

int n, m;
vector<int> g[MAXN];
vector<int> ng[MAXN];
bool visited[MAXN];

void dfs(int v)
{
	if (!visited[v])
	{
		visited[v] = true;
		for (auto u : ng[v])
		{
			dfs(u);
		}
	}
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m;
	int a, b;
	for (int i = 0; i < m; i++)
	{
		cin >> a >> b;
		g[a].push_back(b);
		g[b].push_back(a);
	}

	for (int i = 1; i <= n; i++)
	{
		sort(g[i].begin(), g[i].end(), [](int a, int b) {return a > b; });
		for (int j = 1; j <= n; j++)
		{
			if (i == j) continue;
			if (g[i].empty() || g[i].back() != j)
			{
				ng[i].push_back(j);
			}
			else
			{
				g[i].pop_back();
			}
		}
	}
	int count = 0;
	for (int i = 1; i <= n; i++)
	{
		if (!visited[i]) 
		{
			count++;
			dfs(i);
		}
	}
	cout << count - 1;
}