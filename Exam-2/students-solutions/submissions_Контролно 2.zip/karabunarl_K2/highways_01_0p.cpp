#include <iostream>
#include <vector>
#include <array>
#include <algorithm>
using namespace std;

const int MAXN = 1010;
const int MAXM = 300010;

int n, m, k;
vector<array<int, 3>> g[MAXN]; // weight, to, index
int covered[MAXN];
int stolen[MAXM];

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m >> k;
	int a, b, w;
	for (int i = 0; i < m; i++)
	{
		cin >> a >> b >> w;
		g[a].push_back({ w, b, i });
		g[b].push_back({ w, a, i });
	}

	for (int i = 1; i <= n; i++)
	{
		sort(g[i].begin(), g[i].end());
	}

	for (int i = 1; i <= k; i++)
	{

		int u;
		vector<array<int, 3>> hw = g[1]; // ? ?
		covered[1]++;
		for (int j = 1; j <= n - 1; j++)
		{
			int v = hw.back()[1];
			stolen[hw.back()[2]] = i;
			hw.pop_back();
			covered[v]++;
			vector<array<int, 3>> oldh;
			for (auto u : hw)
			{
				if (covered[u[1]] != k)
				{
					oldh.push_back(u);
				}
			} // already sorted
			vector<array<int, 3>> newh;
			for (auto u : g[v])
			{
				if (covered[u[1]] != k)
				{
					newh.push_back(u);
				}
			}
			sort(newh.begin(), newh.end());
			merge(oldh.begin(), oldh.end(), newh.begin(), newh.end(), hw.begin());
		}
	}

	for (int i = 1; i <= m; i++)
	{
		cout << stolen[i] << "\n";
	}
}