#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>

using namespace std;

#define MAXN 10
#define MAXM 100

int n, m, k;
int values[MAXN];

struct edge{
    int from, to, c, id;
};

bool cmp(const edge &e1, const edge &e2){
    return e1.c > e2.c;
}

vector<edge> edges(MAXN);
int par[MAXN], d[MAXN];

int find(int a){
    if (par[a] == a) return a;
    return par[a] == find(par[a]);
}

void uni(int a, int b){
    a = find(a);
    b = find(b);

    if (d[a] < d[b]) swap(a,b);
    par[b] = a;
    if (d[a] == d[b]) d[a]++;
    return;
}

void kruskal(int party){
    fill(values, values+MAXN, 0);
    int vertex = 0;
    sort(edges.begin(), edges.end(), cmp);
    for (int i = 0; i < m; ++i){
        if (find(edges[i].from) == find(edges[i].to)) continue;
        
        values[edges[i].id] = party;
        uni(edges[i].from, edges[i].to);
        vertex++;
        if(vertex == n - 1) break;
    }
    return;
}

int main() {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> k;

    for (int i = 0; i < m; ++i){
        cin >> edges[i].from >> edges[i].to >> edges[i].c;
        par[i] = i;
        edges[i].id = i;
    }

    sort(edges.begin(), edges.end(), cmp);
    for (int i = 0; i < m; ++i){
        cout << edges[i].from << edges[i].to << edges[i].c << '\n';
    }

    for (int i = 1; i <= k; ++i){
        kruskal(i);
    }



    for (int i = 0; i < m; ++i){
        cout << values[i] << '\n';
    }

    return 0;
}