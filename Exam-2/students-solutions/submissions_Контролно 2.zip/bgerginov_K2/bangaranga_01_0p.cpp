#include <iostream>

int main()
{
      std::cout << 31;
      return 0;
}