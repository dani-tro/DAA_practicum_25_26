#include <bits/stdc++.h>
using namespace std;

#define MAX 1100

bool g[MAX][MAX];
int n, m;

void dfs(bool g[][MAX], int start, vector<bool>& visited)
{
    visited[start] = true;
    for(int i = 1; i <= n; i++)
    {
        if(g[start][i] == 1 && visited[i] == 0)
        {
            dfs(g, i, visited);
        }
    }
}


int connect(bool g[][MAX])
{
    vector<bool> visited(n+1, 0);
    int cnt = 0;
    for(int i = 1; i <= n; i++)
    {
        if(!visited[i])
        {
            dfs(g, i, visited);
            cnt++;
        }
    }
    return cnt;
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int a,b;
        cin >> a >> b;
        g[a][b] = 1;
        g[b][a] = 1;
    }

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            if(g[i][j] == 0)
                g[i][j] = 1;
            else g[i][j] = 0;
        }
    }


    cout << connect(g) - 1 << endl;

    

    return 0;
}