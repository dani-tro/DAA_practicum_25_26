#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

#define MAX_K 10000

struct Edge
{
    int u;
    int v;
    long long w;
    int partiq;
    int id;

    bool operator<(const Edge& other)
    {
        return w > other.w;
    }
};

bool cmp(const Edge& e1, const Edge& e2)
{
    return e1.id < e2.id;
}



int main()
{
    int n,m,k;
    cin >> n>>m>>k;
    vector<Edge> edges;
    for(int i = 1; i <= m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back({u,v,w,0,i});
    }

    sort(edges.begin(), edges.end());
    
    for(int i = 1; i <= k; i++)
    {
        vector<bool> visited(n+1, 0);
        for(auto& edge : edges)
        {
            if((edge.partiq != 0) || (visited[edge.u] && visited[edge.v])) continue;
            else
            {
                edge.partiq = i;
                if(!visited[edge.u])
                    visited[edge.u] = true;
                if(!visited[edge.v])
                    visited[edge.v] = true;
            }
        }
    }

    

    sort(edges.begin(), edges.end(), cmp);
    for(int i = 0; i < m; i++)
    {
        cout << edges[i].partiq << "\n";
    }



    return 0;
}