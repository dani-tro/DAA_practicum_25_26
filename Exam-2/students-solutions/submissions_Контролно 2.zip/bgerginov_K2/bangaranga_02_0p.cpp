#include <iostream>

int main()
{
    std::cout << 65;

    return 0;
}