#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

#define MAX_K 10000

struct Edge
{
    int u;
    int v;
    long long w;
    int partiq;
    int id;

    bool operator<(const Edge& other)
    {
        return w > other.w;
    }
};

bool cmp(const Edge& e1, const Edge& e2)
{
    return e1.id < e2.id;
}

int find_set(int u, vector<int>& parent)
{
    if(parent[u] == u)
        return u;
    return find_set(parent[u], parent);
}



int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int n,m,k;
    cin >> n>>m>>k;
    vector<Edge> edges;
    for(int i = 1; i <= m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back({u,v,w,0,i});
    }

    sort(edges.begin(), edges.end());
    
    for(int i = 1; i <= k; i++)
    {
        vector<int> parent(n+1);
        for(int j = 1; j <= n; j++)
        {
            parent[j] = j;
        }
        for(auto& edge : edges)
        {
            if((edge.partiq != 0) || (find_set(edge.u, parent) == find_set(edge.v, parent))) continue;
            else
            {
                edge.partiq = i;
                parent[edge.u] = edge.v;
            }
        }
    }

    

    sort(edges.begin(), edges.end(), cmp);
    for(int i = 0; i < m; i++)
    {
        cout << edges[i].partiq << "\n";
    }



    return 0;
}