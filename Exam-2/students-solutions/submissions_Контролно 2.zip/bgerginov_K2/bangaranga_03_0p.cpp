#include <bits/stdc++.h>
using namespace std;

#define MAX 110000

long long matrix[4][4];



int main()
{
    long long n, t; cin >> n >> t;
    long long min1 = 10000000000;
    long long min2 = 10000000000;
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            cin >> matrix[i][j];
            if(matrix[i][j] < min1)
            {
                long long temp;
                temp = min1;
                min1 = matrix[i][j];
                min2 = temp;
            }
        }
        
    }

    cout << min1 + min2 + 9*t;





    return 0;
}