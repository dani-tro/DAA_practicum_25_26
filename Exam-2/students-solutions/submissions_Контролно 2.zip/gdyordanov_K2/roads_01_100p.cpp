#include <iostream>
#include <cstdint>
#include <queue>

#define MAX_CITIES 1010
#define MAX_ROADS 500_010

using namespace std;

uint64_t N, M;

bool roads[MAX_CITIES][MAX_CITIES];
bool visitedCities[MAX_CITIES];

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> N >> M;

    for (uint64_t i = 0; i < M; i++){
        uint64_t a, b;
        cin >> a >> b;
        roads[a][b] = true;
        roads[b][a] = true;
    }

    for (uint64_t i = 1; i <= N - 1; i++){
        for (uint64_t j = i + 1; j <= N; j++){
            roads[i][j] = !roads[i][j];
            roads[j][i] = !roads[j][i];
        }
    }

    uint64_t nIsolated = 0;

    for (uint64_t i = 1; i <= N; i++){
        if (visitedCities[i]) continue;
        nIsolated++;
        queue<uint32_t> queue;
        queue.push(i);

        while(!queue.empty()){
            uint32_t city = queue.front();
            queue.pop();

            visitedCities[city] = true;

            for (uint64_t j = 1; j <= N; j++){
                if (visitedCities[j] || !roads[city][j]) continue;
                queue.push(j);
            }
        }
    }

    cout << nIsolated - 1 << endl;

    return 0;
}