#include <iostream>
#include <cstdint>
#include <queue>
#include <cassert>

#define MAX_N 503
#define MAX_T 1_000_010
#define MAX_PANEL_TIME 100010

using namespace std;

struct Point {
    int32_t x;
    int32_t y;

    Point operator+(const Point& p) const{
        return {x + p.x, y + p.y};
    }

    bool operator!=(const Point& p) const{
        return x != p.x || y != p.y;
    }

    bool operator==(const Point& p) const{
        return x == p.x & y == p.y;
    }

    // bool operator <
};

struct Panel {
    uint32_t time;
    Point parent;
    Point pos;
    uint64_t distance = 0xffffffffffffffff;

    bool operator<(const Panel& p) const{
        return time < p.time;
    }
    bool operator>(const Panel& p) const{
        return time > p.time;
    }
};

Panel scene[MAX_N][MAX_N];
bool visited[MAX_N][MAX_N];
Point offsets[] = {
    {0, 3},
    {1, 2},
    {2, 1},
    {3, 0},
    {2, -1},
    {1, -2},
    {0, -3},
    {-1, -2},
    {-2, -1},
    {-3, 0},
    {-2, 1},
    {-1, 2}
};
#define N_OFFSETS 12

uint64_t N, T;

template <typename T>
T& matrixGet(T matrix[MAX_N][MAX_N], Point p){
    return matrix[p.x][p.y];
}

uint32_t getDistance(const Point& p1, const Point& p2){
    return abs((int)p1.x - (int)p2.x) + abs((int)p1.y - (int)p2.y);
}

bool outOfBounds(const Point& p, uint32_t high){
    return p.x < 0 || p.y < 0 || p.x >= high || p.y >= high;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> N >> T;

    for (uint64_t y = 0; y < N; y++){
        for (uint64_t x = 0; x < N; x++){
            cin >> scene[x][y].time;
            scene[x][y].parent = {(int)x, (int)y};
            scene[x][y].pos = {(int)x, (int)y};
        }   
    }

    priority_queue<Panel, vector<Panel>, greater<Panel>> pq;
    scene[0][0].distance = 0;
    pq.push(matrixGet<Panel>(scene, {0, 0}));
    visited[0][0] = true;
    uint32_t finalDistance = 0;

    while(true){
        assert(!pq.empty());
        Panel p = pq.top();
        pq.pop();
        matrixGet<bool>(visited, p.pos) = true;

        if (getDistance(p.pos, {(int)N-1, (int)N-1}) < 3){
            // finalDistance = getDistance(p.pos, {(int)N-1, (int)N-1}) * T;
            Panel* __p = &matrixGet<Panel>(scene, {(int)N-1, (int)N-1});
            __p->parent = p.pos;
            __p->distance = p.distance + T * getDistance(p.pos, {(int)N-1, (int)N-1});
            break;
        }

        for (uint64_t i = 0; i < N_OFFSETS; i++){
            if (outOfBounds(p.pos + offsets[i], N)) continue;
            if (!matrixGet<bool>(visited, p.pos + offsets[i])){
                Panel* next = &matrixGet<Panel>(scene, p.pos + offsets[i]);
                if (p.distance + next->time + 3 * T < next->distance){
                    next->distance = p.distance + next->time + 3 * T;
                    next->parent = p.pos;
                    pq.push(matrixGet<Panel>(scene, p.pos + offsets[i]));
                }
            }
        }
    }

    Panel backtracker = matrixGet<Panel>(scene, {(int)N-1, (int)N-1});

    cout << backtracker.distance << endl;

    return 0;
}