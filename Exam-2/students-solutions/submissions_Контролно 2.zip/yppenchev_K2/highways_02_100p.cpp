#include <algorithm>
#include <iostream>
#include <vector>
#define endl '\n'
using namespace std;

const int MAXN = 1000;
const int MAXM = 300000;

struct edge
{
    int u, v, w, idx;

    bool operator< (const edge& other) const
    {
        return w < other.w;
    }
};

int ans[MAXM + 5];
int par[MAXN + 5], rk[MAXN + 5];
int u[MAXM + 5], v[MAXM + 5], w[MAXM + 5];

int find_par(int u)
{
    if (u == par[u]) return u;
    return par[u] = find_par(par[u]);
}

void unite(int u, int v)
{
    u = find_par(u);
    v = find_par(v);

    if (rk[u] < rk[v]) swap(u, v);

    if (rk[u] == rk[v]) rk[u]++;
    par[v] = u;
}

int main()
{
    int n, m, k;
    cin >> n >> m >> k;

    vector<edge> edges;
    for (int i = 1; i <= m; ++ i)
    {
        cin >> u[i] >> v[i] >> w[i];
        edges.push_back({u[i], v[i], w[i], i});
    }
    sort(edges.begin(), edges.end());
    reverse(edges.begin(), edges.end());

    for (int i = 1; i <= k; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            par[j] = j;
            rk[j] = 1;
        }

        for (auto e : edges)
        {
            if (ans[e.idx]) continue;
            if (find_par(e.u) != find_par(e.v))
            {
                unite(e.u, e.v);
                ans[e.idx] = i;
            }
        }

        if (i % 100 == 0)
        {
            edges.clear();
            for (int j = 1; j <= m; ++ j)
            {
                if (ans[j]) continue;
                edges.push_back({u[j], v[j], w[j], j});
            }
            sort(edges.begin(), edges.end());
            reverse(edges.begin(), edges.end());
        }
    }

    for (int i = 1; i <= m; ++ i)
    {
        cout << ans[i] << endl;
    }

    return 0;
}
