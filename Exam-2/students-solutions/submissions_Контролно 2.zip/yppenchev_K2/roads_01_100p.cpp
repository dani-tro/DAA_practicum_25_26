#include <iostream>
#include <queue>
#define endl '\n'
using namespace std;

const int MAXN = 1000;

int n, m;
bool used[MAXN + 5];
int a[MAXN + 5][MAXN + 5];

void BFS(int u)
{
    queue<int> q;
    q.push(u);
    used[u] = true;

    while (!q.empty())
    {
        u = q.front();
        q.pop();

        for (int i = 1; i <= n; ++ i)
        {
            if (a[u][i] and !used[i])
            {
                used[i] = true;
                q.push(i);
            }
        }
    }
}

int main()
{
    cin >> n >> m;

    for (int i = 1; i <= m; ++ i)
    {
        int u, v;
        cin >> u >> v;
        a[u][v] = a[v][u] = 1;
    }

    for (int i = 1; i <= n; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            a[i][j] = 1 - a[i][j];
        }
    }

    int cnt = 0;
    for (int i = 1; i <= n; ++ i)
    {
        if (!used[i])
        {
            BFS(i);
            cnt++;
        }
    }

    cout << cnt - 1 << endl;

    return 0;
}
