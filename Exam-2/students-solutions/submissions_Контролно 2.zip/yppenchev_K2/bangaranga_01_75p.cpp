#include <iostream>
#include <vector>
#include <queue>
#define endl '\n'
using namespace std;

const int MAXN = 500;
const long long INF = 1e18;

int a[MAXN + 5][MAXN + 5];
long long dist[MAXN * MAXN + 5][3];
vector< pair< pair<int, int>, int > > G[MAXN * MAXN + 5][3];

int main()
{
    int n, t;
    cin >> n >> t;

    for (int i = 1; i <= n; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            cin >> a[i][j];
        }
    }

    for (int i = 1; i <= n; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            for (int p = 0; p <= 2; ++ p)
            {
                if (i > 1)
                {
                    G[(i - 1) * n + j][0].push_back({{(i - 2) * n + j, 1}, t});
                    G[(i - 1) * n + j][1].push_back({{(i - 2) * n + j, 2}, t});
                    G[(i - 1) * n + j][2].push_back({{(i - 2) * n + j, 0}, t + a[i - 1][j]});
                }

                if (i < n)
                {
                    G[(i - 1) * n + j][0].push_back({{i * n + j, 1}, t});
                    G[(i - 1) * n + j][1].push_back({{i * n + j, 2}, t});
                    G[(i - 1) * n + j][2].push_back({{i * n + j, 0}, t + a[i + 1][j]});
                }

                if (j > 1)
                {
                    G[(i - 1) * n + j][0].push_back({{(i - 1) * n + (j - 1), 1}, t});
                    G[(i - 1) * n + j][1].push_back({{(i - 1) * n + (j - 1), 2}, t});
                    G[(i - 1) * n + j][2].push_back({{(i - 1) * n + (j - 1), 0}, t + a[i][j - 1]});
                }

                if (j < n)
                {
                    G[(i - 1) * n + j][0].push_back({{(i - 1) * n + (j + 1), 1}, t});
                    G[(i - 1) * n + j][1].push_back({{(i - 1) * n + (j + 1), 2}, t});
                    G[(i - 1) * n + j][2].push_back({{(i - 1) * n + (j + 1), 0}, t + a[i][j + 1]});
                }
            }
        }
    }

    for (int i = 1; i <= n; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            for (int p = 0; p <= 2; ++ p)
            {
                dist[(i - 1) * n + j][p] = INF;
            }
        }
    }

    dist[1][0] = 0;
    priority_queue< pair< int, pair<int, int> > > pq;
    pq.push({0, {1, 0}});

    while (!pq.empty())
    {
        long long d = -pq.top().first;
        int u = pq.top().second.first;
        int p = pq.top().second.second;
        pq.pop();

        if (d > dist[u][p]) continue;

        for (auto [wh, w] : G[u][p])
        {
            int v = wh.first;
            int p2 = wh.second;
            if (dist[v][p2] > d + w)
            {
                dist[v][p2] = d + w;
                pq.push({-dist[v][p2], {v, p2}});
            }
        }
    }

    cout << min(dist[n * n][0], min(dist[n * n][1], dist[n * n][2])) << endl;

    return 0;
}
