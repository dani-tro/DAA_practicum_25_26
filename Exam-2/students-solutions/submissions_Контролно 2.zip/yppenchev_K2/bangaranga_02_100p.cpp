#include <iostream>
#include <vector>
#include <queue>
#define endl '\n'
using namespace std;

const int MAXN = 500;
const long long INF = 1e18;

int a[MAXN + 5][MAXN + 5];
vector<int> G[MAXN * MAXN + 5];
long long dist[MAXN * MAXN + 5][3];

int main()
{
    int n, t;
    cin >> n >> t;

    for (int i = 1; i <= n; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            cin >> a[i][j];
        }
    }

    for (int i = 1; i <= n; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            for (int p = 0; p <= 2; ++ p)
            {
                if (i > 1)
                {
                    G[(i - 1) * n + j].push_back((i - 2) * n + j);
                }

                if (i < n)
                {
                    G[(i - 1) * n + j].push_back(i * n + j);
                }

                if (j > 1)
                {
                    G[(i - 1) * n + j].push_back((i - 1) * n + (j - 1));
                }

                if (j < n)
                {
                    G[(i - 1) * n + j].push_back((i - 1) * n + (j + 1));
                }
            }
        }
    }

    for (int i = 1; i <= n; ++ i)
    {
        for (int j = 1; j <= n; ++ j)
        {
            for (int p = 0; p <= 2; ++ p)
            {
                dist[(i - 1) * n + j][p] = INF;
            }
        }
    }

    dist[1][0] = 0;
    priority_queue< pair< int, pair<int, int> > > pq;
    pq.push({0, {1, 0}});

    while (!pq.empty())
    {
        long long d = -pq.top().first;
        int u = pq.top().second.first;
        int p = pq.top().second.second;
        pq.pop();

        if (d > dist[u][p]) continue;

        int newp = (p + 1) % 3;

        for (auto v : G[u])
        {
            int i = (v - 1) / n + 1;
            int j = v - (i - 1) * n;
            if (dist[v][newp] > d + t + (newp == 0 ? a[i][j] : 0))
            {
                dist[v][newp] = d + t + (newp == 0 ? a[i][j] : 0);
                pq.push({-dist[v][newp], {v, newp}});
            }
        }
    }

    cout << min(dist[n * n][0], min(dist[n * n][1], dist[n * n][2])) << endl;

    return 0;
}
