#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

#define endl '\n'

using namespace std;

const int MAXN = 1003, MAXM = 5e5 + 3;

bool isEdge[MAXN][MAXN];
int parent[MAXN], depth[MAXN];

int edges[MAXM][2];

int findParent(int x)
{
    if (x == parent[x])
    {
        return x;
    }

    return parent[x] = findParent(parent[x]);
}

bool combine(int x, int y)
{
    int parentX = findParent(x);
    int parentY = findParent(y);

    if (parentX == parentY)
    {
        return false;
    }

    if (depth[parentY] > depth[parentX])
    {
        swap(parentY, parentX);
    }

    parent[parentY] = parentX;
    depth[parentX] += depth[parentY];

    return true;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    cin >> n >> m;

    for (int i = 0; i < m; ++i)
    {
        int x, y;
        cin >> x >> y;

        isEdge[x][y] = isEdge[y][x] = true;

        edges[i][0] = x;
        edges[i][1] = y;
    }

    int components = n;

    for (int i = 1; i <= n; ++i)
    {
        depth[i] = 1;
        parent[i] = i;

        for (int j = i + 1; j <= n; ++j)
        {
            if (i == j || isEdge[i][j])
            {
                continue;
            }

            if (combine(i, j))
            {
                --components;
            }
        }
    }

    int preserved = 0;

    for (int i = m - 1; i >= 0 && components > 1; --i)
    {
        int x = edges[i][0], y = edges[i][1];

        if (combine(x, y))
        {
            --components;
            ++preserved;
        }
    }

    cout << preserved << endl;

    return 0;
}