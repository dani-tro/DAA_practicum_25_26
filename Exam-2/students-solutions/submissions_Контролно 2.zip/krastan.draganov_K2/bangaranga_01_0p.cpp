#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <unordered_set>

#define endl '\n'

using namespace std;

const int MAXN = 503;
const long long INF = 1e18 + 3;

const int dirs[4][2] = {
    {0, -1},
    {0, 1},
    {-1, 0},
    {1, 0}};

long long matrix[MAXN][MAXN];

vector<pair<int, long long>> edges[MAXN * MAXN];
long long dist[MAXN * MAXN];

int n;
long long t;

int getV(int x, int y)
{
    return x * n + y;
}

bool isValid(int x, int y)
{
    return x >= 0 && x < n && y >= 0 && y < n;
}

unordered_set<int> inCycle;

void findEdges(int x, int y, int startV, int counter)
{
    if (counter > 0)
    {
        edges[startV].push_back({getV(x, y), 1ll * counter * t + matrix[x][y]});
    }

    if (counter == 3)
    {
        return;
    }

    for (int i = 0; i < 4; ++i)
    {
        int nextX = x + dirs[i][0];
        int nextY = y + dirs[i][1];

        int nextV = getV(nextX, nextY);

        if (isValid(nextX, nextY) && !inCycle.count(nextV))
        {
            inCycle.insert(nextV);
            findEdges(nextX, nextY, startV, counter + 1);
            inCycle.erase(nextV);
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> t;

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            cin >> matrix[i][j];
        }
    }

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            int startV = getV(i, j);

            inCycle.clear();
            inCycle.insert(startV);

            findEdges(i, j, startV, 0);
        }
    }

    for (int i = 0; i <= n * n; ++i)
    {
        dist[i] = INF;
    }

    int s = getV(0, 0), e = getV(n - 1, n - 1);

    priority_queue<pair<long long, int>> dijkstra;
    dijkstra.push({0, s});

    dist[s] = 0ll;

    while (!dijkstra.empty())
    {
        pair<long long, int> curr = dijkstra.top();
        dijkstra.pop();

        int currV = curr.second;

        cout << currV << endl;

        if (currV == e)
        {
            break;
        }

        for (pair<int, long long> &edge : edges[currV])
        {
            int nextV = edge.first;
            long long w = edge.second;

            long long newDist = dist[currV] + w;

            if (newDist < dist[nextV])
            {
                dist[nextV] = newDist;
                dijkstra.push({-dist[nextV], nextV});
            }
        }
    }

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            cout << i << ", " << j << " -> " << dist[getV(i, j)] << endl;
        }
    }

    cout << dist[e] << endl;

    return 0;
}
