#include <iostream>
#include <vector>
#include <queue>

typedef long long ll;
void bangaranga();

int main()
{
    bangaranga();
}

typedef std::pair<ll, std::pair<int, int>> w_to_coord;
void bangaranga()
{
    int n, t;

    std::cin >> n >> t;
    std::vector<std::vector<int>> graph(n, std::vector<int>(n, 0));
    std::vector<std::vector<ll>> dist(n, std::vector<ll>(n, 1e18));

    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j) std::cin >> graph[i][j];

    std::priority_queue<w_to_coord, std::vector<w_to_coord>, std::greater<w_to_coord>> pq;
    std::pair<int, int> start(0, 0);
    pq.emplace(0, start);
    dist[0][0] = 0;
    
    int d_x[4] = { -1, 1, 0, 0 };
    int d_y[4] = { 0, 0, -1, 1 };

    while (!pq.empty())
    {
        std::pair<ll, std::pair<int, int>> next = pq.top();
        ll d = next.first;
        std::pair<int, int> u = next.second;
        pq.pop();

        int x_u = u.first;
        int y_u = u.second;

        if (d != dist[x_u][y_u]) continue;
        
        for (int i = 0; i < 4; ++i)
        {
            int next_x = x_u + d_x[i];
            int next_y = y_u + d_y[i];

            if (next_x < 0 || next_x >= n || next_y < 0 || next_y >= n) continue;
            ll new_w = dist[x_u][y_u] + t;

            bool is_not_start = (next_x == 0 && next_y != 0) || (next_x != 0 && next_y == 0) || (next_x != 0 && next_y != 0);
            if (is_not_start && (next_x + next_y) % 3 == 0)
            {
                new_w += graph[next_x][next_y];
            }
            if (new_w < dist[next_x][next_y])
            {
                dist[next_x][next_y] = new_w;
                std::pair<int, int> next_el(next_x, next_y);
                pq.emplace(new_w, next_el);
            }
        }
    }
    std::cout << dist[n - 1][n - 1];
}