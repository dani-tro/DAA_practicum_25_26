#include <bits/stdc++.h>

using namespace std;

#define MAXN 1100
#define MAX 330000

int n, m, k, a, b, c;

vector<pair<pair<int, pair<int, int>>, int>> edges;
int asigned[MAX];
bool visited[MAX], used[MAXN];

int main()
{
    cin >> n >> m >> k;

    for (int i = 1; i <= m; i++)
    {
        cin >> a >> b >> c;
        edges.push_back({{c, {a, b}}, i});
    }

    sort(edges.begin(), edges.end());
    reverse(edges.begin(), edges.end());

    for (int i = 1; i <= k; i++)
    {
        fill(used, used + n + 10, false);
        for (int j = 0; j < m; j++)
        {
            int u = edges[j].first.second.first;
            int v = edges[j].first.second.second;

            if (!visited[j])
            {
                if (used[u] && used[v])
                    continue;
                else
                {
                    used[u] = true;
                    used[v] = true;
                    asigned[edges[j].second] = i;
                    visited[j] = true;
                }
            }
        }
    }

    for (int i = 1; i <= m; i++)
        cout << asigned[i] << '\n';

    return 0;
}