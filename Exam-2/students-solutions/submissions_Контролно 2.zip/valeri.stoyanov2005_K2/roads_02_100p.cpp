#include <bits/stdc++.h>

using namespace std;

#define MAX 1100

int n, m, a, b, ccomp = 0;

int grid[MAX][MAX];

bool visited[MAX];

void dfs(int start)
{
    visited[start] = true;

    for (int i = 1; i <= n; i++)
    {
        if (grid[start][i] == 1 && !visited[i])
            dfs(i);
    }
}

int main()
{
    cin >> n >> m;

    for (int i = 0; i < m; i++)
    {
        cin >> a >> b;

        grid[a][b] = 1;
        grid[b][a] = 1;
    }

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (i != j)
                grid[i][j] = 1 - grid[i][j];
        }
    }

    int counter = 0;
    for (int i = 1; i <= n; i++)
    {
        if (!visited[i])
        {
            ccomp++;
            dfs(i);
        }
    }

    cout << ccomp - 1 << '\n';

    return 0;
}