#include <iostream>
#include <queue>
#include <algorithm>
#include <math.h>
using namespace std;

const int MAX = 1e7 + 10;
int n, m, s, a[MAX], b[MAX], d[MAX];
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

bool p(long long x)
{
	return false;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m >> s;

	for(int i = 0; i < n; i++)
	{
		cin >> a[i] >> b[i];
		pq.push({ b[i], a[i] });
	}

	for(int i = 0; i < m; i++)
	{
		cin >> d[i];
	}

	for(int i = 0; i < m; i++)
	{
		int cost = pq.top().second;
		int dist = max(cost - d[i], d[i] - cost);
		cout << pq.top().first + dist << endl;
		pq.pop();
	}
}