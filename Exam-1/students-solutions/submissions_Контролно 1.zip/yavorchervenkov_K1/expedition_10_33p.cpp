#include <iostream>
#include <queue>
#include <algorithm>
#include <math.h>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, m, c, a[MAX], b[MAX], d[MAX];

bool p(long long x)
{
	return false;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m >> c;

	for(long long i = 0; i < n; i++)
	{
		cin >> a[i] >> b[i];
	}

	for(long long i = 0; i < m; i++)
	{
		cin >> d[i];
	}

	for(long long i = 0; i < m; i++)
	{
		long long sum = 1e18;
		for(long long j = 0; j < n; j++)
		{
			long long dist = a[j], fuel = b[j];
			long long finalDist = max(dist - d[i], d[i] - dist);

			sum = min(sum, fuel + finalDist * c);
		}

		cout << sum << endl;
	}
}