#include <iostream>
#include <queue>
#include <algorithm>
#include <math.h>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, k, a1, a2, x, y, z, m;
vector<long long> a;

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> k;
	cin >> a1 >> a2 >> x >> y >> z >> m;

	a.push_back(a1);
	a.push_back(a2);

	for(int i = 2; i < n; i++)
	{
		a.push_back((a[i - 2] * x + a[i - 1] * y + z) % m);
	}

	int diff = 1e9;
	for(int i = 0; i < n - 1; i++)
	{
		for(int j = i + 1; j < n; j++)
		{
			int l = 0, r = 0;
			bool valid = false;
			for(int id = i; id <= j; id++)
			{
				if(l < k) l += a[id];
				else if(r < k) r += a[id];
				else
				{
					valid = true;
					break;
				}
			}

			if(valid) diff = min(diff, j - i);
		}
	}

	if(diff == 1e9) cout << -1;
	else cout << diff;
}