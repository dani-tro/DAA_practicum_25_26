#include <iostream>
#include <algorithm>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, k, a[MAX], origA[MAX], cnt[MAX];

bool p(long long x)
{
	long long height = 0, currHeight = 0;
	long long currIndex = n - 1;

	while(true)
	{
		for(long long j = 0; j < x; j++)
		{
			currHeight = max(currHeight, a[currIndex]);
			currIndex--;
			if(currIndex < 0)
			{
				height += currHeight;
				return height <= k;
			}
		}
		height += currHeight;
		if(height > k) return false;

		currHeight = 0;
	}
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> k;

	for(long long i = 0; i < n; i++)
	{
		cin >> origA[i];
		cnt[origA[i]]++;
	}

	int index = 0;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < cnt[i]; j++)
		{
			a[index] = i;
			index++;
		}
	}

	long long l = 1, r = n;
	while(l <= r)
	{
		long long mid = l + (r - l) / 2;
		if (p(mid)) r = mid - 1;
		else l = mid + 1;
	}

	cout << l;
}