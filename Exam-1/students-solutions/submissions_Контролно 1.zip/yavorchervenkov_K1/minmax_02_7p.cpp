#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, s, a[MAX];
priority_queue<long long> pqMax;
priority_queue<long long, vector<long long>, greater<long long>> pqMin;

bool p(long long x)
{
	return false;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> s;

	for(long long i = 0; i < n; i++)
	{
		cin >> a[i];
		pqMax.push(a[i]);
		pqMin.push(a[i]);
	}

	long long l = pqMin.top(), r = pqMax.top();
	long long diff = r - l;
	while(s >= 0 && diff > 0)
	{
		pqMin.pop();
		pqMax.pop();

		if(r - pqMax.top() <= pqMin.top() - l)
		{
			pqMax.push(r);
			pqMin.push(l + 1);
		}
		else
		{
			pqMax.push(r - 1);
			pqMin.push(l);
		}

		l = pqMin.top(), r = pqMax.top();
		diff = r - l;

		s--;
	}

	cout << diff;
}