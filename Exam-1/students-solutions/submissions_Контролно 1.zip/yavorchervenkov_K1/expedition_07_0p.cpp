#include <iostream>
#include <queue>
#include <algorithm>
#include <math.h>
using namespace std;

const int MAX = 1e7 + 10;
int n, m, s, a[MAX], b[MAX], d[MAX];

bool p(long long x)
{
	return false;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m >> s;

	for(int i = 0; i < n; i++)
	{
		cin >> a[i] >> b[i];
	}

	for(int i = 0; i < m; i++)
	{
		cin >> d[i];
	}

	for(int i = 0; i < m; i++)
	{
		int sum = 1e9;
		for(int j = 0; j < n; j++)
		{
			int dist = a[j], fuel = b[j];
			int finalDist = max(dist - d[i], d[i] - dist);

			sum = min(sum, fuel + finalDist);
		}

		cout << sum << endl;
	}
}