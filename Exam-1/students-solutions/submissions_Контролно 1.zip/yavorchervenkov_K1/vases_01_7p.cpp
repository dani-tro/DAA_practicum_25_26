#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;

const long long MAX = 1e6;
long long n, k, a[MAX];

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> k;
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}

	sort(a, a + n);

	int sum = 0, cnt = 1;
	for(int i = 0; i < n; i++)
	{
		if(sum + a[i] > k)
		{
			cnt++;
			sum = a[i];
		}
		else sum += a[i];
	}

	cout << cnt;
}