#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, s, a[MAX];

bool p(long long x)
{
	return false;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> s;
	int sum = 0;

	for (long long i = 0; i < n; i++)
	{
		cin >> a[i];
		sum += a[i];
	}

	sort(a, a + n);

	long long diff = a[n - 1] - a[0];
	while(s >= 0 && diff > 0)
	{
		for(int i = 0; i < n; i++)
		{
			if(a[i] < sum / n) a[i]++;
			else if(a[i] < sum / n) a[i]--;
			s--;
		}
	}

	sort(a, a + n);
	
	cout << a[n - 1] - a[0];
}