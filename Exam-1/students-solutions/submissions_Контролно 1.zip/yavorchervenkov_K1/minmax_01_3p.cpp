#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, s, a[MAX];

bool p(long long x)
{
	return false;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> s;

	for(long long i = 0; i < n; i++)
	{
		cin >> a[i];
	}

	sort(a, a + n);

	long long diff = a[n - 1] - a[0];
	while(s >= 0 && diff > 0)
	{
		if(a[0] != a[1]) a[0]++;
		else if(a[n - 1] != a[n - 2]) a[n - 1]--;
		else a[0]++;

		sort(a, a + n);

		diff = a[n - 1] - a[0];
	}

	cout << diff;
}