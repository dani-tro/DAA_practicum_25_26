#include <iostream>
#include <queue>
#include <algorithm>
#include <math.h>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, k, a1, a2, x, y, z, m;
vector<long long> a;

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> k;
	cin >> a1 >> a2 >> x >> y >> z >> m;

	a.push_back(a1);
	a.push_back(a2);

	for (long long i = 2; i < n; i++)
	{
		a.push_back((a[i - 2] * x + a[i - 1] * y + z) % m);
	}

	long long diff = 1e9;
	long long i = 0, j = n - 1;
	for (int i = 0; i < n - 1; i++)
	{
		long long l = a[i], r = 0;
		for (long long j = i + 1; j < n; j++)
		{
			if (l < k) l += a[j];
			else if (r < k) r += a[j];
			else
			{
				diff = min(diff, j - i);
				break;
			}
		}
	}

	if (diff == 1e9) cout << -1;
	else cout << diff;
}