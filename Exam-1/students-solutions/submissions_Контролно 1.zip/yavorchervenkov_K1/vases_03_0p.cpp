#include <iostream>
#include <algorithm>
using namespace std;

const long long MAX = 1e7 + 10;
long long n, k, a[MAX];

bool p(long long x)
{
	long long height = 0, currHeight = 0;
	long long currIndex = n - 1;

	for(long long i = n - 1; i >= 0; i -= 3)
	{
		if(i == 0) currHeight = max(currHeight, a[0]);
		else if(i == 1) currHeight = max(currHeight, max(a[0], a[1]));
		else currHeight = max(currHeight, max(a[i], max(a[i - 1], a[i - 2])));

		height += currHeight;
		currHeight = 0;
	}
	return height <= k;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> k;
	for(long long i = 0; i < n; i++)
	{
		cin >> a[i];
	}

	sort(a, a + n);

	long long l = 0, r = n - 1;
	while(l <= r)
	{
		long long mid = l + (r - l) / 2;
		if(p(mid)) r = mid - 1;
		else l = mid + 1;
	}

	cout << l;
}