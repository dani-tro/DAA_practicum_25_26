#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 10000000;

int a[MAXN + 5];
long long pref[MAXN + 5];

int main()
{
	ios :: sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	int n;
	long long k;
	cin >> n >> k;

	int x, y, z, m;
	cin >> a[1] >> a[2] >> x >> y >> z >> m;

	for (int i = 3; i <= n; ++ i)
	{
		a[i] = (1ll * a[i - 2] * x + 1ll * a[i - 1] * y + z) % m;
	}

	for (int i = 1; i <= n; ++ i)
	{
		pref[i] = pref[i - 1] + a[i];
	}

	int ans = -1;
	for (int i = 1; i <= n; ++ i)
	{
		if (pref[n] - pref[i - 1] < 2 * k) break;

		int l = i - 1, r = n + 1, mid;
		while (r - l > 1)
		{
			mid = (l + r) / 2;

			if (pref[mid] - pref[i - 1] >= k) r = mid;
			else l = mid;
		}

		if (pref[n] - pref[r] < k) break;

		int j = r + 1;
		l = j - 1;
		r = n + 1;
		while (r - l > 1)
		{
			mid = (l + r) / 2;

			if (pref[mid] - pref[j - 1] >= k) r = mid;
			else l = mid;
		}

		if (ans == -1) ans = r - i + 1;
		else ans = min(ans, r - i + 1);
	}
	cout << ans << endl;

	return 0;
}