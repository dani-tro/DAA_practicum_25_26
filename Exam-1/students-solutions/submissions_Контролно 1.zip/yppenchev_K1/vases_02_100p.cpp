#include <algorithm>
#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 10000000;

int a[MAXN + 5];

int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int n;
    long long h;
    cin >> n >> h;

    for (int i = 1; i <= n; ++ i)
    {
        cin >> a[i];
    }

    sort(a + 1, a + n + 1);

    int l = 0, r = n, mid;
    while (r - l > 1)
    {
        mid = (l + r) / 2;

        long long sum = 0;
        for (int i = n; i >= 1; i -= mid)
        {
            sum += a[i];
        }

        if (sum > h) l = mid;
        else r = mid;
    }
    cout << r << endl;

    return 0;
}