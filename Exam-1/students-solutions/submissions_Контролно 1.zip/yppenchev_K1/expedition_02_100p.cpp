#include <algorithm>
#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 100000;

pair<int, int> sites[MAXN + 5];
long long pref[MAXN + 5], suff[MAXN + 5];

int main()
{
	ios :: sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	int n, m, c;
	cin >> n >> m >> c;

	for (int i = 1; i <= n; ++i)
	{
		cin >> sites[i].first >> sites[i].second;
	}

	sort(sites + 1, sites + n + 1);

	pref[0] = 1e18;
	for (int i = 1; i <= n; ++ i)
	{
		pref[i] = min(pref[i - 1], sites[i].second - 1ll * sites[i].first * c);
	}

	suff[n + 1] = 1e18;
	for (int i = n; i >= 1; -- i)
	{
		suff[i] = min(suff[i + 1], 1ll * sites[i].first * c + sites[i].second);
	}

	for (int i = 1; i <= m; ++ i)
	{
		int d;
		cin >> d;

		int p = lower_bound(sites + 1, sites + n + 1, make_pair(d, 0)) - sites;

		long long ans = min(pref[p - 1] + 1ll * c * d, suff[p] - 1ll * c * d);
		cout << ans << endl;
	}

	return 0;
}