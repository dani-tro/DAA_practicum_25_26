#include <algorithm>
#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 100000;

int n;
long long s;
int a[MAXN + 5];
long long pref[MAXN + 5];

long long calc(int num, int len)
{
	int p = lower_bound(a + 1, a + n + 1, num) - a;

	long long res = 1ll * (p - 1) * num - pref[p - 1];

	p = lower_bound(a + 1, a + n + 1, num + len + 1) - a;

	res += pref[n] - pref[p - 1] - 1ll * (n - p + 1) * (num + len);

	return res;
}

bool check(int len)
{
	int l = -1, r = 1e9, mid1, mid2;
	while (r - l > 2)
	{
		mid1 = l + (r - l) / 3;
		mid2 = r - (r - l) / 3;

		long long val1 = calc(mid1, len), val2 = calc(mid2, len);
		if (val1 > val2) l = mid1;
		else r = mid2;
	}

	long long tmp = calc(l, len);
	tmp = min(tmp, calc(l + 1, len));
	tmp = min(tmp, calc(l + 2, len));

	return tmp <= s;
}

int main()
{
	ios :: sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	cin >> n >> s;
	
	for (int i = 1; i <= n; ++ i)
	{
		cin >> a[i];
	}

	sort(a + 1, a + n + 1);

	for (int i = 1; i <= n; ++ i)
	{
		pref[i] = pref[i - 1] + a[i];
	}

	int l = -1, r = 1e9 + 1, mid;
	while (r - l > 1)
	{
		mid = (l + r) / 2;

		if (check(mid)) r = mid;
		else l = mid;
	}
	cout << r << endl;

	return 0;
}