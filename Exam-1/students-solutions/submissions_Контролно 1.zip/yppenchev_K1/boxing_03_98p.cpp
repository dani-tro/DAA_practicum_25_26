#include <iostream>
#define endl '\n'
using namespace std;

const int MAXN = 10000000;

int a[MAXN + 5];
long long pref[MAXN + 5];

int main()
{
	ios :: sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);

	int n;
	long long k;
	cin >> n >> k;

	int x, y, z, m;
	cin >> a[1] >> a[2] >> x >> y >> z >> m;

	for (int i = 3; i <= n; ++ i)
	{
		a[i] = (1ll * a[i - 2] * x + 1ll * a[i - 1] * y + z) % m;
	}

	int idx1 = 0;
	long long sum1 = 0;
	while (idx1 < n and sum1 < k)
	{
		idx1++;
		sum1 += a[idx1];
	}

	if (idx1 == n)
	{
		cout << -1 << endl;
		return 0;
	}

	int idx2 = idx1;
	long long sum2 = 0;
	while (idx2 < n and sum2 < k)
	{
		idx2++;
		sum2 += a[idx2];
	}

	if (idx2 == n)
	{
		cout << -1 << endl;
		return 0;
	}

	int ans = idx2;
	for (int i = 2; i <= n; ++ i)
	{
		sum1 -= a[i - 1];

		while (idx1 < n and sum1 < k)
		{
			idx1++;
			sum1 += a[idx1];
			sum2 -= a[idx1];
		}

		if (idx1 == n) break;

		while (idx2 < n and sum2 < k)
		{
			idx2++;
			sum2 += a[idx2];
		}

		if (idx2 == n) break;

		ans = min(ans, idx2 - i + 1);
	}
	if (ans == 0) cout << 1 << endl;
	else cout << ans << endl;

	return 0;
}