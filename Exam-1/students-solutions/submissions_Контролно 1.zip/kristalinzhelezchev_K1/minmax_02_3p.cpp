#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
int main() {
    std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);

    size_t n , s;
    std::cin>>n>>s;

    std::vector<size_t> arr(n);

    std::priority_queue<size_t, std::vector<size_t>> maxqueue;
    std::priority_queue<size_t, std::vector<size_t>, std::greater<size_t>> minqueue;

    size_t num = 0;
    for(size_t i = 0; i < n; i++) {
        std::cin>>num;
        maxqueue.push(num);
        minqueue.push(num);
    }

    while(s > 0) {
        size_t max = maxqueue.top();
        size_t min = minqueue.top();
        maxqueue.pop();
        minqueue.pop();

        size_t nextMax = 0, nextMin = 0;

        if(!maxqueue.empty()) {
            nextMax = maxqueue.top();
            nextMin = minqueue.top();
        }

        size_t maxDiff = max - nextMax;
        size_t minDiff = nextMin - min;

        if(maxDiff == 0) {
            maxDiff = 1;
        }

        if(minDiff == 0) {
            minDiff = 1;
        }

        if(s > std::max(maxDiff, minDiff)) {
            if(maxDiff > minDiff) {
                maxqueue.push(max - maxDiff);
                minqueue.push(min);
                s -= maxDiff;
            }
            // else if(maxDiff == minDiff) {
            //     maxqueue.push(max - maxDiff);
            //     minqueue.push(min);
            //     s -= maxDiff;

            //     if(s > minDiff) {
            //         maxqueue.push(max);
            //         minqueue.push(min + minDiff);
            //         s -= minDiff;
            //     }
            // }
            else{
                maxqueue.push(max);
                minqueue.push(min + minDiff);
                s -= minDiff;
            }
        }else if(s < std::min(maxDiff, minDiff)) {
            if(maxDiff > minDiff) {
                maxqueue.push(max - s);
                minqueue.push(min);
                s = 0;
            }
            // else if(maxDiff == minDiff) {
            //     maxqueue.push(max - maxDiff);
            //     minqueue.push(min);
            //     s -= maxDiff;

            //     if(s > minDiff) {
            //         maxqueue.push(max);
            //         minqueue.push(min + minDiff);
            //         s -= minDiff;
            //     }
            // }
            else{
                maxqueue.push(max);
                minqueue.push(min + s);
                s = 0;
            }
        }else{
            if(minDiff <= s && s <= maxDiff) {
                maxqueue.push(max);
                minqueue.push(min + minDiff);
                s -= minDiff;
            }else{
                maxqueue.push(max - maxDiff);
                minqueue.push(min);
                s -= maxDiff;
            }
        }

    }

    std::cout<<maxqueue.top() - minqueue.top();
    return 0;
}
