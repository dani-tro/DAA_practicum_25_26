#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

size_t getLastMaxIdx(const std::vector<size_t>& arr) {
    const size_t n = arr.size();
    const size_t max = arr[n - 1];

    size_t i = n - 1;
    while(arr[i] == max){
        if(i == 0) {
            return 0;
        }else{
            i--;
        }
    }

    return i + 1;
}

size_t getLastMinIdx(const std::vector<size_t>& arr) {
    const size_t n = arr.size();
    const size_t min = arr[0];

    size_t i = 0;
    while(arr[i] == min){
        if(i == n) {
            return n - 1;
        }else{
            i++;
        }
    }

    return i - 1;
}

int main() {
    std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);

    size_t n , s;
    std::cin>>n>>s;

    std::vector<size_t> arr(n);

    for(size_t i = 0; i < n; i++) {
        std::cin>>arr[i];
    }

    if(n == 1) {
        std::cout<< 0;
        return 0;
    }

    std::sort(arr.begin(), arr.end());

    while(s > 0) {
        size_t lastMaxIdx = getLastMaxIdx(arr);
        size_t lastMinIdx = getLastMinIdx(arr);

        if(lastMaxIdx == 0){
            break;
        }

        size_t maxDiff = arr[n - 1] - arr[lastMaxIdx - 1];
        size_t minDiff = arr[lastMinIdx + 1] - arr[0];
        
        if(s >= std::max(maxDiff, minDiff)) {
            if(maxDiff > minDiff){
                arr[n - 1] -= maxDiff;
                std::swap(arr[n - 1], arr[lastMaxIdx]);
                s-= maxDiff;
            }else{
                arr[0] += minDiff;
                std::swap(arr[0], arr[lastMinIdx]);
                s-= minDiff;
            }
        }else if(s <= std::min(maxDiff, minDiff)) {
            if(maxDiff > minDiff){
                arr[n - 1] -= s;
                std::swap(arr[n - 1], arr[lastMaxIdx]);
                s-= 0;
            }else{
                arr[0] += s;
                std::swap(arr[0], arr[lastMinIdx]);
                s-= 0;
            }
        }else{
            if(s > maxDiff){
                arr[n - 1] -= maxDiff;
                std::swap(arr[n - 1], arr[lastMaxIdx]);
                s-= maxDiff;
            }
            else {
                arr[0] += minDiff;
                std::swap(arr[0], arr[lastMinIdx]);
                s-= minDiff;
            }
        }
    }

    std::cout<<arr[n - 1] - arr[0];
    return 0;
}
