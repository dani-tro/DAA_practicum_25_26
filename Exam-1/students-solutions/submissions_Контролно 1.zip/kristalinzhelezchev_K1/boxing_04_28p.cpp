#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

bool isPossible(const std::vector<size_t>& boxing, const std::vector<size_t>& prefixSums, size_t k, size_t left, size_t right) {
    if(k > prefixSums[right] - prefixSums[left] + boxing[left]) {
        return false;
    }

    for(size_t i = left + 1; i <= right; i++){
        size_t s1 = prefixSums[i] - prefixSums[left] + boxing[left];
        size_t s2 = prefixSums[right] - prefixSums[i];

        if(k <= std::min(s1,s2)){
            return true;
        }
    }

    return false;
}

bool checkIntervals(const std::vector<size_t>& boxing, const std::vector<size_t>& prefixSums, size_t n, size_t k, size_t len) {
    for(size_t i = 0; i < n - len; i++) {
        if(isPossible(boxing, prefixSums, k, i, i + len - 1)){
            return true;
        }
    }

    return false;
}

int main() {
    std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);

    size_t n = 0, k  = 0;
    std::cin >> n >> k;

    size_t a1, a2, x, y, z, m;
    std::cin >> a1 >> a2 >> x >> y >> z >> m;

    std::vector<size_t> boxing (n);
    std::vector<size_t> prefixSums(n);
    boxing[0] = a1;
    boxing[1] = a2;

    prefixSums[0] = a1;
    prefixSums[1] = a1 + a2;

    for(size_t i = 2; i < n; i++) {
        boxing[i] = (x*boxing[i -2] + y*boxing[i-1] + z) % m;
        prefixSums[i] = prefixSums[i-1] + boxing[i];
    }

    long left = 0, right = n;

    long maxInerval = -1;
    while(left < right) {
        long mid = (left + right) / 2;

        if(checkIntervals(boxing, prefixSums, n,k,mid)){
            if(maxInerval == -1 || maxInerval > mid){
                maxInerval = mid;
            }

            right = mid;
        }else{
            left = mid + 1;
        }
    }
    
    std::cout<<maxInerval;
    return 0;
}