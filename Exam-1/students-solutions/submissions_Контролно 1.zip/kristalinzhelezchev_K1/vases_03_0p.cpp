#include <iostream>
#include <vector>
#include <algorithm>


size_t getHeight(size_t k, size_t n, const std::vector<size_t>& arr) {
    if(k >= n) {
        return arr[0];
    }

    size_t countRafts = n / k;
    size_t height = 0;

    for(size_t i = 0; i < countRafts; i++){
        height += arr[i*k];
    }

    if(n % k != 0) {
        height += arr[countRafts * k];
    }

    return height;
}

int main() {
    std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);

    size_t n , h;
    std::cin>>n>>h;

    std::vector<size_t> arr(n);

    for(size_t i = 0; i < n; i++) {
        std::cin>>arr[i];
    }

    std::sort(arr.begin(),arr.end(), std::greater<size_t>());

    size_t left = 1, right = 10;

    for(size_t i = 0; i < 256; i++){
        size_t mid = (left + right) /2;

        size_t currHeight = getHeight(mid, n , arr);

        if(currHeight > h) {
            left = mid + 1;
        }else if(currHeight == h) {
            left = mid;
            break;
        }else{
            right = mid;
        }
    }

    std::cout<<left;
    return 0;
}
