#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

bool isPossible(const std::vector<size_t>& boxing, const std::vector<size_t>& prefixSums, size_t k, size_t left, size_t right) {
    if(k > prefixSums[right] - prefixSums[left] + boxing[left]) {
        return false;
    }

    for(size_t i = left + 1; i <= right; i++){
        size_t s1 = prefixSums[i] - prefixSums[left] + boxing[left];
        size_t s2 = prefixSums[right] - prefixSums[i];

        if(k <= std::min(s1,s2)){
            return true;
        }
    }

    return false;
}

int main() {
    std::ios_base::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);

    size_t n = 0, k  = 0;
    std::cin >> n >> k;

    size_t a1, a2, x, y, z, m;
    std::cin >> a1 >> a2 >> x >> y >> z >> m;

    std::vector<size_t> boxing (n);
    std::vector<size_t> prefixSums(n);
    boxing[0] = a1;
    boxing[1] = a2;

    prefixSums[0] = a1;
    prefixSums[1] = a1 + a2;

    for(size_t i = 2; i < n; i++) {
        boxing[i] = (x*boxing[i -2] + y*boxing[i-1] + z) % m;
        prefixSums[i] = prefixSums[i-1] + boxing[i];
    }

    long left = 0, right = n - 1;

    long maxInerval = -1;
    bool isFound = false;
    while(right - left + 1 > 2) {
        long m1 = left + (right - left + 1) / 3;
        long m2 = left + 2*(right - left + 1) / 3;

        if(left == m1) {
            m1++;
        }
        if(right == m2){
            m2--;
        }

        isFound = false;
        if(isPossible(boxing, prefixSums, k, m1, m2)) {
            left = m1;
            right = m2;
            isFound = true;
        }else if(isPossible(boxing, prefixSums, k ,left, m2)){
            right = m2;
            isFound = true;
        }else if(isPossible(boxing, prefixSums, k ,m1, right)){
            left = m1;
            isFound = true;
        }else{
            break;
        }

        if(isFound) {
            if(maxInerval == -1 || maxInerval > right - left + 1)
                maxInerval = right - left + 1;
        }
    }
    
    if(isPossible(boxing, prefixSums, k ,left, right)){
        if(maxInerval == -1 || maxInerval > right - left + 1)
            maxInerval = right - left + 1;
    }
    std::cout<<maxInerval;
    return 0;
}