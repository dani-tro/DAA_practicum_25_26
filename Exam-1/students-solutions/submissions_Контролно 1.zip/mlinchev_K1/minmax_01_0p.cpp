#include <iostream>
#include <algorithm>

using namespace std;

void updateMinMax(int arr[], int n, int& min, int& max) {
    max = arr[0];
    min = arr[0];
    for (int i = 1 ; i < n ; i++) {
        if (arr[i] < min) min = arr[i];
        if (arr[i] > max) max = arr[i];
    }
}

bool isFound(int arr[], int n, int target) {
    for (int i = 0 ; i < n ; i++) {
        if (arr[i] == target) return true;
    }
    return false;
}

int main() {

    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int n, s;
    cin >> n >> s;
    
    int* arr = new int [n];
    for (int i = 0 ; i < n ; i++) {
        cin >> arr[i];
    }

    int min = arr[0];
    int max = arr[0];
    
    for (int i = 1 ; i < n ; i++) {
        if (arr[i] < min) min = arr[i];
        if (arr[i] > max) max = arr[i];
    }

    

    int i = 0;
    while (s > 0) {
        if (i >= n) {
            i = 0;
            updateMinMax(arr, n, min, max);
        }


        if (arr[i] == max){
            arr[i]--;
            s--;
            
        }
        else if (arr[i] == min){
            arr[i]++;
            s--;
        }
        i++;

    }


    max = arr[0];
    min = arr[0];
    for (int i = 1 ; i < n ; i++) {
        if (arr[i] < min) min = arr[i];
        if (arr[i] > max) max = arr[i];
    }
    cout << '\n' << max - min;

    delete [] arr;

    return 0;
}