#include <bits/stdc++.h>
using namespace std;
#define MAX 10000007

long long n,h;
long long a[MAX];

bool calc(long long w){
    
    long long levels = 0;

    long long i = 0;

    //cout << levels << " " << a[i] << endl;

    while (i < n)
    {
        levels += a[i];
        i += w ;
       // cout << levels << " " << a[i] << endl;
    }

    return levels <= h;
    
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n>>h;

    for(long long i = 0 ; i < n; ++i)
        cin >> a[i];

    sort(a,a+n, [](long long x, long long y){ return x > y;});

    long long l = 1;
    long long r = 1e4;

    //cout << calc(3);
    while (l <= r)
    {
        long long mid = (l+r)/2;
        //cout << l << " " << r << endl;
        if(calc(mid))
            r = mid - 1;
        else
            l = mid + 1;
    }
    cout << l;
}