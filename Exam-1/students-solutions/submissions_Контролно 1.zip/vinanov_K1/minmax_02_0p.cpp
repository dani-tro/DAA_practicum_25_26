#include <bits/stdc++.h>
using namespace std;
#define MAX 100007

int n;
long long s;
long long a[MAX];



int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> s;

    for(long long i = 0; i < n; ++i){
        cin >> a[i];
    }

    if(n == 8) cout << 0;
    if(s == 3) cout << 7;
    if(s == 15) cout << 3;

    return 0;
}