#include <bits/stdc++.h>
using namespace std;
#define MAX 1000007

int n,m;
long long c;
long long a[MAX],b[MAX], d[MAX];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m >> c;

    for(int i = 0; i < n; ++i){
        cin >> a[i] >> b[i];
    }

    for(int i = 0; i < m; ++i){
        cin >> d[i];
    }

    for(int i = 0; i < m; ++i){

        long long res = b[0] + abs(a[0] - d[i]) * c;
        for(int j = 1; j < n; ++j){
            //cout << b[j] + abs(a[j] - d[i]) * c << endl;
            res = min(b[j] + abs(a[j] - d[i]) * c, res);
        }
        cout << res << endl; 
    }


    

    return 0;
}
