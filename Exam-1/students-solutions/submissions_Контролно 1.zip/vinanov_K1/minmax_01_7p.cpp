#include <bits/stdc++.h>
using namespace std;
#define MAX 100007

int n;
long long s;
priority_queue<long long> maxq;
priority_queue<long long> minq;



int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> s;

    for(long long i = 0; i < n; ++i){
        //cin >> a[i];
        long long a;
        cin >> a;

        maxq.push(a);
        minq.push(-a);
    }

    //sort(a,a+n);

    int i = 0;

    while (i < s && maxq.top() != -minq.top())
    {
        long long cur_t = maxq.top();
        while (i < s && cur_t - 1 != maxq.top())
        {
            cur_t = maxq.top();
            maxq.pop();
            maxq.push(cur_t-1);
            ++i;
        }

        long long cur_b = minq.top();
        while (i < s && cur_b - 1 != minq.top())
        {
            cur_b = minq.top();
            minq.pop();
            minq.push(cur_b-1);
            ++i;
        }
    }

    cout << maxq.top() + minq.top();
    

    return 0;
}