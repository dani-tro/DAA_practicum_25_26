#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <map>
using namespace std;

long long const maxN=1e5;
long long a[maxN];

void solve(){
    long long n,s;
    cin >> n >> s;

    for(int i=0; i<n; i++)
        cin >> a[i];
    
    sort(a, a+n);
    map<long long, long long> m;
    for(int i=0; i<n; i++){
        m[a[i]]++;
    }

    long long small=a[0];
    long long big=a[n-1];
    long long ans=0;
    vector<long long> v;

    for(int i=0; i<n;){
        int curr=a[i];
        v.push_back(curr);
        while(i<n && a[i]==curr){
            i++;
        }
    }

    int idxl=0;
    int idxr=v.size()-1;

    while(small!=big){
        if(m[small]<=m[big]){
            if(m[small]<=s){
                idxl++;
                if(s>=(v[idxl]-small)*m[small]){
                    s-=(v[idxl]-small)*m[small];
                    m[v[idxl]]+=m[small];
                    small=v[idxl];
                }
                else{
                    small+=s/m[small];
                    break;
                }
                
            }
            else break;
        }
        else{
            if(m[big]<=s){
                idxr--;
                if(s>=(big-v[idxr])*m[big]){
                    s-=(big-v[idxr])*m[big];
                    m[v[idxr]]+=m[big];
                    big=v[idxr];
                }
                else{
                    big-=s/m[big];
                    break;
                }
            }
            else break;
        }
    }

    ans=big-small;
    cout << ans << endl;

}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);


    solve();
}