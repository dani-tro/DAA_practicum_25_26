#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <map>
using namespace std;

vector<pair<long long, long long>> v;
vector<long long> d;
int const maxN=1e5;
long long optstlqvo[maxN];
long long optstdqsno[maxN];

void solve(){
    long long n,m,c;
    cin >> n >> m >> c;

    for(int i=0; i<n; i++){
        long long a,b;
        cin >> a >> b;

        v.push_back({a,b});
    }

    for(int i=0; i<m; i++){
        long long idk;
        cin >> idk;

        d.push_back(idk);
    }

    //iskash da namerish za vsqko pos : min(abs(v[i].first-pos)*c+v[i].second)
    sort(v.begin(), v.end());
    optstlqvo[0]=v[0].second;
    for(int i=1; i<n; i++){
        optstlqvo[i]=min(v[i].second, optstlqvo[i-1]+c*(v[i].first-v[i-1].first));
    }   

    optstdqsno[n-1]=v[n-1].second;
    for(int i=n-2; i>=0; i--){
        optstdqsno[i]=min(v[i].second, optstdqsno[i+1]+c*(v[i+1].first-v[i].first));
    }
    
    
    for(int i=0; i<m; i++){
        long long pos=d[i];

        //tozi pos e mejdu 2 stationa ili e do 1
        //tursq purvoto v[i].first koeto e po malko - ako nqma znachi e predi purviq station
        int l=0;
        int r=n-1;
        int ans=-1;
        while(l<=r){
            int mid=l+(r-l)/2;
            if(v[mid].first<pos){
                ans=mid;
                l=mid+1;
            }
            else r=mid-1;
        }

        //cout << i << " " << ans << endl;
        

        if(ans==-1){
            cout << min(optstlqvo[0]+c*(v[0].first-pos), optstdqsno[0]+c*(v[0].first-pos)) << endl;
        }
        else if(ans==n-1){
            cout << min(optstlqvo[n-1]+c*(pos-v[n-1].first), optstdqsno[n-1]+c*(pos-v[n-1].first)) << endl;
        }
        else{
            cout << min(min(optstlqvo[ans]+c*(pos-v[ans].first), optstdqsno[ans]+c*(pos-v[ans].first)),
                        min(optstlqvo[ans+1]+c*(v[ans+1].first-pos), optstdqsno[ans+1]+c*(v[ans+1].first-pos))) << endl;
        }
        
    }
    
    



}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);


    solve();
}