#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <map>
using namespace std;

vector<long long> v;
long long const maxN=1e7;
long long pref[maxN+1];

void solve(){
    long long n,k;
    cin >> n >> k;

    long long a1,a2,x,y,z,m;
    cin >> a1 >> a2 >> x >> y >> z >> m;

    v.push_back(a1);
    v.push_back(a2);

    for(int i=2; i<n; i++){
        v.push_back((v[i-2]*x+v[i-1]*y+z)%m);
    }

    pref[0]=0;
    for(int i=1; i<=n; i++){
        pref[i]=v[i-1]+pref[i-1];
    }

    int l1=1;
    int r1=1;
    int r2=2;
    long long ans=1e7+1;
    while(true){
        if(r2==n && pref[r2]-pref[l1-1]<2*k){
            //cout << "a" << endl;
            break;
        }
        
        while(r1<=n && pref[r1]-pref[l1-1]<k){
            r1++;
            if(r2==r1) r2++;
            
        }
        if(pref[r1]-pref[l1-1]<k){
            //cout << "b" << endl;
            break;
        }

        while(r2<=n && pref[r2]-pref[r1]<k){
            r2++;
        }
        //cout << l1 << " " << r1 << " " << r2 << "  ---------       " << pref[l1] << " " << pref[r1] << " " << pref[r2] <<  endl;
        if(pref[r2]-pref[r1]<k){
            //cout << "c" << endl;
            break;
        }
        
        ans=min(ans, (long long)r2-l1+1);
        l1++;
    }

    if(ans==1e7+1) cout << -1 << endl;
    else cout << ans << endl;

}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);


    solve();
}