#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

int const maxN=1e7;
int a[maxN];
int n,h;

bool can(long long w){
    long long leftspace=h;
    int idx=n-1;

    while(idx>=0){
        if(a[idx]>leftspace) return false;
        else{
            leftspace-=a[idx];
            idx-=w;
        }
    }

    return true;

}

void solve(){
    cin >> n >> h;

    for(int i=0; i<n; i++)
        cin >> a[i];

    sort(a, a+n);

    long long l=1;
    long long r=1e9;
    long long ans=1e9;
    while(l<=r){
        long long mid=l+(r-l)/2;
        if(can(mid)){
            ans=mid;
            r=mid-1;
        }
        else l=mid+1;
    }

    cout << ans << endl;
}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);


    solve();
}