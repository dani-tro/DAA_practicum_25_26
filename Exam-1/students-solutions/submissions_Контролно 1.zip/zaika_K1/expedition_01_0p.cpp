#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <utility>
using namespace std;

bool cmp(pair<long long, long long> &a, pair<long long, long long> &b)
{
    if (a.second != b.second)
        return a.second < b.second;
    return a.first > b.first;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m, c;
    cin >> n >> m >> c;

    vector<pair<long long, long long>> s;
    vector<long long> exp;

    for (int i = 0; i < n; i++)
    {
        long long dist, cost;
        cin >> dist >> cost;

        s.push_back({dist, cost});
    }

    for (int i = 0; i < m; i++)
    {
        long long dist;
        cin >> dist;

        exp.push_back(dist);
    }

    sort(s.begin(), s.end(), cmp);

    for (int i = 0; i < m; i++)
    {
        long long cur_dist = exp[i];
        long long ans = cur_dist + s[n-1].second;
        for(int j = 0; j < n; j++) {
            long long dist = s[j].first;
            long long cost = s[j].second;
            cost += abs(cur_dist - dist);
            ans = min(ans, cost);
        }
        cout << ans << "\n";

    }
    
    return 0;
}