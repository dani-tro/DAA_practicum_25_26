#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int main () {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int N, S;
    cin >> N >> S;
    
    vector<int> a;
    vector<int> vasesL;
    for(int i = 0; i < N; i++) {
        int num;
        cin >> num;
        a.push_back(num);
    }

    sort(a.begin(), a.end());

    int i = 0, j = N-1;
    int best = a[N-1] - a[0];
    while(S > 1) {
        if(i == j) {
            sort(a.begin(), a.end());
            best = min(a[N-1] - a[0], best);
            i = 0;
            j = N-1;
        } else if(S > 1) {
            a[i++]++;
            a[j--]--;
            S -= 2;
        }
        
    }

    sort(a.begin(), a.end());
    best = min(a[N-1] - a[0], best);
    if (S == 1) {
        a[0]++;
        best = min(a[N-1] - a[0], best);
        a[0]--;

        a[N-1]--;
        best = min(a[N-1] - a[0], best);
    }



    cout << best;
    return 0;
}