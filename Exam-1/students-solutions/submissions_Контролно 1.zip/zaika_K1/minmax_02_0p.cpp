#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int main () {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int N, S;
    cin >> N >> S;
    
    vector<int> a;
    vector<int> vasesL;
    for(int i = 0; i < N; i++) {
        int num;
        cin >> num;
        a.push_back(num);
    }

    sort(a.begin(), a.end());

    while(S > 0) {
        if(S != 1) {
            a[0]++;
            a[N-1]--;
            S -= 2;
        } else {
            a[N-1]--;
            S--;
        }
        sort(a.begin(), a.end());
    }



    cout << a[N-1] - a[0];
    return 0;
}