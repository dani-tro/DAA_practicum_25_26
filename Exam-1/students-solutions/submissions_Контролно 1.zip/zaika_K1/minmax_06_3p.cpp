#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int imin( vector<int> &a, int i) {
    int j = 1;
    while(a[i] == a[j]) j++;
    return j;
}

int main () {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int N, S;
    cin >> N >> S;
    
    vector<int> a;
    for(int i = 0; i < N; i++) {
        int num;
        cin >> num;
        a.push_back(num);
    }

    sort(a.begin(), a.end());

    int i = 0, j = imin(a, 0), k = N - 1;
    int best = a[N-1] - a[0];
    while(S > 0) {
        if(i == j) {
            i = 0;
            j = imin(a, j-1);
            best = min(a[N-1] - a[0], best);
        } else if(j - i <= S) {
            a[i++]++;
            S--;
        } else {
            a[k--]--;
            S--;
        }
        
    }
    best = min(a[N-1] - a[0], best);

    cout << best;
    return 0;
}