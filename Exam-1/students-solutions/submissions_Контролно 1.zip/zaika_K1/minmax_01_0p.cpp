#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int main () {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    int N, S;
    cin >> N >> S;
    
    vector<int> a;
    vector<int> vasesL;
    for(int i = 0; i < N; i++) {
        int num;
        cin >> num;
        a.push_back(num);
    }

    sort(a.begin(), a.end());

    int i = 0, j = N - 1;
    while(S > 0) {
        if(i == j) {
            a[j]--;
            i = 0;
            j = N - 1;
            sort(a.begin(), a.end());
        } else if(S != 1) {
            a[i++]++;
            a[j--]--;
            S -= 2;
        } else {
            a[j--]--;
            S--;
        }
    }
    sort(a.begin(), a.end());


    cout << a[N-1] - a[0];
    return 0;
}