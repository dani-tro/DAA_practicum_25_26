#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
#define int long long
const int maxn = 10000000 + 3;
const int INF = 99999999999999;

int a[maxn];
int l[maxn], r[maxn];
void solve() {
    int n, k; cin >> n >> k;
    int x, y, z, m;
    cin >> a[0] >> a[1] >> x >> y >> z >> m;
    for (int i = 2; i < n; i++) {
        a[i] = (a[i - 2] * x + a[i - 1] * y + z) % m;
        
    }
    for (int i = 0; i < n; i++) {
        l[i] = -1; r[i] = -1;
    }

    int first = 0, sum = 0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
        while(sum - a[first] >= k) {
            sum -= a[first]; first++;
        }
        if (sum >= k) {
            l[i] = i - first + 1;
        }
    }

    first = n - 1; sum = 0;
    for (int i = n - 1; i >= 0; i--) {
        while (sum - a[first] >= k) {
            sum -= a[first]; first--;
        }
        if (sum >= k) {
            r[i] = first - i;
        }
        sum += a[i];
    }

    int mincomb = INF;
    for (int i = 0; i < n; i++) {
        if (l[i] != -1 && r[i] != -1) {
            mincomb = min(l[i] + r[i], mincomb);
        }
    }

    if (mincomb == INF) cout << -1 << endl;
    else cout << mincomb << endl;

}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();
}
