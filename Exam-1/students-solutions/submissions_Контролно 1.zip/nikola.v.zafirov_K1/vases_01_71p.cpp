#include <iostream>
#include <algorithm>
using namespace std;

#define int long long

const int maxn = 10000000 + 3;
int a[maxn];
int n, h;

bool tryW(int w) {
    int sb = 0;
    for (int i = 0; i < n; i += w) {
        sb += a[i];
    }
    return sb <= h;
}

bool desc(int a, int b) { return a > b; }
void solve() {
    cin >> n >> h;

    int sum = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        sum += a[i];
    }
    sort(a, a + n, desc);


    // bin search
    int l = 1, r = n;
    {      
        while (l <= r) {
            int mid = l + (r - l) / 2;

            if (!tryW(mid)) {
                l = mid + 1;
            }
            else {
                r = mid - 1;
            }
        }
    }

    cout << l << endl;

}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();
}