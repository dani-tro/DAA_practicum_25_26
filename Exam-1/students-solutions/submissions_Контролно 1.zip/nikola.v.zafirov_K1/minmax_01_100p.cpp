#include <iostream>
#include <algorithm>
using namespace std;
#define int long long
const int maxn = 100000 + 3;


int a[maxn];
pair<int, int> coll[maxn];

void solve() {
    int n, s; cin >> n >> s;
    for (int i = 0; i < n; i++) cin >> a[i];
    
    sort(a, a + n);
    int diff = a[n - 1] - a[0];

    int collsize = 0, br = 1;
    for (int i = 1; i <= n; i++) {
        if (a[i] != a[i - 1]) {
            coll[collsize++] = { a[i - 1], br };
            br = 0;
        }
        br++;
    }

    int pl = 0, pr = collsize - 1;
    while (pl < pr && s > 0) {
        if (coll[pl].second < coll[pr].second) {
            int count = coll[pl].second;
            int dist = coll[pl + 1].first - coll[pl].first;
            if (s < count * dist) dist = s / count;
            s -= count * dist;

            coll[pl + 1].second += coll[pl].second;
            diff -= dist;
            pl++;
        }
        else {
            int count = coll[pr].second;
            int dist = coll[pr].first - coll[pr - 1].first;
            if (s < count * dist) dist = s / count;
            s -= count * dist;

            coll[pr - 1].second += coll[pr].second;
            diff -= dist;

            pr--;
        }
    }

    cout << diff << endl;

}


signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();
}