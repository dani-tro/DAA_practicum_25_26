#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
#define int long long
const int maxn = 100000 + 3;
const int inf = 99999999999999;

int n, m, c;
pair<int, int> p[maxn];
struct Corner
{
    int pos;
    int i;
};
Corner k[maxn];
bool ccc(Corner a, Corner b) { return a.pos < b.pos; }

int findcorner(int _i, int _j) {
    int i = min(_i, _j), j = max(_i, _j);
    int x = (int)(((p[i].first * c + p[j].first * c + p[j].second - p[i].second) / (double)c) / 2);
    if (x >= p[i].first && x <= p[j].first) return x;
    else if (x < p[i].first) return -1; // j always better
    else return inf; // i always better
}

bool byfirst(pair<int, int> a, pair<int, int> b) { return a.first < b.first; }
void solve() {
    cin >> n >> m >> c;
    for (int i = 0; i < n; i++) cin >> p[i].first >> p[i].second;

    sort(p, p + n, byfirst);

    k[0] = { -100, 0 };
    int ci = 0, j = 1;
    while(j < n) {
        while (ci >= 0 && j < n) {
            int cor = findcorner(k[ci].i, j);
            if (cor == inf) j++;
            else if (cor == -1) ci--;
            else break;
        }
        if (j != n) {
            if (ci == -1) {
                k[0] = { -100, j };
                ci = 0;
            }
            else {
                k[ci+1] = { findcorner(k[ci].i, j), j };
                ci++;
            }
        }
        j++;
    }

    for (int i = 0; i < m; i++) {
        int q; cin >> q;
        Corner dummy = {q, -10};
        int pl = (*(upper_bound(k, k + ci + 1, dummy, ccc) - 1)).i;
        int gorivo = p[pl].second + abs(p[pl].first - q) * c;
        cout << gorivo << endl;
    }
}


signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    solve();
}