#include <bits/stdc++.h>

using namespace std;

#define MAX 10000005

long long n, h;
vector<long long> a(MAX);

bool check(long long x)
{
    if (x == 0)
        return false;

    long long needed_height = 0;
    long long currMax = a[0];

    for (int i = 1; i < n; i++)
    {
        if (i % x == 0)
        {
            needed_height += currMax;
            currMax = a[i];
        }
        else
        {
            currMax = max(currMax, a[i]);
        }
    }

    needed_height += currMax;

    return needed_height <= h;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> h;

    for (int i = 0; i < n; i++)
        cin >> a[i];

    sort(a.begin(), a.begin() + n);
    reverse(a.begin(), a.begin() + n);

    long long l = 0, r = 1e7, ans = -1;

    while (l <= r)
    {
        long long mid = (l + r) / 2;

        // cout << mid << '\n';

        if (check(mid))
        {
            ans = mid;
            r = mid - 1;
        }
        else
            l = mid + 1;
    }

    cout << ans << '\n';
}