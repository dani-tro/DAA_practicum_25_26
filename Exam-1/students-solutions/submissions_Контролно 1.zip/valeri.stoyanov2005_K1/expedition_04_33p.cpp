#include <bits/stdc++.h>

using namespace std;

#define MAX 100005

long long n, m, c;

vector<pair<long long, long long>> landings(MAX);
vector<long long> d(MAX);
vector<long long> answers;

// long long spentFuel(pair<long long, long long> landing, int idx)
// {
//     return landing.second + abs(landing.first - d[idx]) * c;
// }

// long long solve(int idx)
// {
//     // long long minSpent = landings[0].second + abs(landings[0].first - d[idx]) * c;

//     // for (int i = 1; i < n; i++)
//     // {
//     //     long long spent = landings[i].second;

//     //     minSpent = min(minSpent, spent + abs(landings[i].first - d[idx]) * c);
//     // }

//     // return minSpent;

//     long long l = 0, r = n - 1;

//     while (l <= r)
//     {
//         long long m1 = l + (l + r) / 3;
//         long long m2 = r - (l + r) / 3;

//         if (spentFuel(landings[m1], idx) < spentFuel(landings[m2], idx))
//             r = m2;
//         else
//             l = m1;
//     }

//     return spentFuel(landings[l], idx);
// }

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> c;

    for (int i = 0; i < n; i++)
        cin >> landings[i].first >> landings[i].second;

    // sort(landings.begin(), landings.begin() + n);

    priority_queue<long long> pq;

    for (int i = 0; i < m; i++)
    {
        while (!pq.empty())
            pq.pop();

        long long curr;
        cin >> curr;
        d[i] = curr;

        for (int j = 0; j < n; j++)
            pq.push(-(landings[j].second + abs(landings[j].first - curr) * c));

        answers.push_back(-pq.top());
    }

    // cout << "----------\n";

    // for (int i = 0; i < m; i++)
    //     answers.push_back(solve(i));

    for (int i = 0; i < m; i++)
        cout << answers[i] << '\n';

    return 0;
}