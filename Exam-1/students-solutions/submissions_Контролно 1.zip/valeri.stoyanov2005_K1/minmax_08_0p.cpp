#include <bits/stdc++.h>

using namespace std;

#define MAX 100005

long long n;
unsigned long s;
vector<long long> a(MAX);
long long counts[MAX]{0};

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> s;

    long long maxIdx = 0, minIdx = 1e9;
    for (int i = 0; i < n; i++)
    {
        long long curr;
        cin >> curr;

        a[i] = curr;
        counts[curr]++;
        minIdx = min(minIdx, curr);
        maxIdx = max(maxIdx, curr);
    }

    while (s > 0)
    {
        while (maxIdx > 0 && counts[maxIdx] > 0 && s > 0)
        {
            counts[maxIdx]--;
            counts[maxIdx - 1]++;
            s--;
        }
        maxIdx--;

        while (minIdx < n - 1 && counts[minIdx] > 0 && s > 0)
        {
            counts[minIdx]--;
            counts[minIdx + 1]++;
            s--;
        }
        minIdx++;
    }

    cout << maxIdx - minIdx << '\n';

    // sort(a.begin(), a.begin() + n);

    // long long ans = 0;

    // int l = 0, r = n - 1;
    // while (s > 0)
    // {
    //     if (s > 2)
    //     {
    //         a[l]++;
    //         a[r]--;

    //         while (l < n && a[l] > a[l + 1])
    //             l++;

    //         while (r > -1 && a[r] < a[r - 1])
    //             r--;

    //         s -= 2;
    //     }
    //     else
    //     {
    //         ans = min(abs(a[r - 1] - a[l]), abs(a[r] - a[l + 1]));
    //         s--;
    //     }
    // }

    // for (int i = 0; i < n; i++)
    //     cout << a[i] << ' ';
    // cout << '\n';

    // cout << ans << '\n';
}