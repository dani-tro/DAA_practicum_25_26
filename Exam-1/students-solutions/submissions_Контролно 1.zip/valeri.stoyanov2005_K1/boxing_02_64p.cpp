#include <bits/stdc++.h>

using namespace std;

#define MAX 200000005

unsigned long long n, k;
long long a1, a2, x, y, z, m;

vector<long long> a;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> k;
    cin >> a1 >> a2 >> x >> y >> z >> m;

    a.push_back(a1);
    a.push_back(a2);

    for (int i = 2; i < n; i++)
        a.push_back((a[i - 2] * x + a[i - 1] * y + z) % m);

    // for (int i = 0; i < n; i++)
    //     cout << a[i] << ' ';
    // cout << '\n';

    // long long temp;
    // for (int i = 0; i < 21; i++)
    //     temp += a[i];
    // cout << temp << '\n';

    long long l = 0, currSum = 0, minLen = 1e9;
    bool foundOnce = false;
    for (int r = 0; r < n; r++)
    {
        if (currSum >= 2 * k)
        {
            minLen = min(minLen, r - l);
            foundOnce = true;

            while (currSum > 2 * k)
            {
                currSum -= a[l];
                l++;
            }
        }
        currSum += a[r];
    }

    if (!foundOnce)
        cout << "-1" << '\n';

    cout << minLen << '\n';

    return 0;
}