#include <bits/stdc++.h>

using namespace std;

#define MAX 100005

long long n, s;
vector<unsigned long long> a(MAX);

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> s;

    for (int i = 0; i < n; i++)
        cin >> a[i];

    sort(a.begin(), a.begin() + n);

    long long ans = 0;

    int l = 0, r = n - 1;
    while (s > 0)
    {

        if (s > 2)
        {
            a[l]++;
            a[r]--;

            while (l < n && a[l] > a[l + 1])
                l++;

            while (r > -1 && a[r] < a[r - 1])
                r--;

            s -= 2;
        }
        else
        {
            ans = min(a[r - 1] - a[l], a[r] - a[l + 1]);
            s--;
        }
    }

    cout << ans << '\n';
}