#include <bits/stdc++.h>

using namespace std;

long long n;
unsigned int long long k;
unsigned long long a1, a2, x, y, z, m;

vector<long long> a;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> k;
    cin >> a1 >> a2 >> x >> y >> z >> m;

    a.push_back(a1);
    a.push_back(a2);

    for (int i = 2; i < n; i++)
        a.push_back((a[i - 2] * x + a[i - 1] * y + z) % m);

    unsigned long long l = 0, currSum = 0, minLen = 1e9;
    bool foundOnce = false;
    for (int r = 0; r < n; r++)
    {
        currSum += a[r];
        if (currSum >= 2 * k)
        {
            minLen = min(minLen, r - l + 1);
            foundOnce = true;

            while (currSum > 2 * k)
            {
                currSum -= a[l];
                l++;
            }
        }
    }

    if (!foundOnce)
        cout << "-1" << '\n';
    else
        cout << minLen << '\n';

    return 0;
}