#include <bits/stdc++.h>

using namespace std;

#define MAX 100005

long long n, m, c;

vector<pair<long long, long long>> landings(MAX);
vector<long long> d(MAX);
vector<long long> answers;

long long solve(int idx)
{
    long long minSpent = landings[0].second + abs(landings[0].first - d[idx]) * c;

    for (int i = 1; i < n; i++)
    {
        long long spent = landings[i].second;

        minSpent = min(minSpent, spent + abs(landings[i].first - d[idx]) * c);
    }

    return minSpent;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> c;

    for (int i = 0; i < n; i++)
        cin >> landings[i].first >> landings[i].second;

    for (int i = 0; i < m; i++)
        cin >> d[i];

    for (int i = 0; i < m; i++)
        answers.push_back(solve(i));

    for (int i = 0; i < m; i++)
        cout << answers[i] << '\n';

    return 0;
}