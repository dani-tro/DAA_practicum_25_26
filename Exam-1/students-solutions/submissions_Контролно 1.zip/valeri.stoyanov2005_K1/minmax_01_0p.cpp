#include <bits/stdc++.h>

using namespace std;

#define MAX 100005

long long n, s;
vector<long long> a(MAX);

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> s;

    for (int i = 0; i < n; i++)
        cin >> a[i];

    sort(a.begin(), a.begin() + n);

    // long long l = 0, r = 1e8, ans = -1;
    long long ans = 0;

    while (s > 0)
    {
        // int l = 0, r = n - 1;

        if (s > 2)
        {
            a[0]++;
            a[n - 1]--;

            sort(a.begin(), a.begin() + n);

            // int idx = 1;
            // while (a[l] > a[idx])
            // {
            //     swap(a[l], a[idx]);
            //     l++;
            //     idx++;
            // }

            // idx = n - 2;
            // while (a[r] < a[idx])
            // {
            //     swap(a[r], a[idx]);
            //     r--;
            //     idx--;
            // }

            // s -= 2;
        }
        else
        {
            // long long nextMin = 1, nextMax = n - 2;
            // while (nextMin == a[0] + 1)
            //     nextMin++;

            // while (nextMax == a[n - 1] - 1)
            //     nextMax--;

            // ans = min(a[n - 1] - nextMin, nextMax - a[0])

            ans = min(a[n - 2] - a[0], a[n - 1] - a[1]);

            // a[l]++;
            // int idx = 1;
            // while (a[l] > a[idx])
            // {
            //     swap(a[l], a[idx]);
            //     l++;
            // }
        }

        s--;
    }

    cout << ans << '\n';
}