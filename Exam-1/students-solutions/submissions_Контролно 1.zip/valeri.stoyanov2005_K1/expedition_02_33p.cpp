#include <bits/stdc++.h>

using namespace std;

#define MAX 100005

long long n, m, c;

vector<pair<long long, long long>> landings(MAX);
vector<long long> d(MAX);
vector<long long> answers;

// long long solve(int idx)
// {
//     long long minSpent = landings[0].second + abs(landings[0].first - d[idx]) * c;

//     for (int i = 1; i < n; i++)
//     {
//         long long spent = landings[i].second;

//         minSpent = min(minSpent, spent + abs(landings[i].first - d[idx]) * c);
//     }

//     return minSpent;
// }

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> c;

    for (int i = 0; i < n; i++)
        cin >> landings[i].first >> landings[i].second;

    priority_queue<long long> pq;

    for (int i = 0; i < m; i++)
    {
        while (!pq.empty())
            pq.pop();

        long long curr;
        cin >> curr;

        d[i] = curr;

        for (int i = 0; i < n; i++)
            pq.push(-(landings[i].second + abs(landings[i].first - curr) * c));

        answers.push_back(-pq.top());
    }

    // cout << "----------\n";

    // for (int i = 0; i < m; i++)
    //     answers.push_back(solve(i));

    for (int i = 0; i < m; i++)
        cout << answers[i] << '\n';

    return 0;
}