#include <bits/stdc++.h>

using namespace std;

#define MAX 100005
#define COUNTMAX 100000005

long long n;
unsigned long s;
vector<long long> a(MAX);
long long counts[COUNTMAX]{0};

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> s;

    long long maxIdx = 0, minIdx = 1e9;
    for (int i = 0; i < n; i++)
    {
        long long curr;
        cin >> curr;

        a[i] = curr;
        counts[curr]++;
        minIdx = min(minIdx, curr);
        maxIdx = max(maxIdx, curr);
    }

    while (s > 0)
    {
        while (maxIdx > 0 && counts[maxIdx] > 0 && s > 0)
        {
            counts[maxIdx]--;
            counts[maxIdx - 1]++;
            s--;
        }
        maxIdx--;

        while (minIdx < n - 1 && counts[minIdx] > 0 && s > 0)
        {
            counts[minIdx]--;
            counts[minIdx + 1]++;
            s--;
        }
        minIdx++;
    }

    cout << maxIdx - minIdx << '\n';
}