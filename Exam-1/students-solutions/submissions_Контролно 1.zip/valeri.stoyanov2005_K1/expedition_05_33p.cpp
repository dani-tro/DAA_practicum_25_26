#include <bits/stdc++.h>

using namespace std;

#define MAX 100005

long long n, m, c;

vector<pair<long long, long long>> landings(MAX);
vector<long long> d(MAX);
vector<long long> answers(MAX);

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> c;

    // for (int i = 0; i < 20; i++)
    //     cout << answers[i] << ' ';
    // cout << endl;

    for (int i = 0; i < n; i++)
        cin >> landings[i].first >> landings[i].second;

    for (int i = 0; i < m; i++)
    {
        long long curr;
        cin >> curr;
        d[i] = curr;

        for (int j = 0; j < n; j++)
        {
            if (answers[i] == 0)
                answers[i] = landings[j].second + abs(landings[j].first - curr) * c;
            else
                answers[i] = min(answers[i], landings[j].second + abs(landings[j].first - curr) * c);
        }
    }

    for (int i = 0; i < m; i++)
        cout << answers[i] << '\n';

    return 0;
}