#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 1e7 + 5;
int N;
long long K, X, Y, Z, M;
long long arr[MAXN];
long long pref[MAXN];

long long calc(int l, int r)
{
    return pref[r] - pref[l-1];
}

bool sat(int l, int r)
{
    if(l<r && calc(l, r) < 2*K)
        return false;
    
    int l1 = l, r1 = r;
    while(l1 <= r1)
    {
        int mid = (l1+r1)/2;
        if(calc(l, mid) >= K)
            r1 = mid - 1;
        else 
            l1 = mid + 1;
    }
    return calc(l+1, r) >= K;

}

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> K;
    cin >> arr[1] >> arr[2] >> X >> Y >> Z >> M;

    pref[1] = arr[1];
    pref[2] = arr[1] + arr[2];
    for ( int i = 3; i<= N; i++)
    {
        arr[i] = (arr[i-2]*X + arr[i-1]*Y + Z) % M;
        pref[i] = pref[i-1] + arr[i];
    }

    if(!sat(1, N))
    {
        cout << -1 << endl;
        return 0;
    }
    int l = 1, r = 2;
    int res = 1e8;
    
    while(l < N)
    {
        while(r<N && !sat(l, r))
            r++;
        
        if (!sat(l, r))
            break;

        res = min(res, r-l+1);
        l++;
    }

    cout << res << endl;
    

	return 0;
}