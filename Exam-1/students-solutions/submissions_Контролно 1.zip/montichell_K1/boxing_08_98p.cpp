#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 1e7 + 5;
int N;
long long K, X, Y, Z, M;
long long arr[MAXN];
long long pref[MAXN];

long long calc(int l, int r)
{
    return pref[r] - pref[l-1];
}

bool sat(int l, int r)
{
    if(l>=r || calc(l, r) < 2*K)
        return false;
    
    int l1 = l, r1 = r;
    while(l1 <= r1)
    {
        int mid = (l1+r1)/2;
        if(calc(l, mid) >= K)
            r1 = mid - 1;
        else 
            l1 = mid + 1;
    }
    return calc(l1 + 1, r) >= K;

}

bool P(int len)
{
    int l = 1, r= len;
    while(r<=N)
    {
        if (sat(l, r))
            return true;
        l++;
        r++;
    }
    return false;
}

signed main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> K;
    cin >> arr[1] >> arr[2] >> X >> Y >> Z >> M;

    pref[1] = arr[1];
    pref[2] = arr[1] + arr[2];
    for ( int i = 3; i<= N; i++)
    {
        arr[i] = (arr[i-2]*X + arr[i-1]*Y + Z) % M;
        pref[i] = pref[i-1] + arr[i];
    }

    if(!sat(1, N))
    {
        cout << -1 << endl;
        return 0;
    }
    
    int l = 2, r = N;
    while(l<=r)
    {
        int mid = (l+r)/2;
        if(P(mid))
            r = mid-1;
        else 
            l = mid + 1;
    } 

    cout << l << endl;
    

	return 0;
}