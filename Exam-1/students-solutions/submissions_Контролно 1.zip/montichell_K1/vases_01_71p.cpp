#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e7 + 5;
int arr[MAXN];
int N, H;

bool P(int x)
{
    int H_used = 0;
    int i = N-1;
    while(i >=0 )
    {
        H_used += arr[i];
        i -= x;
    }

    return H_used <= H;
}

int main()
{
	
	cin >> N >> H;

	int l=1, r = 1e7;
    for(int i=0; i<N; i++)
    {
        cin >> arr[i];
    }

    sort(arr, arr + N);

	while(l<=r)
	{
		int mid = (l+r)/2;
       // cout << mid << " : " << P(mid) << endl;
		if(P(mid))
            r = mid - 1;
        else
            l = mid + 1;
	}

    cout << l << endl;

	return 0;
}