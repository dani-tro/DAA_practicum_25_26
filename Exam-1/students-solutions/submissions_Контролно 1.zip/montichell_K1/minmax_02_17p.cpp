#include <bits/stdc++.h>

using namespace std;

#define int long long

const int MAXN = 1e5 + 5;
int N;
long long S;
long long arr[MAXN];

signed main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> S;
    for(int i=0; i<N; i++)
    {
        cin >> arr[i];
    }
    sort(arr, arr + N);

    int l = 0, r = N - 1;
    while(arr[r] - arr[l] > 0 && S>0)
    {
        if(
            (arr[l+1] - arr[l]) * (l+1) < (arr[r] - arr[r-1])*(N-r)
            && (arr[l+1] - arr[l]) * (l+1) <= S
        )
        {
            S -= (arr[l+1] - arr[l]) * (l+1);
            l++;
        }
        else if (
            (arr[l+1] - arr[l]) * (l+1) >= (arr[r] - arr[r-1])*(N-r)
            && (arr[r] - arr[r-1])*(N-r) <= S
        )
        {
            S-=(arr[r] - arr[r-1])*(N-r);
            r--;
        }
        else
        {
            if(N-r < l+1)
            {
                arr[r] -= S/(N-r); 
            }
            else
            {
                arr[l] += S/(l+1);
            }

            break;
        }
    }
    cout << max(0ll, arr[r] - arr[l]) << endl;

	return 0;
}

