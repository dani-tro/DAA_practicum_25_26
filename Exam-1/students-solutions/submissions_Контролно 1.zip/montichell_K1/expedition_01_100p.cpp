#include <bits/stdc++.h>

using namespace std;

struct Event{
    int num;
    int type; //0 for stop | 1 for expedition
    int id;

    friend bool operator<(struct Event &a, struct Event &b){
        if(a.num != b.num)
            return a.num < b.num;
        return a.type < b.type;
    }
};

const int MAXN = 1e5 + 5;
const int MAXM = 1e5 + 5;
int N, M, C;
long long B[MAXN];
struct Event ev[MAXM + MAXN];
int ev_size = 0;
long long res[MAXM];

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> M >> C;
    for(int i = 0; i < N; i++)
    {
        int a;
        cin >> a >> B[i];

        ev[ev_size++] = {a, 0, i};
    }

    for(int i=0; i<M; i++){
        int d;
        cin >> d;
        ev[ev_size++] = {d, 1, i};
    }

    sort(ev, ev + ev_size);

    long long min_dist = 1e10;
    int last_num = 0;
    for(int i=0; i< ev_size; i++)
    {
        if(ev[i].type == 1)
        {
            res[ev[i].id] = min_dist + C*(ev[i].num-last_num);
        }
        else
        {
            min_dist = min(min_dist + C*(ev[i].num-last_num), B[ev[i].id]);
            last_num = ev[i].num;
        }
    }

    min_dist = 1e10;
    last_num = ev[ev_size-1].num;
    for(int i = ev_size - 1; i >= 0; i--)
    {
        if(ev[i].type == 1)
        {
            res[ev[i].id] = min(res[ev[i].id], min_dist + C*(last_num - ev[i].num));
        }
        else
        {
            min_dist = min(min_dist + C*(last_num - ev[i].num), B[ev[i].id]);
            last_num = ev[i].num;
        }
    }

    for(int i=0; i<M; i++)
    {
        cout << res[i] << endl;
    }

	return 0;
}