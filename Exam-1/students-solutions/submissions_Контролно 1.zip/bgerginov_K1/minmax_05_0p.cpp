#include <bits/stdc++.h>
using namespace std;

#define MAX 200000
#define MAX2 11000000000

long long n,s,a[MAX];
long long freq[MAX2];

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> s;
    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
        freq[a[i]]++;
    }
    sort(a+1, a+n+1);
    long long min = a[1];
    long long max = a[n];

    while(s > 0)
    {
        


        if(freq[min] < freq[max])
        {
            a[freq[min]]++;
            freq[min+1] = freq[min+1] +1;
            freq[min]--;
        }
        else
        {
            a[n-freq[max]+1]--;
            freq[max-1] = freq[max-1] + 1;
            freq[max]--;
        }

        s--;
        min = a[1];
        max = a[n];
        //cout << a[n] - a[1] << ' ' << min << ' ' << max << ' ' << freq[min] << ' ' << freq[max] << endl;
    }

    cout << a[n] - a[1] << endl;


    return 0;
}