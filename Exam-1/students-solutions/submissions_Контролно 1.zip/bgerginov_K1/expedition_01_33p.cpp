#include <bits/stdc++.h>
using namespace std;

#define MAX 110000

long long n,m,c;
long long a[MAX], b[MAX];
long long d[MAX];


int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> c;
    for(int i = 1; i <= n; i++)
    {
        cin >> a[i] >> b[i];
    }
    for(int i = 1; i <= m; i++)
    {
        cin >> d[i];
    }

    for(int i = 1; i <= m; i++)
    {
        long long best = INT_MAX;
        for(int j = 1; j <= n; j++)
        {
            long long curr_price = b[j] + abs(d[i] - a[j])*c;
            best = min(best, curr_price);
        }
        cout << best << endl;
    }

    return 0;
}
