#include <bits/stdc++.h>
using namespace std;

#define MAX 200000


long long n,s,a[MAX];
long long res[MAX];

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> s;
    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    sort(a+1, a+n+1);
    long long prev_sum = a[n] - a[1];

    long long temp = a[1], cnt = 0, j = 1;
    for(int i = 1; i <= n; i++)
    {
        if(a[i] == temp)
        {
            cnt++;
        }
        else
        {
            res[j] = cnt;
            j++;
            cnt = 1;
            temp = a[i];
        }
    }
    res[j] = cnt;

    long long l = 1, r = j;
    while(s > 0)
    {
        if(res[l] < res[r])
        {
            if(s-res[l] >= 0)
            {
                s -= res[l];
                l++;
            }
            else
            {
                s = 0;
            }
        }
        else
        {
            if(s-res[r] >= 0)
            {
                s -= res[r];
                r--;
            }
            else s = 0;
        }
    }

    long long dec = (l-1) + (j-r);
    cout << prev_sum - dec <<endl;

    


    return 0;
}