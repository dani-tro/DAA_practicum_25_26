#include <bits/stdc++.h>
using namespace std;

#define MAX 11000000
long long n, h, a[MAX];

bool isOkay(long long width)
{
    long long total = 0;
    long long i = n;
    while(i > 0)
    {
        total += a[i];
        i -= width;
    }

    return total <= h;
}


int main()
{
    cin >> n >> h;
    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }

    sort(a+1,a+n+1);

    long long l = 1;
    long long r = n;
    while(l < r)
    {
        long long mid = (l+r)/2;
        if(isOkay(mid))
        {
            r = mid;
        }
        else l = mid+1;
    }

    cout << l <<endl;
    

    return 0;
}