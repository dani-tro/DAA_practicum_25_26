#include <iostream>
#include <vector>

#define endl '\n'

using namespace std;

long long findLowestCost(long long target, long long walkCost, int n, vector<long long> &distances, vector<long long> &fuelCosts)
{
    long long result = 0;

    for (int i = 0; i < n; ++i)
    {
        long long currentCost = fuelCosts[i];
        currentCost += abs(distances[i] - target) * walkCost;

        if (i == 0 || currentCost < result)
        {
            result = currentCost;
        }
    }

    return result;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    long long c;
    cin >> n >> m >> c;

    vector<long long> distances(n);
    vector<long long> fuelCosts(n);

    for (int i = 0; i < n; ++i)
    {
        cin >> distances[i] >> fuelCosts[i];
    }

    for (int i = 0; i < m; ++i)
    {
        long long target;
        cin >> target;

        cout << findLowestCost(target, c, n, distances, fuelCosts) << endl;
    }

    return 0;
}