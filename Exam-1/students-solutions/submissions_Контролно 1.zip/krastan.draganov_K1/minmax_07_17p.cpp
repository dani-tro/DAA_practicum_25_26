#include <iostream>
#include <algorithm>
#include <vector>

#define endl '\n'

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n;
    long long s;
    cin >> n >> s;

    vector<long long> numbers(n);

    for (int i = 0; i < n; ++i)
    {
        cin >> numbers[i];
    }

    sort(numbers.begin(), numbers.end());

    int left = 0;
    int right = n - 1;

    long long leftSameCount = 1;
    long long rightSameCount = 1;

    long long remainingOperations = s;

    while (remainingOperations > 0ll)
    {
        while (left < right && numbers[left] == numbers[left + 1])
        {
            ++left;
            ++leftSameCount;
        }

        while (left < right && numbers[right] == numbers[right - 1])
        {
            --right;
            ++rightSameCount;
        }

        if (left == right)
        {
            break;
        }

        long long leftDifference = numbers[left + 1] - numbers[left];
        long long rightDifference = numbers[right] - numbers[right - 1];

        long long neededOperationsLeft = leftSameCount * leftDifference;
        long long neededOperationsRight = rightSameCount * rightDifference;

        if (neededOperationsLeft <= neededOperationsRight && neededOperationsLeft <= remainingOperations)
        {

            numbers[left] += leftDifference;
            remainingOperations -= neededOperationsLeft;
        }
        else if (neededOperationsRight < neededOperationsLeft && neededOperationsRight <= remainingOperations)
        {
            numbers[right] -= rightDifference;
            remainingOperations -= neededOperationsRight;
        }
        else if (leftSameCount < rightSameCount)
        {
            numbers[left] += (remainingOperations / leftSameCount);
            remainingOperations = 0ll;
        }
        else
        {
            numbers[right] += (remainingOperations / rightSameCount);
            remainingOperations = 0ll;
        }

        // if (neededOperationsLeft < neededOperationsRight)
        // {
        //     if (neededOperationsLeft > remainingOperations)
        //     {
        //         numbers[left] += (remainingOperations / leftSameCount);
        //         remainingOperations %= leftSameCount;
        //     }
        //     else
        //     {
        //         numbers[left] += leftDifference;
        //         remainingOperations -= neededOperationsLeft;
        //     }
        // }
        // else
        // {
        //     if (neededOperationsRight > remainingOperations)
        //     {
        //         numbers[right] -= (remainingOperations / rightSameCount);
        //         remainingOperations %= rightSameCount;
        //     }
        //     else
        //     {
        //         numbers[right] -= rightDifference;
        //         remainingOperations -= neededOperationsRight;
        //     }
        // }
    }

    cout << numbers[right] - numbers[left] << endl;

    return 0;
}