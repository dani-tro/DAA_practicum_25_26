#include <iostream>
#include <vector>
#include <algorithm>

#define endl '\n'

using namespace std;

bool canMakeWardrobe(int maxWidth, int maxHeight, int n, vector<int> &vases)
{
    int currentHeight = vases[n - 1];
    int currentWidth = 0;

    for (int i = n - 1; i >= 0 && currentHeight <= maxHeight; --i)
    {
        if (currentWidth == maxWidth)
        {
            currentWidth = 0;
            currentHeight += vases[i];
        }

        ++currentWidth;
    }

    return currentHeight <= maxHeight;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, h;
    cin >> n >> h;

    vector<int> vases(n);

    for (int i = 0; i < n; ++i)
    {
        cin >> vases[i];
    }

    sort(vases.begin(), vases.end());

    int left = 1, right = n;

    while (left <= right)
    {
        int mid = (left + right) / 2;

        if (canMakeWardrobe(mid, h, n, vases))
        {
            right = mid - 1;
        }
        else
        {
            left = mid + 1;
        }
    }

    cout << right + 1 << endl;

    return 0;
}