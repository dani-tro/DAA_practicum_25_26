#include <iostream>
#include <vector>

#define endl '\n'

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n;
    long long k;
    cin >> n >> k;

    vector<long long> powers(n);
    cin >> powers[0] >> powers[1];

    long long x, y, z, m;
    cin >> x >> y >> z >> m;

    for (int i = 2; i < n; ++i)
    {
        powers[i] = (powers[i - 2] * x % m + powers[i - 1] * y % m + z) % m;
    }

    int boxer1Right = 0;
    long long boxer1Power = powers[0];

    int boxer2Right = 1;
    long long boxer2Power = powers[1];

    int result = -1;

    for (int boxer1Left = 0; boxer1Left < n; ++boxer1Left)
    {
        int boxer2Left = boxer1Right + 1;

        if (boxer1Left > 0)
        {
            boxer1Power -= powers[boxer1Left - 1];
        }

        if (boxer1Right < boxer1Left)
        {
            boxer1Power = powers[boxer1Left];
            ++boxer1Right;
        }

        while (boxer1Right + 1 < n && boxer1Power < k)
        {
            ++boxer1Right;
            boxer1Power += powers[boxer1Right];
        }

        if (boxer1Power < k)
        {
            break;
        }

        while (boxer2Left <= boxer1Right)
        {
            if (boxer2Left <= boxer2Right)
            {
                boxer2Power -= powers[boxer2Left];
            }

            ++boxer2Left;
        }

        if (boxer2Left >= n)
        {
            break;
        }

        if (boxer2Left > boxer2Right)
        {
            boxer2Power = powers[boxer2Left];

            while (boxer2Right < boxer2Left)
            {
                ++boxer2Right;
            }
        }

        while (boxer2Right + 1 < n && boxer2Power < k)
        {
            ++boxer2Right;
            boxer2Power += powers[boxer2Right];
        }

        if (boxer2Power < k)
        {
            continue;
        }

        int currentCount = boxer2Right - boxer1Left + 1;

        if (result == -1 || currentCount < result)
        {
            result = currentCount;
        }
    }

    cout << result << endl;

    return 0;
}