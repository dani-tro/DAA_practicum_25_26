#include <iostream>
#include <algorithm>
#include <vector>

#define endl '\n'
#define int long long

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n;
    long long s;
    cin >> n >> s;

    vector<long long> numbers(n);

    for (int i = 0; i < n; ++i)
    {
        cin >> numbers[i];
    }

    sort(numbers.begin(), numbers.end());

    int left = 0;
    int right = n - 1;

    long long leftSameCount = 1;
    long long rightSameCount = 1;

    long long remainingOperations = s;

    while (remainingOperations > 0)
    {
        while (left < right && numbers[left] == numbers[left + 1])
        {
            ++left;
            ++leftSameCount;
        }

        while (left < right && numbers[right] == numbers[right - 1])
        {
            --right;
            ++rightSameCount;
        }

        if (left == right)
        {
            break;
        }

        long long leftDifference = numbers[left + 1] - numbers[left];
        long long rightDifference = numbers[right] - numbers[right - 1];

        if (leftDifference < rightDifference || (leftDifference == rightDifference && leftSameCount < rightSameCount))
        {
            long long neededOperations = 1ll * leftSameCount * leftDifference;

            if (neededOperations > remainingOperations)
            {
                numbers[left] += (remainingOperations / leftSameCount);
                remainingOperations = 0;
            }
            else
            {
                numbers[left] += leftDifference;
                remainingOperations -= neededOperations;
            }
        }
        else
        {
            long long neededOperations = 1ll * rightSameCount * rightDifference;

            if (neededOperations > remainingOperations)
            {
                numbers[right] -= (remainingOperations / rightSameCount);
                remainingOperations = 0;
            }
            else
            {
                numbers[right] -= rightDifference;
                remainingOperations -= neededOperations;
            }
        }
    }

    cout << numbers[right] - numbers[left] << endl;

    return 0;
}