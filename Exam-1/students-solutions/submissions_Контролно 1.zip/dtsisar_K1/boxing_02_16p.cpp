#include <iostream>
#include <algorithm>
#include <climits>

using namespace std;
#define int long long

const int MAX = 10000002;

int n, k;
int a1, a2, x, y, z, m;
int bags[MAX], pref[MAX];

signed main()
{

	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> k;
	cin >> a1 >> a2 >> x >> y >> z >> m;
	bags[1] = a1;
	bags[2] = a2;

	for (int i = 3; i <= n; ++i) {
		bags[i] = (bags[i - 2] * x + bags[i - 1] * y + z) % m;
	}

	for (int i = 1; i <= n; ++i) {
		pref[i] = pref[i - 1] + bags[i];
	}

	int r = 1;
	int minLenght = LLONG_MAX;
	for (int l = 0; l <= n; ++l) {
		int currLenght;

		while (r <= n && pref[r] - pref[l] < k) {
			r++;
		}
		if (pref[r] - pref[l] >= k) {
			while (r-1 > 0 && pref[r - 1] - pref[l] >= k) {
				r--;
			}
			while (r <= n && pref[r] - pref[l] < 2 * k)
			{
				r++;
			}

			if (pref[r] - pref[l] >= k) {
				currLenght = r - l;
				minLenght = min(minLenght, currLenght);
			}
		}

	}

	if (minLenght == LLONG_MAX) {
		minLenght = -1;
	}

	cout << minLenght << "\n";

	return 0;
}

