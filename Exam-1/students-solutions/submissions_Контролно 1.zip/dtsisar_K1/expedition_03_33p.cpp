#include <iostream>
#include <algorithm>
#include <climits>

using namespace std;
#define int long long

const int MAX = 10000002;

int n, m, c;
struct Landing {
	int pos;
	int cost;

	bool operator<(const Landing& other) const {
		return cost < other.cost;
	}
};

Landing pads[MAX];
int dest[MAX];

int getCost(int landingIdx, int destIdx) {
	return pads[landingIdx].cost + (abs(dest[destIdx] - pads[landingIdx].pos) * c);
}

signed main()
{

	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m >> c;
	for (int i = 0; i < n; ++i) {
		int pos, cost;
		cin >> pos >> cost;
		pads[i] = { pos, cost };
	}
	sort(pads, pads + n);

	for (int i = 0; i < m; ++i) {
		cin >> dest[i];
	}

	for (int i = 0; i < m; ++i) {
		
		int minCost = LLONG_MAX;
		for (int k = 0; k < n; ++k) {
			minCost = min(minCost, getCost(k, i));
		}
		cout << minCost << "\n";
	}

	

	return 0;
}

