#include <iostream>
#include <algorithm>
#include <climits>

using namespace std;
#define int long long

const int MAX = 10000002;

int n, m, c;
struct Landing {
	int pos;
	int cost;

	bool operator<(const Landing& other) const {
		return cost < other.cost;
	}
};

Landing pads[MAX];
int dest[MAX];

int getCost(int landingIdx, int destIdx) {
	return pads[landingIdx].cost + (abs(dest[destIdx] - pads[landingIdx].pos) * c);
}

signed main()
{

	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> m >> c;
	for (int i = 0; i < n; ++i) {
		int pos, cost;
		cin >> pos >> cost;
		pads[i] = { pos, cost };
	}
	sort(pads, pads + n);

	for (int i = 0; i < m; ++i) {
		cin >> dest[i];
	}

	for (int i = 0; i < m; ++i) {
		int low = 0;
		int high = n - 1;

		while (high - low > 2) {
			int m1 = low + (high - low) / 3;
			int m2 = high - (high - low) / 3;

			if (getCost(m1, i) < getCost(m2, i)) {
				high = m2;
			}
			else {
				low = m1;
			}
		}
		int minCost = LLONG_MAX;
		for (int k = low; k <= high; ++k) {
			minCost = min(minCost, getCost(k, i));
		}
		cout << minCost << "\n";
	}

	

	return 0;
}

