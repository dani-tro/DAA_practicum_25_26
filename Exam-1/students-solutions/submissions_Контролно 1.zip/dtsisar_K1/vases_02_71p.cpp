#include <iostream>
#include <algorithm>

using namespace std;
#define int long long

const int MAX = 200005;

int n, h;
int vases[MAX];

int comp(int x, int y) {
	return x > y;
}

bool check(int x) {
	int curr = 0;
	int currHeight = vases[0];

	for (int i = 0; i < n; ++i) {
		if (curr != x) {
			curr++;
		}
		else {
			curr = 1;
			currHeight += vases[i];

			if (currHeight > h) {
				return false;
			}
		}
	}
	return true;
}

signed main()
{

	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	cin >> n >> h;
	for (int i = 0; i < n; ++i) {
		cin >> vases[i];
	}

	sort(vases, vases + n, comp);

	int low = 0;
	int high = n;
	int ans;

	while (low <= high) {
		int mid = low + (high - low) / 2;

		if (check(mid)) {
			high = mid - 1;
			ans = mid;
		}
		else {
			low = mid + 1;
		}
	}

	cout << ans << "\n";

	return 0;
}

