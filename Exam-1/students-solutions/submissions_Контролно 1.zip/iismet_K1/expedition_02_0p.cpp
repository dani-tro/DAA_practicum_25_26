#include <bits/stdc++.h>

//#define int long long
using namespace std;


double arr[99999]; double brr [99999];
double drr[99999];

double consOverDist[99999];

double mins[99999];

void findMinC(int c, int j, int n)
{
    for (size_t i = 0; i < n; i++)
    {
        double currentC = brr[i] + abs(drr[j]-arr[i]) * c;

        if( currentC < mins[j]) mins[j] = currentC;
    }

    cout << mins[j] << '\n';
    
}

void sortCons(int n)
{
    for (size_t i = 0; i < n; i++)
    {
        for (size_t j = 0; j < n-i-1; j++)
        {
            if(consOverDist[j] > consOverDist[j+1])
            {
                swap(consOverDist[j], consOverDist[j+1]);
                swap(arr[j], arr[j+1]);
                swap(brr[j], brr[j+1]);
            }
        }
    }
    
}
signed main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);


    int n,m,c;
    cin >> n >> m >> c;

    for (size_t i = 0; i < n; i++)
    {
            cin >> arr[i] >> brr[i];

            consOverDist[i] = brr[i]/drr[i];    
    }

    sortCons(n);

    for (size_t i = 0; i < m; i++)
    {
        cin >> drr[i];
        mins[i] = 1e+10;
    }
    
    for (size_t j = 0; j < m; j++)
    {
        findMinC(c,j,n);
    }    
    return 0;
}