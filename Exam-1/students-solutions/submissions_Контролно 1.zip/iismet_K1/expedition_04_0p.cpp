#include <bits/stdc++.h>

// #define int long long
using namespace std;

double arr[99999];
double brr[99999];
double drr[99999];

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    double c;
    cin >> n >> m >> c;

    for (size_t i = 0; i < n; i++)
    {
        cin >> arr[i] >> brr[i];
    }

    for (size_t i = 0; i < m; i++)
    {
        cin >> drr[i];
    }

    for (size_t j = 0; j < m; j++)
    {
        double minC = 1e+10;

        for (size_t i = 0; i < n; i++)
        {
            double currentC = brr[i] + abs(drr[j] - arr[i]) * c;
            if (currentC < minC)
                minC = currentC;
        }

        cout << minC << '\n';
    }
    return 0;
}