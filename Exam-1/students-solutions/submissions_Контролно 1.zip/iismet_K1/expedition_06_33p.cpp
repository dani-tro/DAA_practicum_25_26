#include <bits/stdc++.h>

#define int long long
using namespace std;

int arr[99999];
int brr[99999];
int drr[99999];


signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    int c;
    cin >> n >> m >> c;

    for (size_t i = 0; i < n; i++)
    {
        cin >> arr[i] >> brr[i];
    }

    for (size_t i = 0; i < m; i++)
    {
        cin >> drr[i];
    }

    for (size_t j = 0; j < m; j++)
    {
        int minC = 1000000000000;

        for (size_t i = 0; i < n; i++)
        {
            double currentC = brr[i] + abs(drr[j] - arr[i]) * c;
            if (currentC < minC)
                minC = currentC;
        }

        cout << minC << '\n';
    }
    return 0;
}