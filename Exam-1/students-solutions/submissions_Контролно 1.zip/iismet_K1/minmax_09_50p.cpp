#include <bits/stdc++.h>

//#define int long long
using namespace std;

//minmax
long long arr[100003];
signed main()
{
    long long n;
    long long s;

    cin >> n >> s;

    
    cin >> arr[0];
    long long biggest = arr[0];
    long long smalles = arr[0];

    for (size_t i = 1; i < n; i++)
    {
        cin>> arr[i];
        if(arr[i] > biggest) biggest = arr[i];
        if(arr[i] < smalles) smalles = arr[i];
    }
    long long len = biggest + 1;
    long long* cntr = new long long[len];

    for (size_t i = 0; i < len; i++)
    {
        cntr[i] = 0;
    }

    for (size_t i = 0; i < n; i++)
    {
        ++cntr[arr[i]];
    }

    // for (size_t i = 0; i < len; i++)
    // {
    //     cout << cntr[i] << ' ';
    // }
    
    while( (cntr[biggest]<=s || cntr[smalles]<=s) && s>0)
    {
        if(cntr[biggest]<cntr[smalles])
        {
            cntr[biggest-1] += cntr[biggest];
            s -= cntr[biggest];
            cntr[biggest]=0;
            --biggest; 

        }
        else
        {
            cntr[smalles+1] += cntr[smalles];
            s -= cntr[smalles];
            cntr[smalles]=0;
            ++smalles;
        }

    }
        cout << biggest - smalles;
}