#include <bits/stdc++.h>

//#define int long long
using namespace std;

//minmax
int cntr[10000000001];
signed main()
{
    int n;
    long long s;

    cin >> n >> s;

    long long temp;
    cin >> temp;
    ++cntr[temp];
    long long biggest = temp;
    long long smalles = temp;

    for (size_t i = 1; i < n; i++)
    {
        cin >> temp;
        ++cntr[temp];
        if(temp>biggest) biggest = temp;
        if(temp<smalles) smalles = temp;
    }

    while( (cntr[biggest]<=s || cntr[smalles]<=s) && s>0)
    {
        if(cntr[biggest]<cntr[smalles])
        {
            cntr[biggest-1] += cntr[biggest];
            s -= cntr[biggest];
            cntr[biggest]=0;
            --biggest; 

        }
        else
        {
            cntr[smalles+1] += cntr[smalles];
            s -= cntr[smalles];
            cntr[smalles]=0;
            ++smalles;
        }

    }
        cout << biggest - smalles;
    
    
    
}