#include <bits/stdc++.h>

//#define int long long
using namespace std;

//minmax
int cntr[100000001];

signed main()
{
    int n, s;

    cin >> n >> s;

    long long biggest = 0;
    long long smalles = 10000000003;
    for (size_t i = 0; i < n; i++)
    {
        long long temp;
        cin >> temp;
        ++cntr[temp];
        if(temp>biggest) biggest = temp;
        if(temp<smalles) smalles = temp;
    }

    while( (cntr[biggest]<=s || cntr[smalles]<=s) && s>0)
    {
        if(cntr[biggest]<cntr[smalles])
        {
            cntr[biggest-1] += cntr[biggest];
            s -= cntr[biggest];
            --biggest; 

        }
        else
        {
            cntr[smalles+1] += cntr[smalles];
            s -= cntr[smalles];
            ++smalles;
        }

        
    }
        cout << biggest - smalles;
    
    
    
}