#include <bits/stdc++.h>

//#define int long long
using namespace std;
int x,y,z,m;
void recur(int *arr,int n, int i)
{
    if(i>=n) return;
    
    arr[i] = (arr[i-2]*x + arr[i-1]*y + z) % m;

    recur(arr,n,i+1);
}

int sumSubArr(int l, int r, int* arr)
{
    
    int sumSubar = 0;

    for (size_t i = l; i <= r; i++)
    {
        sumSubar+= arr[i];
    }
    return sumSubar;
}

signed main()
{

    int n,k,a1,a2;

    int* arr = new int [n+1];
    cin >> n >> k >> arr[0] >> arr[1] >> x >> y >>z >> m;

    recur(arr,n,2);

    int box1=0,box2=0;
    int left = 0; int right = n-1;

    int all = sumSubArr(0,n-1,arr);
    if (all < 2*k)
    {
        cout << -1;
        return 0;
    }
    
    int dist = n;

    for (size_t d = left; d < right;)
    {
        int sum = sumSubArr(left,d,arr);
        if(sum>=k && (all - sum)>=k) 
        {
            dist = right - left + 1;

            if(arr[left]<arr[right])
            {
                left++;
                d--;
            }
            else
            {
                right--;
                d--;
            }
        } 

        if(sum<k && (all - sum) >= k)
        {
            d++;
        }

        if(sum >=k && (all - sum) < k)
        {
            break;
        }
    }

    cout << (dist == n) ? -1 : dist;
    
    


    

    


}