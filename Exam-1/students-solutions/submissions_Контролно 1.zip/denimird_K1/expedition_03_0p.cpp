#include<iostream>
#include<algorithm>
using namespace std;
#define MAXN 100005
struct field{
    long long dest;
    long long cost;
    bool operator<(const field& other){
        if(this->cost == other.cost){
            return this->dest<other.dest;
        }
        return this->cost<other.cost;
    }
};
field fields[MAXN];
long long targets[MAXN];
long long ans[MAXN];
int n, m;
long long c;
long long cost(int field, int target){
    return fields[field].cost + c*abs(fields[field].dest - targets[target]);
}
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>m>>c;
    for(int i=0; i<n; i++){
        cin>>fields[i].dest>>fields[i].cost;
    }
    sort(fields, fields+n);
    for(int i=0; i<m; i++){
        cin>>targets[i];
    }
    for(int i=0; i<m; i++){
        int left = 0, right = n-1;
        ans[i] = cost(0, i);
        while(left<right){
            int m1 = left + (right-left)/3;
            int m2 = right - (right-left)/3;
            if(cost(m1, i)<cost(m2, i)){
                ans[i] = cost(m1, i);
                right = m2-1;
            }
            else{
                ans[i] = cost(m2, i);
                left = m1+1;
            }
        }
        cout<<ans[i]<<endl;
    }
}