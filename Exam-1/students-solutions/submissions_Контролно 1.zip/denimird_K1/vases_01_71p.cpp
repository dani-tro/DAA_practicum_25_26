#include<iostream>
#include<algorithm>
using namespace std;
#define MAXN 10000005
long long v[MAXN];
long long n, h;
bool possible(long long width){
    long long sum = 0;
    for(int i=0; i<n; i++){
        if(i%width==0){
            sum+=v[i];
            if(sum>h) return false;
        }
    }
    return true;
}
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>h;
    for(int i=0; i<n; i++){
        cin>>v[i];
    }
    sort(v, v+n, greater<long long>());
    long long left = 1, right = n, ans = n;
    while(left<=right){
        long long mid = left + (right-left)/2;
        if(possible(mid)){
            ans = mid;
            right = mid-1;
        }
        else{
            left = mid+1;
        }
    }
    cout<<ans<<endl;
}