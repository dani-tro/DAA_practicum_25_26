#include<iostream>
#include<algorithm>
using namespace std;
#define MAXN 100005
long long fields[MAXN];
long long costs[MAXN];
long long targets[MAXN];
long long ans[MAXN];
int n, m;
long long c;
long long cost(int field, int target){
    return costs[field] + c*abs(fields[field] - targets[target]);
}
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>m>>c;
    for(int i=0; i<n; i++){
        cin>>fields[i]>>costs[i];
    }
    for(int i=0; i<m; i++){
        cin>>targets[i];
    }
    for(int i=0; i<m; i++){
        ans[i] = cost(0, i);
        for(int j=1; j<n; j++){
            ans[i] = min(ans[i], cost(j, i));
        }
        cout<<ans[i]<<endl;
    }
}