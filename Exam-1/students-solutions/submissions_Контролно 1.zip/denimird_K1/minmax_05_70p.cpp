#include<iostream>
#include<algorithm>
using namespace std;
#define MAXN 100005
long long v[MAXN];
int n;
long long s;
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>s;
    for(int i=0; i<n; i++){
        cin>>v[i];
    }
    sort(v, v+n, greater<long long>());
    long long max = v[0], min = v[n-1], left = 1, right = n-2, max_count = 1, min_count=1;
    while(s>0 && min<max){
        while(v[left]==max){
            left++;
            max_count++;
        }
        while(v[right]==min){
            right--;
            min_count++;
        }
        if(min_count>s && max_count>s) break;
        else if(min_count<max_count){
            s-=min_count;
            min++;
        }
        else{
            s-=max_count;
            max--;
        }
    }
    cout<<max-min<<endl;
}