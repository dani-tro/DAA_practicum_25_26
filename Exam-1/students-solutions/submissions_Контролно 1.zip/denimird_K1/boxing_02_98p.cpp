#include<iostream>
#include<algorithm>
using namespace std;
#define MAXN 10000005
long long v[MAXN];
long long n, k;
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin>>n>>k;
    long long x, y, z, m;
    cin>>v[0]>>v[1]>>x>>y>>z>>m;
    for(int i=2; i<n; i++){
        v[i] = (v[i-2]*x+v[i-1]*y+z)%m;
    }
    long long leftSum = 0, rightSum = 0, left = 0, right = 0, currLeft = 0, currRight = 0;
    long long ans = -1;
    while(right<n){
        while(leftSum<k && currLeft<n-1){
            leftSum += v[currLeft++];
            if(left!=0 && currRight<=currLeft){
                rightSum -= v[currRight++];
            }
        }
        if(currRight<currLeft){
            right = currRight=currLeft;
        }
        while(rightSum<k && right<n){
            rightSum += v[right++];
        }
        if(currLeft==n-1 || right == n) break;
        if(ans==-1) ans = right - left; 
        else if(right-left<ans) ans = right - left;
        leftSum -= v[left++];
    }
    cout<<ans<<endl;
}