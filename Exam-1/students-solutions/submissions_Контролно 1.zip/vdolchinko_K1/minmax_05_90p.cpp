#include <iostream>
#include <algorithm>
#include <queue>

using namespace std;

int arr[100001]{};


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n;
	long long s;
	std::cin >> n >> s;


	for (int i = 0; i < n; i++)
	{
		std::cin >> arr[i];
	}

	sort(arr, arr + n);

	int minVal = arr[0];
	int maxVal = arr[n - 1];
	int minCount = 0;
	for (int i = minCount; arr[i] == minVal; minCount++, i++);
	int maxCount = 0;
	for (int i = n - 1 - maxCount; arr[i] == maxVal; maxCount++, i--);
	while (s > 0)
	{
		if (minCount < maxCount)
		{
			if (s < minCount) break;
			minVal++;
			s -= minCount;
			for (int i = minCount; arr[i] == minVal; minCount++, i++);
		}
		else
		{
			if (s < maxCount) break;
			maxVal--;
			s -= maxCount;
			for (int i = n - 1 - maxCount; arr[i] == maxVal; maxCount++, i--);
		}

	}

	std::cout << maxVal - minVal;
}