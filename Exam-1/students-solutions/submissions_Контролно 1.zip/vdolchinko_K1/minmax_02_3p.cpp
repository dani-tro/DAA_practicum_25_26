#include <iostream>
#include <algorithm>
#include <queue>

using namespace std;

int arr[10000001]{};
int cnt[2001]{};

pair<int, int> findMin()
{
	int min;
	for (int i = 0; i < 2001; i++)
	{
		if (cnt[i] != 0)
		{
			min = i;
			break;
		}
	}
	return pair<int,int>(min, cnt[min]);
}

pair<int, int> findMax()
{
	int max;
	for (int i = 2000; i >= 0; i--)
	{
		if (cnt[i] != 0)
		{
			max = i;
			break;
		}
	}
	return pair<int, int>(max, cnt[max]);
}


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n;
	long long s;
	std::cin >> n >> s;

	//for (int i = 0; i < n; i++)
	//{
	//	std::cin >> arr[i];
	//}

	//std::priority_queue<int> maxHeap;
	//priority_queue<int, std::vector<int>, std::greater<int> > minHeap;



	for (int i = 0; i < n; i++)
	{
		std::cin >> arr[i];
		cnt[arr[i]]++;
	}




	//for (int i = 0; i < s; i++)
	//{
	//	pair min = findMin();
	//	pair max = findMax();
	//	if (min.second < max.second)
	//	{
	//		cnt[min.first]--;
	//		cnt[min.first + 1]++;
	//	}
	//	else
	//	{
	//		cnt[max.first]--;
	//		cnt[max.first - 1]++;
	//	}
	//}

	while (s > 0)
	{
		pair min = findMin();
		pair max = findMax();
		if (min.second < max.second)
		{
			if (min.second > s) break;
			cnt[min.first] = 0;
			cnt[min.first + 1] += min.second;
			s -= min.second;
		}
		else
		{
			if (max.second > s) break;
			cnt[max.first] = 0;
			cnt[max.first - 1] += max.second;
			s -= max.second;
		}

	}

	pair min = findMin();
	pair max = findMax();
	std::cout << max.first - min.first;
}