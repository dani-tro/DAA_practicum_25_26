#include <bits/stdc++.h>
#define int long long
using namespace std;

const int maxN = 1e7 + 10;
int N, K, X, Y, Z, M;
int a[maxN];
int pref[maxN];

bool check(int l, int r)
{
    int s1 = a[l], s2 = a[r];
    while(l < r - 1)
    {
        if(s1 < s2)
        {
            l++;
            s1+=a[l];
        }
        else
        {
            r--;
            s2+=a[r];
        }
    }
    return s1 >= K && s2 >= K;
}

bool calc(int len)
{
    int i = 0, j = 0;
    int s1 = 0, s = 0;
    for(;i < N - len; i++)
    {
        s = pref[i+len - 1] - pref[i] + a[i];
        while(s1 < K && j <= i+len - 1)
        {
            j++;
            s1 = pref[j] - pref[i] + a[i];
        }
        if(s1 >= K && s - s1 >= K) return true;
    }
    return false;
}

signed main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> K >> a[0] >> a[1] >> X >> Y >> Z >> M;
    pref[0] = a[0];
    pref[1] = a[0] + a[1];
    for(int i = 2; i < N; i++)
    {
        a[i] = (a[i-2]*X + a[i-1]*Y + Z) % M;
        pref[i] = pref[i - 1] + a[i];
    }

    if(!check(0, N - 1))
    {
        cout << -1 << "\n";
        return 0;
    }

    int l = 2, r = N, mid;
    while(l < r)
    {
        mid = (l + r) / 2;
        if(calc(mid))
        {
            r = mid;
        }
        else
        {
            l = mid + 1;
        }
    }

    cout << l << "\n";
    //cout << calc(2) << "\n";

    return 0;
}