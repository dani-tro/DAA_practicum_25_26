#include <bits/stdc++.h>
#define int long long
using namespace std;

const int maxN = 1e5 + 10;
int N, M, C;
pair<int, int> a[maxN];


void solve(int d)
{
    int ans = numeric_limits<int>::max();
    for(int i = 0; i < N; i++)
    {
        int s = abs(a[i].first - d)*C + a[i].second;
        ans = min(ans, s);
    }

    cout << ans << "\n";
}

signed main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> M >> C;

    for(int i = 0; i < N; i++)
    {
        cin >> a[i].first >> a[i].second;
    }

    for(int i = 0; i < M; i++)
    {
        int d;
        cin >> d;
        solve(d);
    }

    return 0;
}