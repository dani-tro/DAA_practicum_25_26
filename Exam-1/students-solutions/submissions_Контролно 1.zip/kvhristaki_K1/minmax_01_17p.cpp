#include <bits/stdc++.h>
#define int long long
using namespace std;

const int maxN = 1e5 + 10;
int N, S;
int a[maxN];

int minInd, maxInd;
int minCnt()
{
    int i = 1;
    while(a[minInd] == a[minInd + 1])
    {
        minInd++;
        i++;
    }
    return i;
}
int maxCnt()
{
    int i = 1;
    while(a[maxInd] == a[maxInd - 1])
    {
        maxInd--;
        i++;
    }
    return i;
}

signed main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> S;
    for(int i = 0; i < N; i++) cin >> a[i];

    sort(a, a + N);
    minInd = 0;
    maxInd = N - 1;

    int minC = minCnt();
    int maxC = maxCnt();
    
    while(S > 0)
    {
        if(a[minInd] == a [maxInd]) break;
        if(minInd + 1 < (N - maxInd))
        {
            int s = S - (minInd + 1)*(a[minInd + 1] - a[minInd]);
            if(s < 0)
            {
                a[minInd] += S / (minInd + 1);

                break;
            }
            else
            {
                minInd++;
                minC = minCnt();
                //cout << "min el = " << a[minInd] << " minCnt = " <<minC << "\n";
            }
        }
        else
        {
            int s = S - (N - maxInd)*(a[maxInd] - a[minInd - 1]);
            if(s < 0)
            {
                a[maxInd] -= S / (N - maxInd);
                break;
            }
            else
            {
                maxInd--;
                //cout << "MAX el = " << a[maxInd] << "\n";
                maxC = maxCnt();
            }
        }
    }
    //cout << minInd << " " << maxInd << " " << S << "\n";
    cout << a[maxInd] - a[minInd];

    return 0;
}