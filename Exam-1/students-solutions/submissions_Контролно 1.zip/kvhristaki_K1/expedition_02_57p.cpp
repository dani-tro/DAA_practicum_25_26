#include <bits/stdc++.h>
#define int long long
using namespace std;

struct mySt
{
    int dist;
    int fuel;
    int index;
};

bool cmp1(const mySt& i, const mySt& j)
{
    if(i.dist != j.dist) return i.dist < j.dist;
    if(i.fuel != j.fuel) return i.fuel < j.fuel;
    return i.index < j.index;
}

bool cmp2(const mySt& i, const mySt& j)
{
    if(i.index != j.index) return i.index < j.index;
    return cmp1(i, j);
}

const int maxN = 1e5 + 10;
int N, M, C;
vector<mySt> a;

signed main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> M >> C;

    for(int i = 0; i < N; i++)
    {
        int A, B;
        cin >> A >> B;
        a.push_back({A, B, -1});
    }

    for(int i = 0; i < M; i++)
    {
        int A;
        cin >> A;
        a.push_back({A, numeric_limits<int>::max(), i});
    }

    sort(a.begin(), a.end(), cmp1);

    int minF = a[0].fuel;
    for(int i = 1; i < a.size(); i++)
    {
        if(a[i].index == -1)
        {
            minF = min(minF + (a[i].dist - a[i-1].dist)*C, a[i].fuel);
        }
        else
        {
            minF = minF + (a[i].dist - a[i - 1].dist)*C;
            a[i].fuel = minF;
        }
    }

    reverse(a.begin(), a.end());

    minF = a[0].fuel;
    for(int i = 1; i < a.size(); i++)
    {
        if(a[i].index == -1)
        {
            minF = min(minF + (a[i - 1].dist - a[i].dist)*C, a[i].fuel);
        }
        else
        {
            minF = minF + (a[i - 1].dist - a[i].dist)*C;
            a[i].fuel = min(minF, a[i].fuel);
        }
    }


    sort(a.begin(), a.end(), cmp2);

    for(auto s : a) if(s.index != -1) cout << s.fuel << "\n";

    return 0;
}