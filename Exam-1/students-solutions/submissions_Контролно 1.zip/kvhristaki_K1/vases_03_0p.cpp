#include <bits/stdc++.h>
#define int long long
using namespace std;

int N, H;
const int maxN = 1e7 + 6;
int a[maxN];

bool calc(int len)
{
   // cout << "calc " << len << "\n";
    int h = 0;
    int i = len;
    while(i <= N)
    {
        h+=a[i];
        i+=len;
        ///cout <<"h = " << h << " i = " << i << "\n";
    }
    if(N % len) h+=a[N + 1];
    //cout <<"fin h = " << h << "\n";
    return h <= H;
}

// 1 1 2 2 2 3

signed main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
    
    cin >> N >> H;

    for(int i = 1; i <= N; i++) cin >> a[i];

    sort(a, a + N + 1);

    int l = 1, r = N + 1, mid;

    while(l < r)
    {
        mid = (l + r) / 2;
        //cout << mid << "\n";
        if(calc(mid))
        {
            r = mid;
        }
        else
        {
            l = mid + 1;
        }
    }

    cout << l << "\n";
    //cout << "c = \n" << calc(3) << "\n";

    return 0;
}