#include <iostream>
#include <vector>
#include <algorithm>

//#include <bits/stdio++.h>
using namespace std;
typedef unsigned long long ull;
const ull MAX = 1 * 1e5;
int D[MAX];
typedef unsigned long long ull;

ull getFuel(ull n, vector<pair<ull, ull>> areas, ull m, ull c)
{
    ull bestFuel = 999999999999;
 
    for (ull i = 0; i < n; i++)
    {
        ull currFuel = areas[i].second + (areas[i].first - m) * c;
        bestFuel = min(bestFuel, currFuel);
    }

    return bestFuel;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    ull n, m, c;
    cin >> n >> m >> c;

    vector<pair<ull, ull>> areas(n);

    for (ull i = 0; i < n; i++)
    {
        cin >> areas[i].first >> areas[i].second;   //A_i & B_i
    }

    for (ull i = 0; i < m; i++)
    {
        cin >> D[i];
    }

    sort(areas.begin(), areas.end(), [](pair<ull, ull> lhs, pair<ull, ull> rhs)
        {
            return lhs.second < rhs.second;
        });

    //vector<ull> answer(m);

    for (ull i = 0; i < m; i++)
    {
        ull fuel = getFuel(n, areas, m, c);
        cout << fuel << endl;
    }

    //for (ull i = 0; i < m; i++)
    //{
    //    cout << answer[i] << endl;
    //}

   
}
