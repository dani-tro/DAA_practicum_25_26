#include <iostream>


#include <bits/stdc++.h>

using namespace std;



long long N, M,C, D[1000001], l, r,mid, c1,c2,c3;
pair<long long, long long> AB[1000001];

void solve(long long d){
    l = 0;
    r = N-1;
    while (l < r){
        mid = (l + r)/2;
        if (AB[mid].first >= d){
            l = mid + 1;
        }else{
            r = mid;
        }
    }

    c1=AB[mid].second + abs(d - AB[mid].first);
    c2=AB[mid+1].second + abs(d - AB[mid+1].first);
    c3=AB[mid-1].second + abs(d - AB[mid-1].first);
    //cout << "stop: " << AB[mid].first << ",cost: " << AB[mid].second ;
    //cout  << ", additional: " <<  abs(d - AB[mid].first)   << endl;
    cout << min(min(c1,c2),c3) << endl;

}

int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> M >> C;
    for (int i = 0; i < N ; ++i)
    {
        cin >> AB[i].first >> AB[i].second;
    }
    sort(AB, AB + N);
    for (int i = 0; i < M ; ++i)
    {
        cin >> D[i];
        solve(D[i]);
    }

    return 0;
}