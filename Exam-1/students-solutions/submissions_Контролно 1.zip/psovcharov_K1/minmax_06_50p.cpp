#include <iostream>


#include <bits/stdc++.h>

using namespace std;



long long N, S,ans = 0,sl=0,sr=0,l=0,r, i = 0,j=0, sum = 0, arr[1000000] ;


int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> S;
    for (int i = 0; i < N ; ++i)
        {
            cin >> arr[i];
        }
    sort(arr, arr + N);
    ans = arr[N-1] - arr[0];
    sr = N-1;
    sl = 0;

    while (S >= 0)
   {
        i = sl;
        j = sr;

        while (arr[sl] == arr[i]){i++;}

        while (arr[sr] == arr[j]){j--;}


        if(i <= (N-1-j)){
        S -= i;
            if(S >=0){
                arr[i-1]++;
                sl = i-1;
            }
            else {break;}
        }else{
            S -= (N-1-j);
            if(S >=0){
                    arr[j+1]--;
                    sr = j+1;

                }
            else {break;}

        }
        ans = min( (arr[j+1] - arr[i-1]), ans);

    }


    cout <<  abs(ans) << endl;
    return 0;
}


/*
 cout << "S=" << S << " i=" << i  << " j=" << j  << " sl="<< sl << " sr=" << sr<<endl;
        cout << "(i-sl)="<< (i-sl) << "  (sr-j)="<< (sr-j)<< endl;
        for (int i = 0; i < N ; ++i)
        {
            cout << arr[i] << " ";

        } cout << endl;
        cout<<" d= " << (arr[j+1] - arr[i-1]) <<endl<< endl;
  for (int i = 0; i < N ; ++i)
        {
            cout << arr[i] << " ";

        } cout << endl;  for (int i = 0; i < N ; ++i)
        {
            cout << arr[i] << " ";

        } cout << endl;
//cout << "sr" << sr;" l=" << l << " r="<< r
   /*
    for (int i = 0; i < N ; ++i)
    {
        cout << arr[i] << " ";
        sum += arr[i];
    }
        //cout << "r ="<< r<< " arr[i] =" <<arr[i] << endl;
8 5
4 2 3 2 4 3 4 3
ans> 0
sorted> 2 2 3 3 3 4 4 4
sum> 21
............
7 3
1 9 2 9 10 2 10
ans>7
sorted>1 2 2 9 9 10 10
sum> 43
............
7 15
1 9 2 9 10 2 10
sorted> 1 2 2 9 9 10 10
sum> 43
ans>3



/////////////////////
#include <iostream>


#include <bits/stdc++.h>

using namespace std;



long long N, S,ans = 0,sl=0,sr=0,l=0,r, i = 0,j=0, sum = 0, arr[1000000000000000] ;


int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
    //cout << "Hello world!" << endl;
    cin >> N >> S;
    r = N-1;
    for (int i = 0; i < N ; ++i)
        {
            cin >> arr[i];
        }
    sort(arr, arr + N);
    ans = arr[N-1] - arr[0];

    while (S >= 0)
   {
        i = 0;
        j = N-1;
        sl = 0;
        sr =0;
        while (arr[0] == arr[i]){
            sl++;
            i++;
        }

        while (arr[N-1] == arr[j]){
            sr++;
            j--;
        }
           if(sl < sr){
            S -= sl;
            if(S >=0){
                ans = min( arr[j] - arr[i], ans);
            }
            else {break;}


        }else{
            S -=sr;
            if(S >=0){
                    ans = min( arr[j] - arr[i], ans);
                }
            else {break;}

        }
        cout << "S_new= " << S <<endl;
    }

    cout <<  ans << endl;
    return 0;
}


/*
//cout << "S=" << S << " i=" << i  << " j=" << j  << " sl="<< sl << " sr=" << sr<<endl;

//cout << "sr" << sr;" l=" << l << " r="<< r
   /*
    for (int i = 0; i < N ; ++i)
    {
        cout << arr[i] << " ";
        sum += arr[i];
    }
        //cout << "r ="<< r<< " arr[i] =" <<arr[i] << endl;

8 5
4 2 3 2 4 3 4 3
ans> 0
sorted> 2 2 3 3 3 4 4 4
sum> 21
............
7 3
1 9 2 9 10 2 10
ans>7
sorted>1 2 2 9 9 10 10
sum> 43
............
7 15
1 9 2 9 10 2 10
sorted> 1 2 2 9 9 10 10
sum> 43
ans>3

*/
