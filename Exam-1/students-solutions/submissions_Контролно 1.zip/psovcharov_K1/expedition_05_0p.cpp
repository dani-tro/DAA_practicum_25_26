#include <iostream>
#include <bits/stdc++.h>
using namespace std;
long long N, M,C, D[1000001], l, r,mid, d,c, ans = LONG_MAX;
pair<long long, long long> AB[1000001];

int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> M >> C;
    for (int i = 0; i < N ; ++i)
    {
        cin >> AB[i].first >> AB[i].second;
    }
    for (int i = 0; i < M ; ++i)
    {
        cin >> d;
        ans = LONG_MAX;

        for (int i = 0; i < N ; ++i)
        {
            c = max(AB[i].first,d) - min(AB[i].first,d);
            ans = min((AB[i].second + c), ans);
        }
        D[i] = ans;

    }
    for (int i = 0; i < M ; ++i)
    { cout << D[i] << endl;}
    return 0;
}