#include <iostream>


#include <bits/stdc++.h>

using namespace std;



long long N, S,ans = 0,sl=0,sr=0,l=0,r, i = 0,j=0, sum = 0, arr[1000000] ;


int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
    //cout << "Hello world!" << endl;
    cin >> N >> S;
    for (int i = 0; i < N ; ++i)
        {
            cin >> arr[i];
        }
    sort(arr, arr + N);
    ans = arr[N-1] - arr[0];
    sr = N-1;
    sl = 0;

    while (S >= 0)
   {
        i = sl;
        j = sr;
        //sl = 0;
        //sr =0;
        while (arr[sl] == arr[i]){i++;}

        while (arr[sr] == arr[j]){j--;}
        //cout << "S=" << S << " i=" << i  << " j=" << j  << " sl="<< sl << " sr=" << sr<<endl;
        //cout << "(i-sl)="<< (i-sl) << "  (sr-j)="<< (sr-j)<< " d= " << (arr[j] - arr[i]) <<endl<< endl;

        if(i < (N-1-j)){
        S -= i;
            if(S >=0){
                ans = min( arr[j] - arr[i], ans);
                sl = i-1;
            }
            else {break;}
        }else{
            S -= (N-1-j);
            if(S >=0){
                    ans = min( arr[j] - arr[i], ans);
                    sr = j+1;
                }
            else {break;}

        }
        //cout << "S_new= " << S <<endl;
    }

    cout <<  abs(ans) << endl;
    return 0;
}

