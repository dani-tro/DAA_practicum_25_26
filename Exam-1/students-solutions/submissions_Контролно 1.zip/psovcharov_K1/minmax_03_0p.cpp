#include <iostream>


#include <bits/stdc++.h>

using namespace std;



long long N, S,ans = 0,sl=0,sr=0,l=0,r, i = 0,j=0, sum = 0, arr[1000000] ;


int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
    //cout << "Hello world!" << endl;
    cin >> N >> S;
    r = N-1;
    for (int i = 0; i < N ; ++i)
        {
            cin >> arr[i];
        }
    sort(arr, arr + N);
    ans = arr[N-1] - arr[0];
 
    while (S >= 0)
   {
        i = 0;
        j = N-1;
        sl = 0;
        sr =0;
        while (arr[0] == arr[i]){
            sl++;
            i++;
        }

        while (arr[N-1] == arr[j]){
            sr++;
            j--;
        }
           if(sl < sr){
            S -= sl;
            if(S >=0){
                ans = min( arr[j] - arr[i], ans);
            }
            else {break;}


        }else{
            S -=sr;
            if(S >=0){
                    ans = min( arr[j] - arr[i], ans);
                }
            else {break;}

        }
        cout << "S_new= " << S <<endl;
    }

    cout <<  ans << endl;
    return 0;
}