#include <iostream>
#include <bits/stdc++.h>
using namespace std;
long long N, M,C, D[1000001], l, r,mid, c1,c2,c3, ans = LONG_MAX;
pair<long long, long long> AB[1000001];



void solve(long long d){
    ans = LONG_MAX;
    for (int i = 0; i < N ; ++i)
    {
        ans = min((AB[i].second + abs(d - AB[i].first)), ans);
    }
    cout << ans <<endl;
}

int main()
{
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> N >> M >> C;
    for (int i = 0; i < N ; ++i)
    {
        cin >> AB[i].first >> AB[i].second;
    }
    //sort(AB, AB + N);
    for (int i = 0; i < M ; ++i)
    {
        cin >> D[i];
        solve(D[i]);
    }

    return 0;
}