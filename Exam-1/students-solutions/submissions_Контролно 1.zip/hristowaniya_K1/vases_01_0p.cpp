// KontrolnoDaa.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#include <vector>;
#include <algorithm>;
bool check(int W, const vector<int>& vases, int maxHeight) {
    int currHeight = vases[0];
    int currWidth = 1;
    for (int v : vases) {
        if (currWidth + 1 < W) {
            currWidth++;
        }
        else {
            if (currHeight + v > maxHeight)
                return false;
            else
                currHeight += v;
        }
    }
    return true;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, H;
    cin >> N >> H;
    vector<int> vases(N);
    int sumWidths = 0;
    for (int i = 0; i < N; i++)
    {
        cin >> vases[i];
        sumWidths++;
    }
    sort(vases.begin(), vases.end());
    int low = 0;
    int high = sumWidths;
    int ans = sumWidths;

    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (check(mid, vases, H)) {
            ans = mid;
            high = mid - 1;
        }
        else
            low = mid + 1;
    }
    cout << ans << endl;

    
    
}


