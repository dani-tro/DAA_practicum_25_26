#include <iostream>
using namespace std;
#include <vector>;
#include <algorithm>;

bool canAdd(int currWidth, int W) {
    return currWidth + 1 <= W;
}
bool check(int W, const vector<int>& vases, int maxHeight) {


    int currMaxHeight = 0;
    int baseHeight = 0;
    int currWidth = 0;
    for (int i = 0; i < vases.size(); i++)
    {

        if (canAdd(currWidth, W)) {

            if (baseHeight + vases[i] > maxHeight)
                return false;
            else {
                if ( vases[i] > + currMaxHeight) {
                    currMaxHeight = vases[i];
                }
            }
            currWidth++;
        }
        else {
            baseHeight += currMaxHeight;
            if (baseHeight + vases[i] <= maxHeight) {
                currWidth = 1;
                currMaxHeight = vases[i];
            }
            else {
                return false;
            }
        }
    }
    return true;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, H;
    cin >> N >> H;
    vector<int> vases(N);
    int sumWidths = N;
    for (int i = 0; i < N; i++)
    {
        cin >> vases[i];
    }
    
    int low = 1;
    int high = sumWidths;
    int ans = sumWidths;

    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (check(mid, vases, H)) {
            ans = mid;
            high = mid - 1;
        }
        else
            low = mid + 1;
    }
    cout << ans << endl;



}