// KontrolnoDaa.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#include <vector>;
#include <algorithm>;
bool canAdd(int currWidth, int W) {
    return currWidth + 1 <= W;
}
bool check(int W, const vector<int>& vases, int maxHeight) {

    int currHeight = vases[0];
    int baseHeight = 0;
    int currWidth = 1;
    for (int i = 1; i < vases.size(); i++)
    {
        //moga li da dobavq
        if (canAdd(currWidth, W)) {
            //ako moga pitam dali ne nadvishavam visochinata
            if (baseHeight + vases[i] > maxHeight)
                return false;
            else {
                if (baseHeight + vases[i] > baseHeight + currHeight) {
                    currHeight = vases[i];
                }
            }
            currWidth++;
        }
        else {//nov red ot shkafa - edna vaza, update na tekushta visochina i tekushtata visochina na rafta e kolkoto putvata vaza
            if (baseHeight + vases[i] <= maxHeight) {
                baseHeight += currHeight;
                currHeight = vases[i];
                currWidth = 1;
            }
            else {
                return false;
            }
        }
    }
    return true;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, H;
    cin >> N >> H;
    vector<int> vases(N);
    int sumWidths = N;
    for (int i = 0; i < N; i++)
    {
        cin >> vases[i];
    }
    sort(vases.begin(), vases.end());
    int low = 0;
    int high = sumWidths;
    int ans = sumWidths;

    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (check(mid, vases, H)) {
            ans = mid;
            high = mid - 1;
        }
        else
            low = mid + 1;
    }
    cout << ans << endl;

    
    
}


