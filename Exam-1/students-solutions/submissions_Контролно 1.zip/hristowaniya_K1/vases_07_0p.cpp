// KontrolnoDaa.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#include <vector>;
#include <algorithm>;

bool canAdd(int currWidth, int W) {
    return currWidth + 1 <= W;
}
bool isValidHeight(int baseHeight, int height, int MaxHeight) {
    return baseHeight + height <= MaxHeight;
}
bool check(int W, const vector<int>& vases, int maxHeight) {


    int currMaxHeight = vases[0];
    int baseHeight = 0;
    int currWidth = 0;
    int currMaxWidth = 0;
    for (int i = 0; i < vases.size(); i++)
    {
        if (canAdd(currWidth, W)) {
            if (!isValidHeight(baseHeight, vases[i], maxHeight))
                return false;
            else {
                if (vases[i] > currMaxHeight)
                    currMaxHeight = vases[i];
            }
            currWidth++;
            currMaxWidth = max(currWidth, currMaxWidth);
        }
        else {
            if (isValidHeight(baseHeight, currMaxHeight, maxHeight)) {
                baseHeight += currMaxHeight;
                currWidth = 0;
                currMaxHeight = vases[i];
            }
            else
                return false;
            

        }
    }
    return true;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, H;
    cin >> N >> H;
    vector<int> vases(N);
    int sumWidths = N;
    for (int i = 0; i < N; i++)
    {
        cin >> vases[i];
    }
    sort(vases.begin(), vases.end());
    int low = 1;
    int high = sumWidths;
    int ans = sumWidths;

    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (check(mid, vases, H)) {
            ans = mid;
            high = mid - 1;
        }
        else
            low = mid + 1;
    }
    cout << ans << endl;



}


