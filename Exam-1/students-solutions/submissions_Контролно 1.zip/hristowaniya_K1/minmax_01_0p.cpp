#include <iostream>
#include <vector>;
#include <algorithm>;
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, S;
    cin >> N >> S;
    vector<int> numbers(N);
    sort(numbers.begin(), numbers.end()); 
    vector<int> occurrencies;
    for (int i = 0; i < N; i++)
    {
       cin >> numbers[i];
    }
    sort(numbers.begin(), numbers.end());
    int occMax = numbers[N - 1];
    vector<int> occurencies(occMax);
    for (int i = 0; i < N; i++)
    {
        occurencies[numbers[i] -1 ]++;
    }
    for (int i = 0; i < occMax; i++)
    {
        cout << occurencies[i];
            
    }
    cout << endl;
    while (S > 0) {
        int maxNum = numbers[N - 1];
        int minNum = numbers[0];
        int maxNumOcc = occurencies[maxNum - 1];
        int minNumOcc = occurencies[minNum - 1];

        if (maxNumOcc > minNumOcc) {
            int idx = N - 1;
            while (maxNumOcc > 0) {
                numbers[idx]--;
                idx--;
                maxNumOcc--;
                S--;
            }

        }
        else {
            int idx = 0;
            while (minNumOcc > 0) {
                numbers[idx]++;
                idx++;
                minNumOcc--;
                S--;

            }
        }





    }
    

    cout << numbers[N - 1] - numbers[0];
   
}