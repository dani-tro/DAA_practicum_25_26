#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
pair<long long, long long> a[maxn];
pair<long long, long long> b[maxn];
long long res[maxn];

int n, m;
long long c;

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> c;

    for (int i = 0; i < n; i++)
    {
        long long point, fuel;
        cin >> point >> fuel;

        a[i] = {fuel, point};
        b[i] = {point, fuel};
    }

    sort(a, a + n);
    sort(b, b + n);

    for (int i = 0; i < m; i++)
    {
        long long d;
        cin >> d;

        long long total_fuel_1 = a[0].first + abs(a[0].second - d) * c;
        long long total_fuel_2 = b[0].second + abs(b[0].first - d) * c;


        res[i] = min(total_fuel_1, total_fuel_2);
    }

    for (int i = 0; i < m; i++)
    {
        cout << res[i] << "\n";
    }

}