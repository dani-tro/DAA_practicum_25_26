#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e8 + 7;
long long a[maxn];
long long n, h;

long long check(long long x)
{
    long long total_heigh = 0;

    int i = n - 1;
    while (i >= 0)
    {
        total_heigh += a[i];
        i -= x;
    }

    return total_heigh;
}

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> h;

    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    sort(a, a + n);

    long long low = 1;
    long long high = a[n - 1];
    long long ans = a[n - 1];

    while (low <= high)
    {
        long long mid = low + (high - low) / 2;

        if (check(mid) <= h)
        {
            ans = mid;
            high = mid - 1;
        }
        else
        {
            low = mid + 1;
        }
    }

    cout << ans << "\n";
}