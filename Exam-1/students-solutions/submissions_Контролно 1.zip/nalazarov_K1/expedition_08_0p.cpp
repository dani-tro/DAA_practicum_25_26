#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
pair<long long, long long> a[maxn];
long long res[maxn];

int n, m;
long long c;

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> c;

    for (int i = 0; i < n; i++)
    {
        long long point, fuel;
        cin >> point >> fuel;

        a[i] = {point, fuel};
    }


    for (int i = 0; i < m; i++)
    {
        long long d;
        cin >> d;

        long long total_fuel = a[0].second + abs(a[0].first - d) * c;

        for (int j = 1; j < n; j++)
        {
            long long temp_fuel = a[j].second + abs(a[j].first - d) * c;
            cout << "temp_fuel: " << temp_fuel << "\n";
            total_fuel = min(total_fuel, temp_fuel);
        }

        res[i] = total_fuel;
    }

    for (int i = 0; i < m; i++)
    {
        cout << res[i] << "\n";
    }

}