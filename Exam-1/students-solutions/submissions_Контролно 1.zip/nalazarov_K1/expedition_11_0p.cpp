#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
long long res[maxn];

int n, m;
long long c;

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> c;
    priority_queue<pair<long long, long long>, std::vector<pair<long long, long long>>, std::greater<pair<long long, long long>> > pq;

    for (int i = 0; i < n; i++)
    {
        long long point, fuel;
        cin >> point >> fuel;
        pq.push({fuel, point});
    }

    for (int i = 0; i < m; i++)
    {
        long long d;
        cin >> d;

        res[i] = pq.top().first + abs(pq.top().second - d) * c;
        pq.pop();
    }

    for (int i = 0; i < m; i++)
    {
        cout << res[i] << "\n";
    }

}