#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
pair<long long, long long> a[maxn];
pair<long long, long long> b[maxn];
long long res[maxn];

int n, m;
long long c;

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> c;

    for (int i = 0; i < n; i++)
    {
        long long point, fuel;
        cin >> point >> fuel;

        a[i] = {fuel, point};
        b[i] = {point, fuel};
    }

    sort(a, a + n);
    sort(b, b + n);

    // for (int i = 0; i < n; i++)
    // {
    //     cout << "point: " << a[i].second << " fuel: " << a[i].first << "\n";
    // }
    // cout << "\n";
    // for (int i = 0; i < n; i++)
    // {
    //     cout << "point: " << b[i].first << " fuel: " << b[i].second << "\n";
    // }

    

    for (int i = 0; i < m; i++)
    {
        long long d;
        cin >> d;

        long long total_fuel_min = 1e9 + 7;
        long long total_fuel_1;
        long long total_fuel_2;
        for (int j = 0; j < n; j++)
        {
            total_fuel_1 = a[j].first + abs(a[j].second - d) * c;
            total_fuel_2 = b[j].second + abs(b[j].first - d) * c;
            total_fuel_min = min(total_fuel_min, min(total_fuel_1, total_fuel_2));
        }
        res[i] = total_fuel_min;
    }

    for (int i = 0; i < m; i++)
    {
        cout << res[i] << "\n";
    }

}