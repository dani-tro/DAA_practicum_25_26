#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
long long a[maxn];

int n;
long long s;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> s;

    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    sort(a, a + n);
    long long max_delta;

    while (s > 0)
    {
        if (s % 2 == 1)
        {
            a[n - 1]--;
        }
        else 
        {
            a[0]++;
        }

        sort(a, a + n);
        s--;
    }

    for (int i = 0; i < n; i++)
    {
        cout << a[i] << " ";
    }

    cout << "\n";

    max_delta = a[n - 1] - a[0];
    cout << max_delta << "\n";
}