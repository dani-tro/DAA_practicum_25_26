#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
pair<long long, long long> a[maxn];
long long res[maxn];

int n, m;
long long c;

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> c;

    for (int i = 0; i < n; i++)
    {
        long long point, fuel;
        cin >> point >> fuel;

        a[i] = {fuel, point};
    }

    sort(a, a + n);

    for (int i = 0; i < m; i++)
    {
        long long d;
        cin >> d;

        long long total_fuel = a[i].first + abs(a[i].second - d) * c;

        for (int j = 0; j < n; j++)
 {
            long long temp_fuel = 
                   total_fuel = min(total_fuel, temp_fuel);
        }

        res[i] = total_fuel;
    }

    for (int i = 0; i < m; i++)
    {
        cout << res[i] << "\n";
    }

}