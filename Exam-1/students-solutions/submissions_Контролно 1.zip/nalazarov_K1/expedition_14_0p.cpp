#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
long long res[maxn];

int n, m;
long long c;

int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> n >> m >> c;
    priority_queue<pair<long long, long long>, std::vector<pair<long long, long long>>, std::greater<pair<long long, long long>> > pqFuel;
    priority_queue<pair<long long, long long>, std::vector<pair<long long, long long>>, std::greater<pair<long long, long long>> > pqPoint;

    for (int i = 0; i < n; i++)
    {
        long long point, fuel;
        cin >> point >> fuel;
        pqFuel.push({fuel, point});
        pqPoint.push({point, fuel});
    }

    for (int i = 0; i < m; i++)
    {
        long long d;
        cin >> d;
        res[i] = min(pqFuel.top().first + abs(pqFuel.top().second - d) * c, pqPoint.top().second + abs(pqPoint.top().first - d) * c);
        if(pqFuel.top().first + abs(pqFuel.top().second - d) * c > pqPoint.top().second + abs(pqPoint.top().first - d) * c)
        {
            pqFuel.pop();
        }
        else
        {
            pqPoint.pop();
        }
    }

    for (int i = 0; i < m; i++)
    {
        cout << res[i] << "\n";
    }

}