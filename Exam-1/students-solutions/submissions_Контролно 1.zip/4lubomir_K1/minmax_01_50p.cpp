// minmax.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#define ull unsigned long long
unsigned A[1000000];
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	unsigned long long N, S;
	cin >> N >> S;
	unsigned long long reader, maxRead=0;
	for (unsigned i = 0; i < N; i++)
	{
		cin >> reader;
		if (reader > maxRead) maxRead = reader;
		A[reader]++;
	}
	/*
	for (ull i = 1; i <= maxRead; i++)
	{
		cout << A[i] << " ";
	}*/
	
	ull l = 0, r = maxRead;
	while (l < r && S>0)
	{
		if (A[l] <= A[r])
		{
			//cout << S;
			if (S >= A[l]) S -= A[l]; //safe minus
			else break;
			A[l + 1] += A[l];
			A[l] = 0;
			l++;
			//cout <<"  "<<S << "AAAAA";
		}
		else
		{
			if (S >= A[r]) S -= A[r]; //safe minus
			else break;
			A[r - 1] += A[r];
			A[r] = 0;
			if (r >= 1) r--;
			else break;
		}
		/*
		for (ull i = 1; i <= maxRead; i++)
		{
			cout << A[i] << " ";
		}
		cout << endl;
		*/
	}
	cout << r - l;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file

