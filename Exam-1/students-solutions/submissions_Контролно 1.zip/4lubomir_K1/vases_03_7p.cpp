// vases.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <algorithm>
//#include <bits/stdc++.h>
using namespace std;

unsigned A[10000003];
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	unsigned long long N, H;
	cin >> N >> H;
	for (unsigned i = 0; i < N; i++)
	{
		cin >> A[i];
	}

	long long l = 0, r = N - 1;
	unsigned long long currSum = 0;
	unsigned long long minimalWidth = 1;
	
	sort(A, A+N);
	/*sort_heap(A, A)
	for (unsigned i = 0; i < N; i++)
	{
		cout << A[i];
	}*/
	while (l <= r)
	{
		//cout << l << " " << r << " " << currSum << " " << minimalWidth << endl;
		if (currSum + A[r] <= H)
		{
			currSum += A[r];
			r--;
		}
		else 
		{
			if (currSum + A[l] <= H)
			{
				currSum += A[l];
				l++;
			}
			else
			{
				minimalWidth++;
				currSum = 0;
			}
		}
	}
	cout<< minimalWidth;
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
