#include <bits/stdc++.h>
using namespace std;
const long long MAXN = 1e5;

long long arr[MAXN];
struct str{
    long long value;
    long long coun;

};
str num[MAXN];
long long n, s, m;


int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin >> n >> s;
    long long i;
    for (long long i = 0; i < n; i++){
        cin >> arr[i];
    }
    sort(arr, arr+n);
    m = 0;
    long long curr = arr[0], coun = 1;
    for (long long i = 1; i < n; i++){
        if (arr[i-1] != arr[i]){
            num[m] = {curr, coun};
            coun = 0;
            curr = arr[i];
            m++;
        }
        coun ++;
    }

    num[m] = {curr, coun};
    m++;


    long long l = 0, r = m - 1;
    for (; l < r; ){
        //cout << s << ": " << num[l].value <<  ' ' << num[l].coun  << ' '<< num[r].value <<  ' ' << num[r].coun << endl;
        if (num[l].coun < num[r].coun || (num[l].coun == num[r].coun && num[l+1].value - num[l].value > num[r].value - num[r-1].value)){
            long long maxC = s / (num[l+1].value - num[l].value);
            if (maxC >= num[l].coun){
                s-= (num[l+1].value - num[l].value) * num[l].coun;
                num[l+1].coun += num[l].coun;
                l++;
            }
            else{
                cout << num[r].value - num[l].value - (s / num[l].coun) << endl;
                return 0;
            }
        }
        else{
            long long maxC =  s / (num[r].value - num[r-1].value);
            if (maxC >= num[r].coun){
                s-= (num[r].value - num[r-1].value) * num[r].coun;
                num[r-1].coun += num[r].coun;
                r--;
            }
            else{
                cout << num[r].value - num[l].value - (s / num[r].coun) << endl;
                return 0;
            }
        }





    }
    cout << 0 << endl;
return 0;
}
