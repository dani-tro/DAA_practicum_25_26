#include <bits/stdc++.h>
using namespace std;
const long long MAXN = 1e7;

long long arr[MAXN];
long long n, s;
long long a1, a2, x, y, z, m;


int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin >> n >> s;
    long long i, j, k;
    cin >> a1 >> a2 >> x >> y >> z >> m;

