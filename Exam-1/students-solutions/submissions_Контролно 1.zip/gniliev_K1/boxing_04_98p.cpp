#include <bits/stdc++.h>
using namespace std;
const long long MAXN = 1e7;

long long arr[MAXN];
long long n, s;
long long a1, a2, x, y, z, m;


int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin >> n >> s;
    long long i, j, k;
    cin >> a1 >> a2 >> x >> y >> z >> m;
    arr[0]=a1;
    arr[1]=a2;
    for (i = 2; i < n; i++){
        arr[i] = (arr[i-2]*x + arr[i-1]*y + z)%m;
    }
    for (i = 0; i < n; i++){
     //   cout << arr[i] << " ";
    }
    //cout << endl;
    long long end1=0, start2=0, end2 = 0, sum1 = 0, sum2 = 0, minL = n;
    bool t = false;
    for (i = 0; i<n-1; i++){
        if (i!=0)sum1-=arr[i-1];

        for (j = end1; sum1 < s && j<n-1; j++){
            sum1+=arr[j];
            sum2-=arr[j];
        }
        if (j==n-1)break;
        end1 = j;
        if (end2 < j){sum2 = 0; end2 = j;}
        start2 = j;
        for (k = end2; sum2 < s && k < n; k++){
            sum2+=arr[k];

        }
       // cout << "sum1: " << sum1 << ", sum2: " << sum2 << endl;
        end2 = k;
       // cout << i << " " << end1 << ' ' << start2 << " " << end2 <<  endl;
        if (sum2 >= s){
            if (minL > k - i){
              //  cout << "change: " << k - i << endl;
            }
            minL = min(minL, k - i );
            t = true;
        }
        //cout << endl;
    }
    if (t){
        cout << minL << endl;
    }
    else {
        cout << -1 << endl;
    }

return 0;
}

