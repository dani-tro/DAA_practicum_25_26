#include <bits/stdc++.h>
using namespace std;
const long long MAXN = 1e7;

long long arr[MAXN];
long long n, h;

bool check(long long width){
    int i, left = h, coun = width;
    for ( i = n-1; i>=0; i--){
        if (coun == width){
            left -= arr[i];
            coun = 0;
        }
        coun ++;
        if (left<0)break;
    }

    return i == -1;
}

int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin >> n >> h;
    long long i;
    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }
    sort(arr, arr+n);
    long long l = 1, r = n;
    while (l < r){
        long long mid = (l + r)/2;
        if (check(mid)){
            r = mid;
        }
        else {
            l = mid+1;
        }
    }
    cout << r << endl;
return 0;
}
