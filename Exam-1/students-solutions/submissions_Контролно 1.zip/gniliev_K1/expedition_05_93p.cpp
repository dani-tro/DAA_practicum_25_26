#include <bits/stdc++.h>
using namespace std;
const long long MAXN = 1e5;
const long long maxD = 1e9;

long long n, m, c;
long long siz = 1;
struct str{
    long long left;
    long long right;
    long long pos;
    long long cost;
};
str dist[MAXN];
long long stations[MAXN];
struct helli{
    long long pos;
    long long cost;
    bool operator <(const helli& other){
        return pos < other.pos || (pos == other.pos && cost < other.cost);
    }
};
helli heli[MAXN];
long long mod(long long x){
    if (x< 0)x = -x;
    return x;
}


long long fin(long long v){
    long long l = 0, r = siz, mid;
    while (l < r - 1){
        mid = (l + r)/2;
        //cout << mid << ": " << dist[mid].left << endl;
        if (dist[mid].left > v){
            r =  mid;
        }
        else {
            l = mid;
        }
    }
    return l;
}
int main (){
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
    cin >> n >> m >> c;

    long long i;
    for (i = 0; i < n; i++){
        cin >> heli[i].pos >> heli[i].cost;
    }
    for (i = 0; i < m; i++){
        cin >> stations[i];
    }
    sort(heli, heli+n);

    dist[0].left = 0;
    dist[0].right = maxD;
    dist[0].pos = heli[0].pos;
    dist[0].cost = heli[0].cost;

    for (i = 1; i < n; i++){
        while (siz > 0 && dist[siz - 1].cost - heli[i].cost - (heli[i].pos - dist[siz - 1].pos) * c > 0){
            siz--;
        }
        if (siz == 0){
            dist[0].left = 0;
            dist[0].right = maxD;
            dist[0].pos = heli[i].pos;
            dist[0].cost = heli[i].cost;
            siz++;
        }
        else{
            if (!( heli[i].cost - dist[siz - 1].cost - (heli[i].pos - dist[siz - 1].pos) * c > 0)){
                if (heli[i].cost > dist[siz - 1].cost){
                    long long temp = (heli[i].cost - dist[siz - 1].cost) / c;
                    long long pos = dist[siz - 1].pos + temp;

                    dist[siz].right = maxD;
                    dist[siz].pos = heli[i].pos;
                    dist[siz].cost = heli[i].cost;
                    if ((heli[i].pos - pos) % 2 == 0){
                        long long tp = (heli[i].pos - pos)/2;
                        dist[siz - 1].right = pos + tp;
                        dist[siz].left = heli[i].pos - tp + 1;
                    }
                    else{
                        long long tp = (heli[i].pos - pos)/2;
                        dist[siz - 1].right = pos + tp;
                        dist[siz].left = heli[i].pos - tp;
                    }
                    siz++;
                }
                else{
                    long long temp = (dist[siz - 1].cost - heli[i].cost) / c;
                    long long pos = heli[i].pos - temp;

                    dist[siz].right = maxD;
                    dist[siz].pos = heli[i].pos;
                    dist[siz].cost = heli[i].cost;
                    if ((pos - dist[siz - 1].pos) % 2 == 0){
                        long long tp = (pos - dist[siz - 1].pos)/2;
                        dist[siz - 1].right = dist[siz - 1].pos + tp - 1;
                        dist[siz].left = pos - tp - 1;
                    }
                    else{
                        long long tp = (pos - dist[siz - 1].pos)/2;
                        dist[siz - 1].right = dist[siz - 1].pos + tp;
                        dist[siz].left = pos - tp;
                    }
                    siz++;
                }
            }
        }
    }
  /*  for (int i = 0; i < siz; i++){

        cout << dist[i].left << ' ' << dist[i].right << endl;
    }*/
    for (int i =0; i <m; i++){
        long long pos = fin(stations[i]);
      //  cout << pos <<  endl;
        cout << dist[pos].cost + mod(dist[pos].pos - stations[i]) * c << endl;
    }
return 0;
}

