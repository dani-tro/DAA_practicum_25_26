#include <bits/stdc++.h>
#define int long long
using namespace std;

#define INF (1ll<<60)

void sol() {
	int n; cin >> n;
	int m; cin >> m;
	int c; cin >> c;
	
	vector<array<int, 2>> a(n); for (auto &[x, w]: a) cin >> x >> w;
	
	sort(a.begin(), a.end());
	
	vector<array<int, 2>> a_good;
	for (auto [x, w]: a) {
		while (!a_good.empty()) {
			auto [x1, w1] = a_good.back();
			int dx = x - x1;
			if (dx*c + w1 < w) goto next;
			if (dx*c + w < w1) {
				a_good.pop_back();
				continue;
			}
			break;
		}
		a_good.push_back({x, w});
		next:;
	}
		
	for (int i = 0; i < m; i += 1) {
		int x; cin >> x;
		
		int l = -1;
		int r = a_good.size();
		while (l + 1 < r) {
			int m = (l+r)/2;
			if (x < a_good[m][0]) r = m;
			else                  l = m;
		}
		
		int best = INF;
		if (l != -1)            best = min(best, a_good[l][1] + c*(x - a_good[l][0]));
		if (r != a_good.size()) best = min(best, a_good[r][1] + c*(a_good[r][0] - x));
		cout << best << "\n" << flush;
	}
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
}