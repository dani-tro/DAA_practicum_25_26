#include <bits/stdc++.h>
#define int long long
using namespace std;

#define INF (1ll<<60)

void sol() {
	int n; cin >> n;
	int k; cin >> k;
	
	vector<int> a(min((int)2, n));
	cin >> a[0];
	cin >> a[1];
	int x; cin >> x;
	int y; cin >> y;
	int z; cin >> z;
	int mod; cin >> mod;
	for (int i = 2; i < n; i += 1) a[i] = (x*a[i-2] + y*a[i-1] + z) % mod;
	
	int pfx = 0;
	int sfx = 0;
	int l = 0;
	int m = 0;
	int ans = n+1;
	for (int r = 1; r <= n; r += 1) {
		sfx += a[r-1];
		while (sfx-a[m] >= k) {
			sfx -= a[m];
			pfx += a[m];
			m += 1;
		}
		while (pfx-a[l] >= k) {
			pfx -= a[l];
			l += 1;
		}
		if (pfx >= k && sfx >= k) ans = min(ans, r-l);
	}
	
	if (ans == n+1) ans = -1;
	cout << ans << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
}