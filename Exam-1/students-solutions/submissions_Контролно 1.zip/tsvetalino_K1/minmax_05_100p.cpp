#include <bits/stdc++.h>
#define int long long
using namespace std;

#define INF (1ll<<60)

void sol() {
	int n; cin >> n;
	int s; cin >> s;
	vector<int> a(n); for (auto &x: a) cin >> x;
	sort(a.begin(), a.end());

	vector<int> mn(n);
	vector<int> mx(n);
	
	mn[0] = 0;
	for (int i = 1; i < n; i += 1) mn[i] = mn[i-1] + i * (a[i] - a[i-1]);
	
	mx[n-1] = 0;
	for (int i = n-2; i >= 0; i -= 1) mx[i] = mx[i+1] + (n-i-1) * (a[i+1] - a[i]);
		
	int ans = INF;
	
	for (int i = 0; i < n && mn[i] <= s; i += 1) {
		int l = i-1;
		int r = n;
		while (l + 1 < r) {
			int m = (l+r)/2;
			if (mn[i] + mx[m] <= s) r = m;
			else                    l = m;
		}
		
		if (i == r) {
			cout << "0\n";
			return;
		}
		
		int cost = n-r;
		int space = a[r] - a[r-1];
		
		int delta = min(space, (s - mn[i] - mx[r])/cost);

		ans = min(ans, a[r] - a[i] - delta);
	}
	
	for (int i = n-1; i >= 0 && mx[i] <= s; i -= 1) {
		int l = 0;
		int r = i+1;
		while (l + 1 < r) {
			int m = (l+r)/2;
			if (mx[i] + mn[m] <= s) l = m;
			else                    r = m;
		}
		
		if (i == l) {
			cout << "0\n";
			return;
		}
		
		int cost = l+1;
		int space = a[l+1] - a[l];
		
		int delta = min(space, (s - mn[l] - mx[i])/cost);

		ans = min(ans, a[i] - a[l] - delta);
	}
	
	assert(ans >= 0);
	
	cout << ans << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
	return 0;
}