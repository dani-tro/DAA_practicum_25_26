#include <bits/stdc++.h>
#define int long long
using namespace std;

#define INF (1ll<<60)

void sol() {
	int n; cin >> n;
	int s; cin >> s;
	vector<int> a(n); for (auto &x: a) cin >> x;
	sort(a.begin(), a.end());

	int ans = a.back() - a.front();

	for (int mn = a.front(); mn <= a.back(); mn += 1) {
		for (int mx = a.front(); mx <= a.back(); mx += 1) {
			int t = 0;
			for (auto x: a) {
				if (x < mn) t += mn - x;
				if (mx < x) t += x - mx;
			}
			if (t <= s) ans = min(ans, mx - mn);
		}
	}
	
	cout << ans << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
	return 0;
}