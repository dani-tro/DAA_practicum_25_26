#include <bits/stdc++.h>
#define int long long
using namespace std;

#define INF (1ll<<60)

void sol() {
	int n; cin >> n;
	int s; cin >> s;
	vector<int> a(n); for (auto &x: a) cin >> x;
	sort(a.begin(), a.end());

	vector<int> mn(n);
	vector<int> mx(n);
	
	mn[0] = 0;
	for (int i = 1; i < n; i += 1) mn[i] = mn[i-1] + i * (a[i] - a[i-1]);
	
	mx[n-1] = 0;
	for (int i = n-2; i >= 0; i -= 1) mx[i] = mx[i+1] + (n-i-1) * (a[i+1] - a[i]);
		
	int ans = INF;
	
	for (int i = 0; i < n && mn[i] <= s; i += 1) {
		int l = i-1;
		int r = n;
		while (l + 1 < r) {
			int m = (l+r)/2;
			if (mn[i] + mx[m] <= s) r = m;
			else                    l = m;
		}
		
		if (i == r) {
			cout << "0\n";
			return;
		}
		
		int t = s - mn[i] - mx[r];
		
		array<int, 2> bonus1 = {i+1, a[i+1] - a[i]};
		array<int, 2> bonus2 = {n-r, a[r] - a[r-1]};
		
		if (bonus1[0] > bonus2[0]) swap(bonus1, bonus2);
		
		int diff = a[r] - a[i];
		
		{
			int delta = min(bonus1[1], t/bonus1[0]);
			diff -= delta;
			t -= delta * bonus1[0];
		}
		if (r != i+1) {
			int delta = min(bonus2[1], t/bonus2[0]);
			diff -= delta;
			t -= delta * bonus2[0];
		}
		ans = min(ans, diff);
	}
	
	assert(ans >= 0);
	
	cout << ans << "\n";
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
	return 0;
}