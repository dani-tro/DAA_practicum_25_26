#include <bits/stdc++.h>
#define int long long
using namespace std;

#define INF (1ll<<60)

void sol() {
	int n; cin >> n;
	int h; cin >> h;
	vector<int> a(n); for (auto &x: a) cin >> x;
	sort(a.begin(), a.end(), [&](int x, int y){return x > y;});
	
	int r = n+1;
	int l = 0;
	for (int m = 1;; m += 1) {
		int curr = 0;
		for (int i = 0; i < n; i += m) curr += a[i];
		if (curr > h) continue;
		cout << m << "\n";
		break;
	}
}

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	sol();
	return 0;
}