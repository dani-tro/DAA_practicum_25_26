#include <bits/stdc++.h>
using namespace std;

// bool canAchieve(vector<int> red, int mid, int N, long long S){

    
// }

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int N;
    long long S;

    cin >> N >> S;

    vector<int> reditsa;

    for(int i = 0; i < N; ++i){
        int r;
        cin >> r;
        reditsa.push_back(r);
    }

    sort(reditsa.begin(), reditsa.end());

    // int l = 0;
    // int r = reditsa[N-1] - reditsa[0];
    // int ans = 1e9+4;

    // while(l <= r){
    //     int mid = (l+r)/2;

    //     if(canAchieve(reditsa, mid, S, N)){
    //         ans = mid;
    //         r = mid - 1;
    //     }
    //     else l = mid + 1;
    // }

    int ans = reditsa[N-1] - reditsa[0];
    while(ans > 0 && S > 0){
        if(ans == 1){
            if(reditsa[0] != reditsa[1]) reditsa[0] += 1;
            else reditsa[N-1] -= 1;
            S-=1;
        }
        else {
        reditsa[0] += 1;
        reditsa[N-1] -= 1;
        S -= 2;
        }
        sort(reditsa.begin(), reditsa.end());
        ans = reditsa[N-1] - reditsa[0];

        for(auto& el : reditsa) cout << el << " ";
        cout << endl;
    }

    cout << ans;

    return 0;
}