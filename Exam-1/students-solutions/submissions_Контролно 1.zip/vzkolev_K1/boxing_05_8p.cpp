#include <bits/stdc++.h>
using namespace std;

long long summer(vector<long long>& kr, int l, int r){
    long long sum = 0;
    for(int i = l; i <= r; ++i){
        sum += kr[i];
    }
    return sum;
}

int canSatisfy(vector<long long>& kr, int l, int r, long long K, int N){
    if(l >= r) return -1;
    int mid = 1LL * (l+r) / 2;

    long long s1 = summer(kr, l, mid);
    long long s2 = summer(kr, mid + 1, r);
    if(s1 > K && s2 > K) return r-l+1;
    else return min(canSatisfy(kr, l, mid, K, N), canSatisfy(kr, mid+1, r, K, N));
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int N;
    long long K;


    cin >> N;
    cin >> K;

    vector<long long> krushi;
    
    int a1, a2, X, Y, Z, M;
    cin >> a1 >> a2 >> X >> Y >> Z >> M;

    krushi.push_back(a1);
    krushi.push_back(a2);
    for(int i = 3; i <= N; ++i){
        long long ai = (1LL * krushi[i-3] * X + krushi[i-2] * Y + Z) % M;
        krushi.push_back(ai);
    }

    // int ans = -1;

    // int pot = canSatisfy(krushi, 0, N-1, K, N);
    // if(pot != -1){
    //     ans = pot;
    // }
    
    // cout << ans;
    

    int min = 1e9+5;
    for(int i = 0; i < N; ++i){
        for(int j = i; j < N; ++j){
            for(int p = i; p <= j; ++p){
                long long s1 = 0;
                long long s2 = 0;
                for(int q = i; q <= j; ++q){
                    if(q <= p) s1 += krushi[q];
                    else s2 += krushi[q];
                }
                if(s1 > K && s2 > K){
                    if(min > j-i+1) {
                        min = j-i+1;
                    }
                    break;
                }
            }
        }
    }

    if(min == 1e9+5) cout << -1;
    else cout << min;


    return 0;
}