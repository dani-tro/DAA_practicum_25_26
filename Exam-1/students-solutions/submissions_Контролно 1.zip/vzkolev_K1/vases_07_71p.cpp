#include <bits/stdc++.h>
using namespace std;

bool doesFit(std::vector<int> As, long long k, int H, int N){
    long long S = 0;

    for(long long i = 0; i < N; i=i+k){
        S+=As[i];
    }

    return S <= H;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int N, H;

    cin >> N >> H;
    vector<int> As;

    for(int i = 1; i <= N; ++i){
        int A;
        cin >> A;
        As.push_back(A);
    }

    sort(As.begin(), As.end(), [](int a, int b) {return a > b;});

    int l = 1;
    int r = N;
    int ans = 1e9+5;

    while(l <= r){
        long long mid = 1LL * (l+r)/2;

        if(doesFit(As, mid, H, N)){
            ans = mid;
            r = mid - 1;
        }
        else l = mid + 1;
    }

    cout << ans;

    return 0;
}