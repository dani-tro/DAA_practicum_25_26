#include <bits/stdc++.h>
using namespace std;

bool doesFit(std::vector<long long>& As, long long k, long long H, long long N){
    long long S = 0;

    for(long long i = 0; i < N; i=i+k){
        S+=As[i];
    }

    return S <= H;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    long long N, H;

    cin >> N >> H;
    vector<long long> As;

    for(long long i = 1; i <= N; ++i){
        long long A;
        cin >> A;
        As.push_back(A);
    }

    sort(As.begin(), As.end(), [](long long a, long long b) {return a > b;});

    long long l = 1;
    long long r = N;
    long long ans = 1e9+5;

    while(l < r){
        long long mid = (l+r)/2;

        if(doesFit(As, mid, H, N)){
            ans = mid;
            r = mid - 1;
        }
        else l = mid + 1;
    }

    cout << ans;

    return 0;
}