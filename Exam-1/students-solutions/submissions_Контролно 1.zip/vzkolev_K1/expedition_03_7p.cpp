#include <bits/stdc++.h>
using namespace std;


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    long long N, M, C;

    cin >> N >> M >> C;

    vector<pair<long long, long long>> vec;

    for(long long i = 1; i <= N; ++i){
        long long A, B;
        cin >> A >> B;
        vec.push_back({A,B});
    }

    vector<long long> Ds;

    for(long long i = 0; i < M; ++i){
        long long D;
        cin >> D;
        Ds.push_back(D);
    }

    // sort(vec.begin(), vec.end(), [](pair<long long, long long> a, pair<long long, long long> b){
    //     if(a.second != b.second) return a.second < b.second;
    //     return a.first < b.first;
    // });

    for(auto& el : Ds){
        long long min = 1e9+5;

        for(long long i = 0; i < N; ++i){
            long long curMin = vec[i].second + abs(el - vec[i].first)*C;
            if(curMin < min) min = curMin;
        }
        cout << min << endl;
    }

    return 0;
}