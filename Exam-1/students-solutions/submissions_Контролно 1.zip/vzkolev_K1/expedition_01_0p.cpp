#include <bits/stdc++.h>
using namespace std;


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int N, M, C;

    cin >> N >> M >> C;

    vector<pair<int, int>> vec;

    for(int i = 1; i <= N; ++i){
        int A, B;
        cin >> A >> B;
        vec.push_back({A,B});
    }

    vector<int> Ds;

    for(int i = 0; i < M; ++i){
        int D;
        cin >> D;
        Ds.push_back(D);
    }

    sort(vec.begin(), vec.end(), [](pair<int, int> a, pair<int, int> b){
        if(a.second != b.second) return a.second < b.second;
        return a.first < b.first;
    });

    for(auto& el : Ds){
        long long min = 1e18+5;

        for(int i = 0; i < N; ++i){
            long long curMin = vec[i].second + abs(el - vec[i].first)*C;
            if(curMin < min) min = curMin;
        }
        cout << min << endl;
    }

    return 0;
}