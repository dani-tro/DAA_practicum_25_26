#include <iostream>
#include <algorithm>
using namespace std;
#define endl '\n'
#define int long long

int const maxn = 1e5 + 5;
int a[maxn];
pair<int, int> c[maxn];

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n, s;
	cin >> n >> s;
	for (int i = 0; i < n; i++) {
		cin >> a[i];
	}

	sort(a, a + n);

	int minmax = a[n - 1] - a[0];
	int cs = 0, b = 1;

	for (int i = 1; i <= n; i++) {
		if (a[i] != a[i - 1]) {
			c[cs++] = { a[i - 1], b };
			b = 0;
		}
		b++;
	}

	int l = 0;
	int r = cs - 1;
	while (l < r && s > 0) {
		if (c[l].second < c[r].second) {
			int cnt = c[l].second;
			int d = c[l + 1].first - c[l].first;
			if (s < cnt * d) {
				d = s / cnt;
			}
			s -= cnt * d;

			c[l + 1].second += c[l].second;
			minmax -= d;
			l++;
		}
		else {
			int cnt = c[r].second;
			int d = c[r].first - c[r - 1].first;
			if (s < cnt * d) {
				d = s / cnt;
			}
			s -= cnt * d;

			c[r - 1].second += c[r].second;
			minmax -= d;

			r--;
		}
	}
	cout << minmax << endl;

}

