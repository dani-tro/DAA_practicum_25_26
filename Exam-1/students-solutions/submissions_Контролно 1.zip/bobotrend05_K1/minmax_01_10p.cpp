#include <iostream>
#include <algorithm>
using namespace std;
#define endl '\n'
#define int long long

int const maxn = 1e5 + 5;
int a[maxn];
int dav[maxn];
pair<int, int> offsets[maxn];

bool rev(int a, int b) {
	return a > b;
}

bool revpair(pair<int, int> a, pair<int, int> b) {
	return a.first > b.first;
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n, s;
	cin >> n >> s;
	int sum = 0;
	for (int i = 0; i < n; i++) {
		cin >> a[i];
		sum += a[i];
	}

	sort(a, a + n, rev);
	int avg = sum / n;
	for (int i = 0; i < n; i++) {
		dav[i] = a[i] - avg;
	}
	sort(dav, dav + n, rev);

	offsets[0] = { dav[0], 1 };
	int count = 1;
	for (int i = 1; i < n; i++) {
		if (dav[i] == offsets[count - 1].first) {
			offsets[count - 1].second++;
		}
		else {
			offsets[count] = { dav[i], 1 };
			count++;
		}
	}
	
	int l = 0, r = count-1;
	while (s > 0 && l<=r) {
		if (l <= r && offsets[l].second == 0) {
			l++;
		}
		if (l <= r && offsets[r].second == 0) {
			r--;
		}
		if (s > 0 && offsets[l].second > 0 && abs(offsets[l].first) >= abs(offsets[r].first)) {
			offsets[l].second--;
			s--;
		}
		if (s > 0 && offsets[r].second > 0 && abs(offsets[l].first) < abs(offsets[r].first)) {
			offsets[r].second--;
			s--;
		}
	}

	int biggestId = 0;
	int smallestId = count - 1;
	while (offsets[biggestId].second == 0 && biggestId < count) {
		biggestId++;
	}
	while (offsets[smallestId].second == 0 && smallestId >= 0) {
		smallestId--;
	}


	cout << offsets[biggestId].first - offsets[smallestId].first << endl;


}

