#include <iostream>
#include <algorithm>
using namespace std;
#define endl '\n'
#define int long long

int const maxn = 1e7 + 5;

int a[maxn];

bool rev(int a, int b) {
	return a > b;
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int n, h;
	cin >> n >> h;
	//int high = 0;
	for (int i = 0; i < n; i++) {
		cin >> a[i];
		//high += a[i];
	}

	sort(a, a + n, rev);

	int low = 1; int high = n;
	while (low < high) {
		int mid = low + (high - low) / 2;

		int w = 1;
		int curh = a[0];
		int i = 1;
		while (i < n) {
			
			if (w + 1 <= mid) {
				w++;
			}
			else{
				curh += a[i];
				w = 1;
			}
			i++;
		}
		if (curh <= h) high = mid-1;
		else low = mid + 1;
	}

	cout << low << endl;

}



