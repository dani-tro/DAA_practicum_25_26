#include <bits/stdc++.h>

using namespace std;

const long long maxn = 1e7;
long long n, h;
long long arr[maxn];

bool p(int width)
{
    int raft = 0;
    int totalH = 0;
    for (int i = n - 1; i >= 0; --i)
    {
        if (raft >= width) raft = 0;
        if (raft == 0)
            totalH += arr[i];
        raft++;
    }
    return totalH <= h;
}

int bs(int l, int r)
{
    if (l >= r) return l;
    int mid = (l + r) / 2;
    if (p(mid)) return bs(l, mid);
    return bs(mid + 1, r);
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin >> n >> h;
    for (int i = 0; i < n; ++i)
    {
        cin >> arr[i];
    }
    sort(arr, arr + n);
    cout << bs(1, n) << '\n';

    return 0;
}