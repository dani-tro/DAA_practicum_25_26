#include <bits/stdc++.h>

using namespace std;

long long k;
long long n;
const long long maxn = 1e7;
long long prefix[maxn + 1];

bool bs2(long long l, long long r)
{
    if (l >= r) return false;
    long long mid = (l + r) / 2;
    // cout << "mid: " << mid << '\n';
    // cout << prefix[mid] << ' ' << prefix[l] << ' ' << prefix[r] << '\n';
    if (prefix[mid] - prefix[l] >= k && prefix[r] - prefix[mid] >= k) return true;
    if (prefix[mid] - prefix[l] >= k) return bs2(l, mid - 1);
    return bs2(mid + 1, r);
}

bool p(long long len)
{
    long long l = 0;
    long long r = len;
    while (r <= n)
    {
        // cout << "bs2 for " << l << ' ' << r << '\n';
        if (bs2(l++, r++)) return 1;
    }
    return 0;
}

long long bs(long long l, long long r)
{
    if (l >= r) return p(l) ? l : -1;
    long long mid = (l + r) / 2;
    if (p(mid)) return bs(l, mid);
    return bs(mid + 1, r);
}


int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;
    cin >> k;
    
    long long arr[n];
    cin >> arr[0];
    cin >> arr[1];
    long long x, y, z, m;
    cin >> x >> y >> z >> m;

    for (long long i = 2; i < n; ++i)
    {
        arr[i] = ((arr[i - 2] * x % m + arr[i - 1] * y % m) % m + z) % m; 
        // cout << arr[i] << ' ';
    }
    for (long long i = 1; i <= n; ++i)
    {
        prefix[i] = arr[i - 1] + prefix[i - 1];
    }

    cout << bs(1, n) << '\n';


    return 0;
}