#include <bits/stdc++.h>

using namespace std;

long long s;
int n;
const int maxn = 1e5;
long long a[maxn];

bool p(long long dif)
{
    long long lv = a[0];
    long long rv = lv + dif;
    long long sumL = 0;
    long long sumR = 0;
    int j;
    for (j = n - 1; a[j] > rv; --j) sumR += a[j];
    for (int i = 0; i < n && j < n;)
    {
        if (i * lv - sumL + sumR - ((n - j - 1) * rv) <= s) return true;
        int prevI = i;
        while (i < n - 1 && lv == a[i + 1]) i++;
        lv = a[++i];
        rv = lv + dif;
        for (; prevI < i; ++prevI) sumL += a[prevI];
        for (; j < n - 1 && a[j + 1] <= rv; ++j) sumR -= a[j + 1];
    }
    rv = a[n - 1];
    lv = rv - dif;
    sumL = 0;
    sumR = 0;
    int i;
    for (i = 0; a[i] > rv; --j) sumL += a[i];
    for (int j = n - 1; j >= 0 && i >= 0;)
    {
        if (sumL - i * lv - sumR + ((n - j - 1) * rv) <= s) return true;
        int prevJ = j;
        while (j >= 0 && rv == a[j - 1]) j--;
        rv = a[--j];
        lv = rv - dif;
        for (; prevJ > j; --prevJ) sumR += a[prevJ];
        for (; i >= 0 && a[i - 1] >= lv; --i) sumL -= a[i - 1];
    }
    return false;
}

long long bs(long long l, long long r)
{
    if (l >= r) return l;
    long long mid = (l + r) / 2;
    if (p(mid)) return bs(l, mid);
    return bs(mid + 1, r);
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;

    cin >> s;
    for (int i = 0; i < n; ++i)
    {
        cin >> a[i];
    }
    sort(a, a + n);

    cout << bs(0, a[n - 1]) << '\n';

    return 0;
}