#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    int m;
    cin >> m;
    int c;
    cin >> c;
    vector < pair <int, int> > v;
    for (int i = 0; i < n; ++i)
    {
        int a, b;
        cin >> a >> b;
        v.push_back({a, b});
    }
    for (int j = 0; j < m; ++j)
    {
        long long a;
        cin >> a;
        long long ans = v[0].second + abs(v[0].first - a) * c;
        for (int i = 1; i < n; ++i)
        {
            long long guess = v[i].second + abs(v[i].first - a) * c;
            //cout << i << ' ' << guess << '\n';
            if (guess < ans) ans = guess;
        }
        cout << ans << '\n';
    }


    return 0;
}