#include <bits/stdc++.h>

using namespace std;

long long s;
int n;
const int maxn = 1e5;
long long a[maxn];

bool p(long long dif)
{
    // cout << dif << '\n';
    int i = 0, j = n - 1;
    long long lv = 1;
    long long rv = 1 + dif;
    long long opitL = 0;
    long long opitR = 0;
    for (; a[i] < lv; ++i)
    {
        opitL += a[i] - lv;
    }
    opitL += i;
    for (; a[j] > rv; --j)
    {
        opitR += a[j] - rv - 1;
    }
    opitR += (n - j) - 1;
    // cout << i << ' ' << j << '\n';
    // cout << "lv: " << lv << " rv: " << rv << " opitL: " << opitL << " opitR: " << opitR << '\n';
    rv++;
    lv++;
    while (rv <= a[n - 1])
    {
        for (; a[i] < lv; ++i);
        opitL += i;
        int t = 0;
        for (; j < n - 1 && a[j] <= rv; ++j) t++;
        --j;
        --t;
        opitR -= (n - j - 1) + t;
        // cout << i << ' ' << j << '\n';
        // cout << "lv: " << lv << " rv: " << rv << " opitL: " << opitL << " opitR: " << opitR << '\n';
        if (opitL + opitR <= s) return true;
        lv++;
        rv++;
    }
    return false;
}

long long bs(long long l, long long r)
{
    if (l >= r) return l;
    long long mid = (l + r) / 2;
    if (p(mid)) return bs(l, mid);
    return bs(mid + 1, r);
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;

    cin >> s;
    for (int i = 0; i < n; ++i)
    {
        cin >> a[i];
    }
    sort(a, a + n);

    cout << bs(0, a[n - 1]) << '\n';

    return 0;
}