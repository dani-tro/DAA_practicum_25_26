#include <bits/stdc++.h>

using namespace std;

int k;
int n;
const int maxn = 1e7;
long long prefix[maxn + 1];

bool bs2(int l, int r)
{
    if (l >= r) return false;
    int mid = (l + r) / 2;
    if (prefix[mid] - prefix[l] >= k && prefix[r] - prefix[mid] >= k) return true;
    if (prefix[mid] - prefix[l] >= k) return bs2(l, mid - 1);
    return bs2(mid + 1, r);
}

bool p(int len)
{
    int l = 0;
    int r = len;
    while (r <= n)
    {
        if (bs2(l++, r++)) return 1;
    }
    return 0;
}

int bs(int l, int r)
{
    if (l >= r) return p(l) ? l : -1;
    int mid = (l + r) / 2;
    if (p(mid)) return bs(l, mid);
    return bs(mid + 1, r);
}


int main()
{

    cin >> n;
    cin >> k;
    
    int arr[n];
    cin >> arr[0];
    cin >> arr[1];
    int x, y, z, m;
    cin >> x >> y >> z >> m;

    for (int i = 2; i < n; ++i)
    {
        arr[i] = (arr[i - 2] * x % m + arr[i - 1] * y % m + z) % m; 
    }
    for (int i = 1; i <= n; ++i)
    {
        prefix[i] = arr[i] + prefix[i - 1];
    }

    cout << bs(1, n) << '\n';


    return 0;
}