#include <bits/stdc++.h>

long long n, h;
long long heights[10'000'005];

bool possible(long long width) {
    long long h1 = 0;
    long long placed = 0;
    while (placed < n) {
        h1 += heights[placed];
        if (h1 > h) return false;
        placed += width;
    }
    
    if (h1 > h) return false;

    return true;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> h;

    for (int i = 0; i < n; i++) {
        std::cin >> heights[i];
    }

    std::sort(heights, heights + n, [](long long a, long long b) {
        return a > b;
    });

    long long l = 1;
    long long r = 1e18;
    
    while (l < r) {
        long long mid = l + (r - l) / 2;

        if (possible(mid)) {
            r = mid;
        } else {
            l = mid + 1;
        }
    }

    std::cout << l << "\n";
}