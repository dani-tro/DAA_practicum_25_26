#include <bits/stdc++.h>

long long n, m, c;
struct land {
    long long dist;
    long long fuel;
    long long lcost;
    long long rcost;
    long long mincost;
};
land landings[100'002];

long long cost(long long landing, long long goal) {
    return landings[landing].fuel + std::abs(landings[landing].dist - goal) * c;
};

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> m >> c;
    
    for (int i = 0; i < n; i++) {
        std::cin >> landings[i].dist >> landings[i].fuel;
    }

    std::sort(landings, landings + n, [](land& l1, land& l2) {
        return l1.dist < l2.dist;
    });

    for (int i = 0; i < n; i++) {
        std::cout << landings[i].dist << ":" << landings[i].fuel << " ";
    }
    std::cout << "\n";

    landings[0].lcost = std::min(landings[0].fuel, landings[0].dist * c);
    for (int i = 1; i < n; i++) {
        landings[i].lcost = std::min(landings[i - 1].lcost + std::abs(landings[i].dist - landings[i - 1].dist) * c, landings[i].fuel);
    }

    landings[n-1].rcost = std::min(landings[n-1].fuel, landings[n-1].dist * c);
    for (int i = n-2; i >= 0; i--) {
        landings[i].rcost = std::min(landings[i + 1].rcost + std::abs(landings[i].dist - landings[i + 1].dist) * c, landings[i].fuel);
    }

    for (int i = 0; i < n; i++) {
        landings[i].mincost = std::min(landings[i].lcost, landings[i].rcost);
    }

    for (int i = 0; i < m; i++) {
        long long goal;
        std::cin >> goal;
        long long min = 1e18;
        for (int j = 0; j < n; j++) {
            long long cost1 = cost(j, goal);
            if (cost1 < min) min = cost1;
        }
            std::cout << min << "\n";
    }

};