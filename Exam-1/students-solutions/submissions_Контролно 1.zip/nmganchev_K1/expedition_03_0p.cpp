#include <bits/stdc++.h>

long long n, m, c;
long long distances[100'000];
long long fuel[100'000];

long long cost(long long landing, long long goal) {
    return fuel[landing] + std::abs(distances[landing] - goal) * c;
};

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> m >> c;
    
    for (int i = 0; i < n; i++) {
        std::cin >> distances[i] >> fuel[i];
    }

    for (int i = 0; i < m; i++) {
        long long goal;
        std::cin >> goal;
        long long l = 0;
        long long r = n;
        while (l < r) {
            long long mid1 = l + (r - l) / 3;
            long long mid2 = r - (r - l) / 3;
            long long cost1 = cost(mid1, goal);
            long long cost2 = cost(mid2, goal);
            if (cost1 < cost2) {
                r = mid2 - 1;
            } else {
                l = mid1 + 1;
            }
        }

        if (l == n) l -= 1;

        std::cout << cost(l, goal) << "\n";
    }

};