#include <bits/stdc++.h>

long long n, k;
long long punching[10'000'005];

bool possible(long long length) {
    long long begin = 1;
    long long end = length;
    while (end <= n) {
        if (punching[end] - punching[begin - 1] >= 2*k) {
            for (int mid = begin; mid <= end; mid++) {
                if (punching[mid] - punching[begin - 1] >= k && punching[end] - punching[mid] >= k) {
                    return true;
                }
            }
        }
        begin++;
        end++;
    }

    return false;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    long long a1, a2, x, y, z, m;
    std::cin >> n >> k >> a1 >> a2 >> x >> y >> z >> m;

    punching[0] = 1;
    if (n == 1) {
        punching[1] = a1;
    } else {
        punching[1] = a1;
        punching[2] = a2;
    }

    for (int i = 3; i <= n; i++) {
        punching[i] = (punching[i-2] * x + punching[i-1]*y + z) % m;
    }

    for (int i = 1; i <= n; i++) {
        punching[i] = punching[i] + punching[i-1];
    }

    long long l = 1;
    long long r = n + 1;
    while (l < r) {
        long long mid = l + (r - l) / 2;
        if (possible(mid)) {
            r = mid;
        } else {
            l = mid + 1;
        }
    }

    if (l == n + 1) l = -1;
    std::cout << l << "\n";
}