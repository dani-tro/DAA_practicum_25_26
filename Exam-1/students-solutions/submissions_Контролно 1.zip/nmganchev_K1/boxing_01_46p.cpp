#include <bits/stdc++.h>

long long n, k;
long long punching[10'000'005];

bool possible(long long length) {
    long long i = 0;
    long long j = 1;
    bool possible = false;
    while (i < n && j < n) {
        if (punching[j] - punching[i - 1] < 2*k) {
            j++;
        } else {
            possible = true;
            i++;
        }
    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    long long a1, a2, x, y, z, m;
    std::cin >> n >> k >> a1 >> a2 >> x >> y >> z >> m;

    punching[0] = 1;
    if (n == 1) {
        punching[1] = a1;
    } else {
        punching[1] = a1;
        punching[2] = a2;
    }

    for (int i = 3; i < n; i++) {
        punching[i] = (punching[i-2] * x + punching[i-1]*y + z) % m;
    }

    for (int i = 1; i < n; i++) {
        punching[i] = punching[i] + punching[i-1];
    }

    long long i = 0;
    long long j = 1;
    long long min = 1e18;
    bool possible = false;
    while (i < n && j < n) {
        if (punching[j] - punching[i - 1] < 2*k) {
            j++;
        } else {
            if (j - i + 1 < min) min = j - i + 1;
            possible = true;
            i++;
        }
    }

    if (!possible) min = -1;

    std::cout << min << "\n";
}