#include <bits/stdc++.h>

long long n, k;
long long punching[10'000'005];

bool possible(long long length) {
    long long begin = 1;
    long long end = length;
    while (end <= n) {
        if (punching[end] - punching[begin - 1] >= 2*k) {
            for (int mid = begin + 1; mid < end; mid++) {
                if (punching[mid] - punching[begin - 1] >= k && punching[end] - punching[mid - 1] >= k) {
                    return true;
                }
            }
        }
        begin++;
        end++;
    }

    return false;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    long long a1, a2, x, y, z, m;
    std::cin >> n >> k >> a1 >> a2 >> x >> y >> z >> m;

    punching[0] = 1;
    if (n == 1) {
        punching[1] = a1;
    } else {
        punching[1] = a1;
        punching[2] = a2;
    }

    for (int i = 3; i <= n; i++) {
        punching[i] = (punching[i-2] * x + punching[i-1]*y + z) % m;
    }

    for (int i = 1; i <= n; i++) {
        punching[i] = punching[i] + punching[i-1];
    }

    long long i = 0;
    long long j = 1;
    long long min = 1e18;
    for (int i = 1; i <= n; i++) {
        if (possible(i)) {
            std::cout << i << "\n";
            return 0;
        }
    }

    std::cout << -1 << "\n";
}