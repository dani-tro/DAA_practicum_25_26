#include <bits/stdc++.h>

long long n, m, c;
long long distances[100'000];
long long fuel[100'000];

long long cost(long long landing, long long goal) {
    return fuel[landing] + std::abs(distances[landing] - goal) * c;
};

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> m >> c;
    
    for (int i = 0; i < n; i++) {
        std::cin >> distances[i] >> fuel[i];
    }

    for (int i = 0; i < m; i++) {
        long long goal;
        std::cin >> goal;
        long long min = 1e18;
        long long prevCost = cost(0, goal);
        for (int j = 1; j < n; j++) {
            long long cost1 = cost(j, goal);
            if (cost1 < min) min = cost1;
            if (prevCost < cost1) break;
        }
        std::cout << min << "\n";
    }

};