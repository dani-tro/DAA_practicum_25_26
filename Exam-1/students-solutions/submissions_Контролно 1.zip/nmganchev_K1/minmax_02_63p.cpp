#include <bits/stdc++.h>

long long n, s;
long long nums[100'000];

struct num {
    long long number;
    long long count;
};
num nums2[100'000];

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);

    std::cin >> n >> s;

    for (int i = 0; i < n; i++) {
        std::cin >> nums[i];
    }

    std::sort(nums, nums + n);

    int nums2size = 0;
    for (int i = 0; i < n;) {
        int j = i;
        while (j < n && nums[i] == nums[j]) {
            j++;
        }
        num num1{nums[i], j - i};
        nums2[nums2size] = num1;
        nums2size++;
        i = j;
    }

    int least = 0;
    int max = nums2size - 1;
    while (least < max && nums2[max].number - nums2[least].number > 0 && s > 0) {
        int countMax = nums2[max].count;
        int countMin = nums2[least].count;
        if (countMin <= s || countMax <= s) {
            if (countMin <= s && countMax > s) {
                long long jumpCost = nums2[least].count * (nums2[least + 1].number - nums2[least].number);
                if (jumpCost <= s) {
                    nums2[least+1].count += nums2[least].count;
                    s -= jumpCost;
                    least++;
                } else {
                    jumpCost = s / nums2[least].count;
                    nums2[least].number += jumpCost;
                    s -= jumpCost * nums2[least].count;
                }
            } else if (countMax <= s && countMin > s) {
                long long jumpCost = nums2[max].count * (nums2[max].number - nums2[max-1].number);
                if (jumpCost <= s) {
                    nums2[max - 1].count += nums2[max].count;
                    s -= jumpCost;
                    max--;
                } else {
                    jumpCost = s / nums2[max].count;
                    nums2[max].number += jumpCost;
                    s -= jumpCost * nums2[max].count;
                }
            } else if (countMax < countMin) {
                long long jumpCost = nums2[max].count * (nums2[max].number - nums2[max-1].number);
                if (jumpCost <= s) {
                    nums2[max - 1].count += nums2[max].count;
                    s -= jumpCost;
                    max--;
                } else {
                    jumpCost = s / nums2[max].count;
                    nums2[max].number += jumpCost;
                    s -= jumpCost * nums2[max].count;
                }
            } else {
                long long jumpCost = nums2[least].count * (nums2[least + 1].number - nums2[least].number);
                if (jumpCost <= s) {
                    nums2[least+1].count += nums2[least].count;
                    s -= jumpCost;
                    least++;
                } else {
                    jumpCost = s / nums2[least].count;
                    nums2[least].number += jumpCost;
                    s -= jumpCost * nums2[least].count;
                }
            }
        } else {
            break;
        }
    }

    std::cout << nums2[max].number - nums2[least].number << "\n";
}