#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

#define MAXN 100009

int n, m;
long long c, d[MAXN];
vector<pair<long long, long long>> pads(MAXN);

long long calc(long long dist)
{
    long long curr_fuel = 0;
    long long min_fuel = LLONG_MAX;

    for (int i = 0; i < n; i++)
    {
        curr_fuel = pads[i].second + abs(pads[i].first - dist) * c;
        min_fuel = min(min_fuel, curr_fuel);
    }

    return min_fuel;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> m >> c;
    for (int i = 0; i < n; i++)
    {
        // first = dist, second = fuel needed to i
        cin >> pads[i].first >> pads[i].second;
    }

    for (int i = 0; i < m; i++)
    {
        cin >> d[i];
    }

    for (int i = 0; i < m; i++)
    {
        cout << calc(d[i]) << endl;
    }
}