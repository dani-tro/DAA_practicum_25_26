#include <iostream>
#include <algorithm>

using namespace std;

#define MAXN 10000009

int n, h, a[MAXN];

// bool check(long long width)
// {
//     long long height = 0;
//     for (int i = 0; i < n; i++)
//     {
//         long long j = 1;
//         int curr_highest_vase = a[i];
//         while (j < width && i < n)
//         {
//             // cout << "curr_width: " << j << "  curr_highest_vase: " << curr_highest_vase << "   i: " << i << endl;
//             j++;
//             i++;
//             curr_highest_vase = max(curr_highest_vase, a[i]);
//         }
//         height += curr_highest_vase;
//     }

//     return height <= h;
// }

// bool check(long long width)
// {
//     long long heigth = 0;
//     long long curr_width = 0;
//     int curr_heighes_vase = 0;
//     for (int i = 0; i < n; i++)
//     {
//         if (curr_width < width)
//         {
//             curr_width++;
//             curr_heighes_vase = max(curr_heighes_vase, a[i]);
//         }
//         else
//         {
//             heigth += curr_heighes_vase;
//             curr_width = 1;
//             curr_heighes_vase = a[i];
//         }
//     }

//     if (n % width != 0)
//     {
//         heigth += curr_heighes_vase;
//     }

//     return heigth <= h;
// }

bool check(long long width)
{
    long long heigth = 0;
    long long curr_width = 0;
    int curr_heighes_vase = 0;
    for (int i = 0; i < n; i++)
    {
        if (curr_width < width)
        {
            curr_width++;
            curr_heighes_vase = max(curr_heighes_vase, a[i]);
        }
        else
        {
            heigth += curr_heighes_vase;
            curr_width = 1;
            curr_heighes_vase = a[i];
        }
        // cout << heigth << " : " << curr_heighes_vase << endl;
    }
    
    // if (n % width != 0)
    // {
    //     heigth += curr_heighes_vase;
    // }
    heigth += curr_heighes_vase;
    // cout << heigth << endl;
    return heigth <= h;
}


int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> h;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    sort(a, a + n);

    long long l = 1, r = 1e14;
    while (l < r)
    {
        long long mid = (r + l) / 2;
        if (check(mid))
        {
            r = mid;
        }
        else
        {
            l = mid + 1;
        }
    }

    cout << l << endl;

    // check(2);
}
