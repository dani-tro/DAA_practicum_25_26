#include <iostream>
#include <algorithm>

using namespace std;

#define MAXN 10000009

int n, h, a[MAXN];

bool check(long long width)
{
    long long height = 0;
    for (int i = 0; i < n; i++)
    {
        long long j = 1;
        int curr_highest_vase = a[i];
        while (j < width & i < n)
        {
            j++;
            i++;
            curr_highest_vase = max(curr_highest_vase, a[i]);
        }
        height += curr_highest_vase;
    }

    return height <= h;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> n >> h;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    sort(a, a + n);

    long long l = 1, r = 1e14;
    while (l < r)
    {
        long long mid = (r + l) / 2;
        if (check(mid))
        {
            r = mid;
        }
        else
        {
            l = mid + 1;
        }
    }

    cout << l << endl;
}
