#include<iostream>
#include<vector>
#include<algorithm>

int main(){
    size_t element;
    size_t vases_num;
    size_t wall_height;
    std::cin >> vases_num >> wall_height;
    std::vector<size_t> vases_heights;
    for(size_t i = 0; i < vases_num; i++){
        std::cin >> element;
        vases_heights.push_back(element);
    }

    sort(vases_heights.begin(), vases_heights.end(), std::greater<int>());

    if(vases_heights[0] > wall_height){
        std::cout << 0;
        return 0;
    }

    for(size_t i = vases_heights.size(); i > 0; i--){
        size_t step = vases_heights.size() - i + 1;
        size_t height = 0;
        size_t current = 0;
        while(true){
            if(current < vases_heights.size()){
                height += vases_heights[current];
                current += step;
            }
            else break;
        }
        if(height <= wall_height){
            std::cout << step;
            break;
        }
    }
    return 0;
}