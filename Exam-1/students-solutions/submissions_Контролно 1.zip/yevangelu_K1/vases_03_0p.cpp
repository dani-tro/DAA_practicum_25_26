#include<iostream>
#include<vector>

void sort(std::vector<size_t>& elements){
    for(size_t i = 0; i < elements.size(); i++)
        for(size_t j = 0; j < elements.size() - i - 1; j++)
            if(elements[j] < elements[j + 1])
                std::swap(elements[j], elements[j + 1]);
}

int main(){
    size_t element;
    size_t vases_num;
    size_t wall_height;
    std::cin >> vases_num >> wall_height;
    std::vector<size_t> vases_heights;
    for(size_t i = 0; i < vases_num; i++){
        std::cin >> element;
        vases_heights.push_back(element);
    }

    sort(vases_heights);

    for(size_t i = vases_heights.size(); i > 0; i--){
        if(vases_heights[0] > wall_height){
            std::cout << 0;
            break;
        }
        size_t step = vases_num / i;
        size_t height = 0;
        size_t current = 0;
        while(height < wall_height){
            if(current < vases_heights.size()){
                height += vases_heights[current];
                current += step;
            }
            else break;
        }
        if(height < wall_height){
            std::cout << step;
            break;
        }
    }
    return 0;
}