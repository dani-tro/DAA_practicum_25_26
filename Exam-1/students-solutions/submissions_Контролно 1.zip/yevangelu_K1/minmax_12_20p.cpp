#include<iostream>

int main(){
    size_t min = 1000001, max = 0;
    size_t element;
    size_t size;
    size_t changes;
    
    std::cin >> size >> changes;

    size_t nums[100000];

    for(size_t i = 0; i < size; i++){
        std::cin >> element;
        nums[i] = element;
    }

    size_t min_num, max_num;

    //find min and max
    min = 1000001;
    max = 0;
    for(int j = 0; j < size; j++){
        if(nums[j] < min)
            min = nums[j];
        
        if(nums[j] > max)
            max = nums[j];
    }

    while(changes > 0){
        min_num = 0;
        max_num = 0;

        //all equal
        if(min == max)
            break;

        //check number of min and max
        for(size_t j = 0; j < size; j++){
            if(nums[j] == max)
                max_num++;
            if(nums[j] == min)
                min_num++;
        }

        for(size_t i = 0; i < size; i++){
            if(min_num < max_num){
                if(min == nums[i]){
                    nums[i]++;
                    changes--;
                    if(changes == 0)
                       break;
                }
            }
            else{
                if(max == nums[i]){
                    nums[i]--;
                    changes--;
                    if(changes == 0)
                        break;
                }
            }
        }
        if(min_num < max_num)
            min++;
        else
            max--;
    }

    min = 1000001;
    max = 0;
    for(size_t j = 0; j < size; j++){
        if(nums[j] < min)
            min = nums[j];
        
        if(nums[j] > max)
            max = nums[j];
    }

    std::cout << std::endl << (max - min);
    return 0;
}