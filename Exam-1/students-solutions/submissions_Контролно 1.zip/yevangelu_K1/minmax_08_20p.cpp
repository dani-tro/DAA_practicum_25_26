#include<iostream>
#include<vector>
#include <array>

const size_t constant(size_t i){
    return i;
}

int main(){
    size_t min = 1000001, max = 0;
    size_t element;
    size_t size;
    size_t changes;
    
    std::cin >> size >> changes;

    std::vector<size_t> nums;

    for(size_t i = 0; i < size; i++){
        std::cin >> element;
        nums.push_back(element);
    }

    size_t min_num, max_num;

    while(changes > 0){
        min_num = 0;
        max_num = 0;

        //find min and max
        min = 1000001;
        max = 0;
        for(int j = 0; j < size; j++){
            if(nums[j] < min)
                min = nums[j];
            
            if(nums[j] > max)
                max = nums[j];
        }

        //all equal
        if(min == max)
            break;

        //check number of min and max
        for(size_t j = 0; j < size; j++){
            if(nums[j] == max)
                max_num++;
            if(nums[j] == min)
                min_num++;
        }

        //performing changes
        if(max_num == 1){
            for(size_t j = 0; j < size; j++){
                if(max == nums[j]){
                    nums[j]--;
                    changes--;
                    break;
                }
            }
        }
        else if(min_num == 1){
            for(size_t j = 0; j < size; j++){
                if(min == nums[j]){
                    nums[j]++;
                    changes--;
                    break;
                }
            }
        }
        else if(min_num < max_num){
            for(size_t j = 0; j < size; j++){
                if(min == nums[j]){
                    nums[j]++;
                    changes--;
                    if(changes == 0)
                        break;
                }
            }
        }
        else if(min_num > max_num){
            for(size_t j = 0; j < size; j++){
                if(max == nums[j]){
                    nums[j]--;
                    changes--;
                    if(changes == 0)
                        break;
                }
            }
        }
        else{
            for(size_t j = 0; j < size; j++){
                if(min == nums[j]){
                    nums[j]++;
                    changes--;
                    if(changes == 0)
                        break;
                }
            }
        }
    }

    min = 1000001;
    max = 0;

    for(size_t j = 0; j < size; j++){
        if(nums[j] < min)
            min = nums[j];
        
        if(nums[j] > max)
            max = nums[j];
    }

    std::cout << (max - min);
    return 0;
}