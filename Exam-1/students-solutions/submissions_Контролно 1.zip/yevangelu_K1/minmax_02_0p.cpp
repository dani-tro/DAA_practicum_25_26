#include<iostream>
#include<vector>

int main(){
    size_t min = 1000001, max = 0;
    size_t element;
    size_t size;
    size_t changes;
    std::vector<size_t> nums;
    
    std::cin >> size >> changes;

    for(size_t i = 0; i < size; i++){
        std::cin >> element;
        nums.push_back(element);
    }

    for(int j = 0; j < size; j++){
        if(nums[j] < min)
            min = nums[j];
            
        if(nums[j] > max)
            max = nums[j];
    }

    int min_num, max_num;

    for(int i = 0; i < changes;){
        min_num = 0;
        max_num = 0;

        //all equal
        if(min == max)
            break;

        //check number of min and max
        for(int j = 0; j < size; j++){
            if(nums[i] == max)
                max_num++;
            if(nums[i] == min)
                min_num++;
        }

        //single change
        if(max_num == 1){
            for(int j = 0; j < size; j++){
                if(max == nums[j]){
                    nums[j]--;
                    i++;
                    break;
                }
            }
            max--;
        }

        //singe change
        if(min_num == 1){
            for(int j = 0; j < size; j++){
                if(min == nums[j]){
                    nums[j]++;
                    i++;
                    break;
                }
            }
            min++;
        }

        //multiple changes
        if(min_num > 1 && max_num > 1){
            if(min_num < max_num){
                for(int j = 0; j < size; j++){
                    if(min == nums[j]){
                        nums[j]++;
                        i++;
                    }
                }
                min--;
            }
            else if(min_num > max_num){
                for(int j = 0; j < size; j++){
                    if(max == nums[j]){
                        nums[j]--;
                        i++;
                    }
                }
                max--;
            }
            else{
                for(int j = 0; j < size; j++){
                    if(min == nums[j]){
                        nums[j]++;
                        i++;
                    }
                }
                min--;
            }
        }
    }

    std::cout << (max - min);
    return 0;
}