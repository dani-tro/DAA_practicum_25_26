// #include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;

using ll = long long;

ll N, K;
ll a1, a2, X, Y, Z, M;

int main() {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> K;
    cin >> a1 >> a2 >> X >> Y >> Z >> M;;

    vector<ll> a(N);
    a[0] = a1;
    a[1] = a2;
    for (ll i = 2; i < N; ++i){
        a[i] = (a[i-2] * X + a[i-1] * Y + Z) % M;
    }
    
    ll l = 0;
    ll res = -1;
    for (ll r = 1; r < N; ++r){
        ll boxing = 0;
        ll i = l;
        while (i < r){
            boxing += a[i];
            i++;
        }
        if (boxing >= K){
            res = r - l + 1;
        }
        else{
            l++;
        }
    }

    cout << res << endl;

    return 0;
}