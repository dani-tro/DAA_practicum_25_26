// #include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

using ll = long long;

ll N, S;

int main() {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> S;

    vector<ll> seq(N);

    for(ll i = 0; i < N; ++i) cin >> seq[i];

    sort(seq.begin(), seq.end());

    ll l = 0;
    ll maxsub = seq[N-1] - seq[0];
    for (ll r = 0; r < N && S > 0; ++r){
        ll currsub = seq[r] - seq[l];
        if(currsub < maxsub){
            S -= currsub;
            seq[l] = seq[r];
            l++;
        }
        else if(seq[r] - seq[l] == maxsub){
            S -= seq[r] - seq[l];
            seq[r] = seq[l];
            l++;
        }
    }
    
    cout << seq[N-1] - seq[0] << endl;

    return 0;
}