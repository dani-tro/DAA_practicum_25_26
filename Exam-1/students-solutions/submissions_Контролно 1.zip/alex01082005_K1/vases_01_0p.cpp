// #include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

using ll = long long;

ll N, H;

bool check(ll mid, ll N, ll H, vector<ll> &sorted_vases){
    ll total = 1;
    ll heihts = 0;
    if (total > mid) return false;
    for (auto v : sorted_vases){
        heihts += v;
        if (heihts == H){
            total++;
            heihts = 0;
        }
    }

    return total <= mid;
}

int main() {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> H;

    vector<ll> vaseheight(N);
    ll sum = 0;
    for (ll i = 0; i < N; ++i) {
        cin >> vaseheight[i];
        sum += vaseheight[i];
    }

    sort(vaseheight.begin(), vaseheight.end());

    ll l = 1, h = N;
    ll res = h;

    if (sum == H){
        cout << 1 << endl;
        return 0;
    }
    
    while (l <= h){
        ll mid = (l + h) / 2;
        if (check(mid, N, H, vaseheight)){
            res = mid;
            h = mid - 1;
        }
        else l = mid + 1;
    }

    cout << res << endl;

    return 0;
}