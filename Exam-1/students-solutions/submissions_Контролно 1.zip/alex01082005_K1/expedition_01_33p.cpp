// #include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

using ll = long long;

ll N, M, C;

struct Point{
    ll km, fuel;
};

int main() {
    ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

    cin >> N >> M >> C;

    vector<Point> points(N);
    vector<ll> location(M);

    for (ll i = 0; i < N; ++i) cin >> points[i].km >> points[i].fuel;
    for (ll i = 0; i < M; ++i) cin >> location[i];

    vector<ll> results;

    priority_queue<ll> pq;

    for (ll i = 0; i < M; ++i){
        vector<ll> currres;
        for (ll j = 0; j < N; ++j){
            currres.push_back(points[j].fuel + abs(points[j].km - location[i]) * C);
        }
        sort(currres.begin(), currres.end());
        results.push_back(currres[0]);
    }

    for (auto res : results){
        cout << res << endl;
    }

    return 0;
}