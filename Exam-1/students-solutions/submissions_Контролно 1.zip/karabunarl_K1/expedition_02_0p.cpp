#include <iostream>
#include <algorithm>
using namespace std;

const int MAX = 100010;
int n, m, c, a[MAX], b[MAX], d[MAX];
long long s;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> c;
    for (int i = 1; i <= n; i++) cin >> a[i] >> b[i];
    for (int i = 1; i <= m; i++) cin >> d[i];

    int minfuel;
    for (int i = 1; i <= m; i++)
    {
        minfuel = b[1] + c * abs(a[1] - d[i]);
        for (int j = 1; j <= n; j++)
        {   
            minfuel = min(minfuel, b[j] + c * abs(a[j] - d[i]));
        }
        cout << minfuel << "\n";
    }
}