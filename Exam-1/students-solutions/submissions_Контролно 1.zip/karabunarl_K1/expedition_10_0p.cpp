#include <iostream>
#include <algorithm>
using namespace std;

const int MAX = 100010;
int n, m, c;
pair <int, int> d[MAX];
pair <int, int> ab[MAX];
long long result[MAX];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> c;
    for (int i = 1; i <= n; i++) cin >> ab[i].first >> ab[i].second;
    for (int i = 1; i <= m; i++)
    {
        cin >> d[i].first;
        d[i].second = i;
    }

    sort(ab + 1, ab + n + 1);
    sort(d + 1, d + m + 1);

    int stopidx = 1;
    for (int i = 1; i <= m; i++) // expeditions
    {
        long long minfuel = ab[stopidx].second + c * abs(ab[stopidx].first - d[i].first);

        for (int j = stopidx; j <= n; j++)
        {
            if (minfuel >= ab[j].second + c * abs(ab[j].first - d[i].first))
            {
                stopidx = j;
                minfuel = ab[j].second + c * abs(ab[j].first - d[i].first);
            }
        }
        result[d[i].second] = minfuel;
    }
    
    for (int i = 1; i <= m; i++) cout << result[i] << "\n";
}