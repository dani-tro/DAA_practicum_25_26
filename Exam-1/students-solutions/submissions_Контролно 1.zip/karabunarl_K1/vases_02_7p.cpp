#include <iostream>
#include <algorithm>
using namespace std;

const int MAX = 10000010;
int n, h, a[MAX];

bool solve(int w)
{
    int curh = 0;
    for (int i = w; i <= n; i += w)
    {
        curh += a[i];
    }
    if (n % w != 0) curh += a[n];
    return curh <= h;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> h;
    for (int i = 1; i <= n; i++) cin >> a[i];

    sort(a + 1, a + n + 1);

    int l = 1, r = n, m;
    while (l < r)
    {
        m = (l + r) / 2;
        //cout << l << " " << m << " " << r << " \n";
        if (solve(m))
        {
            r = m;
        }
        else l = m + 1;
    }
    cout << l;
}