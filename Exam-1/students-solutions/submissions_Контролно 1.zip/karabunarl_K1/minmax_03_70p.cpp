#include <iostream>
#include <algorithm>
using namespace std;

const int MAX = 100010;
int n, a[MAX];
long long s;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> s;
    for (int i = 1; i <= n; i++) cin >> a[i];

    sort(a + 1, a + n + 1);

    int l = 1, r = n;
    long long cost = 0, mincnt;

    while (l < r)
    {
        mincnt = min(l, n - r + 1);
        if (a[l] == a[l + 1]) l++;
        else if (a[r] == a[r - 1]) r--;
        else if (cost + mincnt <= s)
        {
            cost += mincnt;
            if (l <= n - r + 1)
            {
                a[l]++;
            }
            else a[r]--;
        }
        else
        {
            cout << a[r] - a[l];
            return 0;
        }
    }
    cout << a[r] - a[l];
}